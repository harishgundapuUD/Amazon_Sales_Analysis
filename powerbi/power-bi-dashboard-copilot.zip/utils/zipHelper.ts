
declare const JSZip: any;

export async function createAndDownloadZip(files: Record<string, string>, zipFileName: string): Promise<void> {
  if (typeof JSZip === 'undefined') {
    console.error('JSZip library is not loaded.');
    alert('Could not create ZIP file. JSZip library is missing.');
    return;
  }
  const zip = new JSZip();

  for (const [fileName, content] of Object.entries(files)) {
    zip.file(fileName, content);
  }

  const zipBlob = await zip.generateAsync({ type: 'blob' });

  const link = document.createElement('a');
  link.href = URL.createObjectURL(zipBlob);
  link.download = zipFileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(link.href);
}
