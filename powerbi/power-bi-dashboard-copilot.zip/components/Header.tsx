
import React from 'react';
import { BotIcon } from './icons/BotIcon';

export const Header: React.FC = () => {
    return (
        <header className="flex items-center space-x-3">
            <div className="p-2 bg-indigo-600 rounded-lg">
                <BotIcon className="w-8 h-8 text-white"/>
            </div>
            <div>
                <h1 className="text-2xl font-bold text-white">Power BI Copilot</h1>
                <p className="text-sm text-gray-400">AI-Powered Dashboard Instructions</p>
            </div>
        </header>
    );
}
