
import React, { useMemo, useState } from 'react';
import type { Question } from '../types';
import { ChevronDownIcon } from './icons/ChevronDownIcon';
import { CheckCircleIcon } from './icons/CheckCircleIcon';

interface QuestionListProps {
  questions: Question[];
  onQuestionSelect: (question: Question) => void;
  selectedQuestionId?: number | null;
  generatedQuestionIds: number[];
  disabled: boolean;
}

export const QuestionList: React.FC<QuestionListProps> = ({ questions, onQuestionSelect, selectedQuestionId, generatedQuestionIds, disabled }) => {
  const groupedQuestions = useMemo(() => {
    return questions.reduce((acc, question) => {
      (acc[question.category] = acc[question.category] || []).push(question);
      return acc;
    }, {} as Record<string, Question[]>);
  }, [questions]);

  const [openCategories, setOpenCategories] = useState<Record<string, boolean>>(() => {
      const initialState: Record<string, boolean> = {};
      Object.keys(groupedQuestions).forEach(category => {
          initialState[category] = true;
      });
      return initialState;
  });

  const toggleCategory = (category: string) => {
    setOpenCategories(prev => ({ ...prev, [category]: !prev[category] }));
  };

  return (
    <div className={`p-4 space-y-2 ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}>
      {Object.entries(groupedQuestions).map(([category, qs]) => (
        <div key={category} className="bg-gray-800 rounded-lg">
          <button
            className="w-full flex justify-between items-center p-4 text-left font-semibold text-lg"
            onClick={() => toggleCategory(category)}
          >
            <span>{category}</span>
            <ChevronDownIcon className={`w-5 h-5 transition-transform ${openCategories[category] ? 'rotate-180' : ''}`} />
          </button>
          {openCategories[category] && (
            <div className="border-t border-gray-700">
              <ul className="p-2 space-y-1">
                {qs.map((q) => (
                  <li key={q.id}>
                    <button
                      onClick={() => !disabled && onQuestionSelect(q)}
                      disabled={disabled}
                      className={`w-full text-left p-3 rounded-md transition-colors text-sm flex items-start space-x-3 ${
                        selectedQuestionId === q.id
                          ? 'bg-indigo-600/30 text-indigo-300'
                          : 'hover:bg-gray-700/50'
                      }`}
                    >
                      <span className="font-semibold text-gray-400 mt-0.5">Q{q.id}.</span>
                      <span className="flex-1">{q.text}</span>
                      {generatedQuestionIds.includes(q.id) && <CheckCircleIcon className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};
