
import React from 'react';
import type { Question } from '../types';
import { MarkdownRenderer } from './MarkdownRenderer';
import { FileTextIcon } from './icons/FileTextIcon';
import { UploadCloudIcon } from './icons/UploadCloudIcon';

interface InstructionPanelProps {
  question: Question | null;
  instruction: string | null | undefined;
  isLoading: boolean;
  error: string | null;
  isReady: boolean;
}

const LoadingSkeleton: React.FC = () => (
    <div className="space-y-6 animate-pulse">
      <div className="h-6 bg-gray-700 rounded w-3/4"></div>
      <div className="space-y-3">
        <div className="h-4 bg-gray-700 rounded"></div>
        <div className="h-4 bg-gray-700 rounded w-5/6"></div>
      </div>
      <div className="h-6 bg-gray-700 rounded w-1/2"></div>
      <div className="space-y-3">
        <div className="h-4 bg-gray-700 rounded"></div>
        <div className="h-4 bg-gray-700 rounded w-5/6"></div>
        <div className="h-4 bg-gray-700 rounded w-4/5"></div>
      </div>
    </div>
);


export const InstructionPanel: React.FC<InstructionPanelProps> = ({ question, instruction, isLoading, error, isReady }) => {
    
    const renderContent = () => {
        if (!isReady) {
            return (
                <div className="text-center">
                    <UploadCloudIcon className="mx-auto h-16 w-16 text-gray-500" />
                    <h3 className="mt-4 text-lg font-medium text-gray-300">Upload a CSV file</h3>
                    <p className="mt-2 text-sm text-gray-500">Please upload your Amazon sales data to get started.</p>
                </div>
            );
        }

        if (!question) {
            return (
                <div className="text-center">
                    <FileTextIcon className="mx-auto h-16 w-16 text-gray-500" />
                    <h3 className="mt-4 text-lg font-medium text-gray-300">Select a question</h3>
                    <p className="mt-2 text-sm text-gray-500">Choose a question from the list to view the AI-generated instructions.</p>
                </div>
            );
        }

        if (isLoading) {
            return <LoadingSkeleton />;
        }

        if (error) {
            return (
                <div className="text-center text-red-400 bg-red-900/20 p-4 rounded-lg">
                    <h3 className="font-semibold">An Error Occurred</h3>
                    <p>{error}</p>
                </div>
            );
        }

        if (instruction) {
            return <MarkdownRenderer content={instruction} />;
        }
        
        return null; // Should not happen if a question is selected
    };

    return (
        <div className="p-8 h-full">
            <div className="flex items-center justify-center h-full">
               {renderContent()}
            </div>
        </div>
    );
};
