
import React from 'react';

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const renderContent = () => {
    const lines = content.split('\n');
    const elements: React.ReactNode[] = [];
    let inList = false;
    let inCodeBlock = false;
    let codeBlockContent = '';

    const flushList = () => {
      if (inList) {
        elements.push(<ul key={`ul-${elements.length}`} className="list-disc list-inside space-y-2 mb-4 pl-4">{listItems}</ul>);
        listItems = [];
        inList = false;
      }
    };
    
    const flushCodeBlock = () => {
      if (inCodeBlock) {
        elements.push(
          <pre key={`pre-${elements.length}`} className="bg-gray-800 p-4 rounded-md my-4 overflow-x-auto">
            <code className="text-sm text-indigo-300 font-mono">{codeBlockContent}</code>
          </pre>
        );
        codeBlockContent = '';
        inCodeBlock = false;
      }
    };

    let listItems: React.ReactNode[] = [];

    lines.forEach((line, index) => {
        if (line.startsWith('```')) {
            if (inCodeBlock) {
                flushCodeBlock();
            } else {
                flushList();
                inCodeBlock = true;
            }
            return;
        }

        if (inCodeBlock) {
            codeBlockContent += line + '\n';
            return;
        }

        if (line.startsWith('# ')) {
            flushList();
            elements.push(<h1 key={index} className="text-3xl font-bold mb-4 mt-6 border-b border-gray-600 pb-2">{line.substring(2)}</h1>);
        } else if (line.startsWith('## ')) {
            flushList();
            elements.push(<h2 key={index} className="text-2xl font-bold mb-3 mt-5">{line.substring(3)}</h2>);
        } else if (line.startsWith('### ') || line.match(/^\d+\.\s/)) {
            flushList();
            elements.push(<h3 key={index} className="text-xl font-semibold mb-3 mt-4">{line.replace(/^###\s/, '').replace(/^\d+\.\s/, '')}</h3>);
        } else if (line.startsWith('* ') || line.startsWith('- ')) {
            if (!inList) {
                inList = true;
            }
            listItems.push(<li key={index}>{line.substring(2)}</li>);
        } else if (line.trim() === '') {
            flushList();
            elements.push(<div key={index} className="h-4" />); // Represents a paragraph break
        } else {
            flushList();
            const formattedLine = line
                .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-white">$1</strong>')
                .replace(/`(.*?)`/g, '<code class="bg-gray-700 text-indigo-300 px-1.5 py-0.5 rounded-md font-mono text-sm">$1</code>');

            elements.push(<p key={index} className="mb-4 text-gray-300" dangerouslySetInnerHTML={{ __html: formattedLine }} />);
        }
    });

    flushList();
    flushCodeBlock();

    return elements;
  };

  return <div className="prose prose-invert max-w-none">{renderContent()}</div>;
};
