
export interface Question {
  id: number;
  category: string;
  text: string;
}
