
import type { Question } from './types';

export const ALL_QUESTIONS: Question[] = [
  // Executive Dashboard
  { id: 1, category: 'Executive Dashboard', text: 'Create an Executive Summary Dashboard showing key business metrics: Total Revenue, Growth Rate, Active Customers, Average Order Value, and Top Performing Categories. Include year-over-year comparisons and trend indicators.' },
  { id: 2, category: 'Executive Dashboard', text: 'Build a Real-time Business Performance Monitor displaying current month performance vs targets, revenue run-rate, customer acquisition metrics, and key operational indicators with alerts for underperformance.' },
  { id: 3, category: 'Executive Dashboard', text: 'Design a Strategic Overview Dashboard showing market share analysis, competitive positioning, geographic expansion metrics, and business health indicators for C-level decision making.' },
  { id: 4, category: 'Executive Dashboard', text: 'Create a Financial Performance Dashboard with revenue breakdown by categories, profit margin analysis, cost structure visualization, and financial forecasting models.' },
  { id: 5, category: 'Executive Dashboard', text: 'Build a Growth Analytics Dashboard tracking customer growth, market penetration, product portfolio expansion, and strategic initiative performance with predictive insights.' },

  // Revenue Analytics
  { id: 6, category: 'Revenue Analytics', text: 'Design a Revenue Trend Analysis Dashboard showing monthly/quarterly/yearly revenue patterns, growth rates, seasonal variations, and revenue forecasting with interactive time period selection.' },
  { id: 7, category: 'Revenue Analytics', text: 'Create a Category Performance Dashboard analyzing revenue contribution, growth trends, market share changes, and category-wise profitability with drill-down capabilities.' },
  { id: 8, category: 'Revenue Analytics', text: 'Build a Geographic Revenue Analysis showing state-wise and city-wise performance, tier-wise growth patterns, and market penetration opportunities with interactive maps.' },
  { id: 9, category: 'Revenue Analytics', text: 'Design a Festival Sales Analytics Dashboard tracking festival period performance, campaign effectiveness, promotional impact, and seasonal revenue optimization insights.' },
  { id: 10, category: 'Revenue Analytics', text: 'Create a Price Optimization Dashboard analyzing price elasticity, discount effectiveness, competitive pricing, and revenue impact of pricing strategies.' },

  // Customer Analytics
  { id: 11, category: 'Customer Analytics', text: 'Build a Customer Segmentation Dashboard using RFM analysis, behavioral segmentation, lifetime value analysis, and targeted marketing recommendations with interactive customer profiles.' },
  { id: 12, category: 'Customer Analytics', text: 'Design a Customer Journey Analytics Dashboard tracking acquisition channels, purchase patterns, category transitions, and customer evolution from first-time to loyal customers.' },
  { id: 13, category: 'Customer Analytics', text: 'Create a Prime Membership Analytics Dashboard analyzing Prime vs non-Prime behavior, membership value analysis, retention rates, and Prime-specific business insights.' },
  { id: 14, category: 'Customer Analytics', text: 'Build a Customer Retention Dashboard showing cohort analysis, churn prediction, retention strategies effectiveness, and customer lifecycle management insights.' },
  { id: 15, category: 'Customer Analytics', text: 'Design a Demographics & Behavior Dashboard analyzing age group preferences, spending patterns, geographic behaviors, and targeted marketing opportunities.' },

  // Product & Inventory Analytics
  { id: 16, category: 'Product & Inventory Analytics', text: 'Create a Product Performance Dashboard ranking products by revenue, units sold, ratings, and return rates with category-wise analysis and product lifecycle tracking.' },
  { id: 17, category: 'Product & Inventory Analytics', text: 'Build a Brand Analytics Dashboard comparing brand performance, market share evolution, customer preferences, and competitive positioning across categories.' },
  { id: 18, category: 'Product & Inventory Analytics', text: 'Design an Inventory Optimization Dashboard analyzing product demand patterns, seasonal trends, inventory turnover, and demand forecasting for better inventory management.' },
  { id: 19, category: 'Product & Inventory Analytics', text: 'Create a Product Rating & Review Dashboard analyzing rating distributions, review sentiment, correlation with sales, and product quality insights.' },
  { id: 20, category: 'Product & Inventory Analytics', text: 'Build a New Product Launch Dashboard tracking launch performance, market acceptance, competitive analysis, and success metrics for product development teams.' },

  // Operations & Logistics
  { id: 21, category: 'Operations & Logistics', text: 'Design a Delivery Performance Dashboard analyzing delivery times, on-time delivery rates, geographic performance variations, and operational efficiency metrics.' },
  { id: 22, category: 'Operations & Logistics', text: 'Create a Payment Analytics Dashboard showing payment method preferences, transaction success rates, payment trends evolution, and financial partnership insights.' },
  { id: 23, category: 'Operations & Logistics', text: 'Build a Return & Cancellation Dashboard analyzing return rates, return reasons, cost impact, and quality improvement opportunities with category-wise breakdown.' },
  { id: 24, category: 'Operations & Logistics', text: 'Design a Customer Service Dashboard tracking customer satisfaction scores, complaint categories, resolution times, and service quality improvements.' },
  { id: 25, category: 'Operations & Logistics', text: 'Create a Supply Chain Dashboard monitoring supplier performance, delivery reliability, cost analysis, and vendor management insights.' },

  // Advanced Analytics
  { id: 26, category: 'Advanced Analytics', text: 'Build a Predictive Analytics Dashboard with sales forecasting, customer churn prediction, demand planning, and business scenario analysis using advanced statistical models.' },
  { id: 27, category: 'Advanced Analytics', text: 'Design a Market Intelligence Dashboard analyzing competitor tracking, market trends, pricing intelligence, and strategic positioning insights.' },
  { id: 28, category: 'Advanced Analytics', text: 'Create a Cross-selling & Upselling Dashboard identifying product associations, recommendation effectiveness, bundle opportunities, and revenue optimization strategies.' },
  { id: 29, category: 'Advanced Analytics', text: 'Build a Seasonal Planning Dashboard for inventory planning, promotional calendar, resource allocation, and seasonal business optimization.' },
  { id: 30, category: 'Advanced Analytics', text: 'Design a Business Intelligence Command Center integrating all key metrics, automated alerts, performance monitoring, and strategic decision support tools.' }
];
