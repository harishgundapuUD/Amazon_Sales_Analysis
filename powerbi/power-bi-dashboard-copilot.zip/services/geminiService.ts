
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

function buildPrompt(csvSample: string, questionText: string): string {
    const csvHeaders = csvSample.split('\n')[0];
    const csvSampleRows = csvSample.split('\n').slice(1).join('\n');

    return `
You are a world-class Power BI and data analytics consultant. A user has provided a CSV file with the following headers and a few sample rows of data.

**CSV Data Sample:**
\`\`\`csv
${csvHeaders}
${csvSampleRows}
\`\`\`

The user wants to build a Power BI dashboard to answer the following question:

**User's Goal:**
"${questionText}"

Your task is to provide comprehensive, step-by-step instructions for the user to create this dashboard in Power BI Desktop. Assume the user is new to Power BI.

**Instructions Format:**
Your response must be in well-structured Markdown. Follow this format strictly:

1.  **Objective:** Briefly state the goal of this dashboard.
2.  **Data Loading & Preparation:**
    *   Explain how to load the CSV data into Power BI.
    *   Detail any necessary data cleaning or transformation steps in Power Query Editor (e.g., changing data types, handling nulls, creating new columns). Be specific about which columns to transform.
3.  **Data Modeling (if necessary):**
    *   Mention if a date table is needed and provide the DAX code to create one.
    *   Explain any relationships that need to be created.
4.  **DAX Measures:**
    *   List all necessary DAX measures. For each measure, provide the name, the DAX formula, and a brief explanation of what it calculates. Use code blocks for formulas.
5.  **Visualization:**
    *   Recommend specific visuals for each metric (e.g., Card, Bar Chart, Line Chart, Map).
    *   For each visual, specify which fields and measures should be used for axes, values, legends, etc.
    *   Suggest layout and design tips for an effective and visually appealing dashboard.
6.  **Interactivity:**
    *   Suggest slicers (e.g., by Year, Category) to allow the user to filter the dashboard.
    *   Explain how to set up drill-down/drill-through functionality if applicable.

Provide clear, concise, and actionable steps. Your guidance should empower the user to build a fully functional and insightful dashboard from scratch.
`;
}


export async function generateInstructions(csvSample: string, questionText: string): Promise<string> {
    const prompt = buildPrompt(csvSample, questionText);

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error generating content from Gemini:", error);
        throw new Error("Failed to communicate with the AI model.");
    }
}
