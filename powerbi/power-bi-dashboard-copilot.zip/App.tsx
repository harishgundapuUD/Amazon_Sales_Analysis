
import React, { useState, useCallback, useMemo } from 'react';
import { FileUpload } from './components/FileUpload';
import { QuestionList } from './components/QuestionList';
import { InstructionPanel } from './components/InstructionPanel';
import { Header } from './components/Header';
import { DownloadIcon } from './components/icons/DownloadIcon';
import { ALL_QUESTIONS } from './constants';
import type { Question } from './types';
import { generateInstructions } from './services/geminiService';
import { createAndDownloadZip } from './utils/zipHelper';

// For using JSZip from CDN
declare const JSZip: any;

export default function App(): React.ReactElement {
  const [csvContent, setCsvContent] = useState<string | null>(null);
  const [csvFileName, setCsvFileName] = useState<string | null>(null);
  const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(null);
  const [instructions, setInstructions] = useState<Record<number, string>>({});
  const [loadingStates, setLoadingStates] = useState<Record<number, boolean>>({});
  const [errorStates, setErrorStates] = useState<Record<number, string | null>>({});
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);

  const csvSample = useMemo(() => {
    if (!csvContent) return null;
    const lines = csvContent.split('\n');
    const headers = lines[0];
    const sampleRows = lines.slice(1, 6).join('\n');
    return `${headers}\n${sampleRows}`;
  }, [csvContent]);

  const handleFileLoad = useCallback((content: string, fileName: string) => {
    setCsvContent(content);
    setCsvFileName(fileName);
    setSelectedQuestion(null);
    setInstructions({});
    setLoadingStates({});
    setErrorStates({});
  }, []);

  const handleQuestionSelect = useCallback(async (question: Question) => {
    setSelectedQuestion(question);
    if (instructions[question.id] || loadingStates[question.id]) {
      return;
    }

    if (!csvSample) {
      setErrorStates(prev => ({ ...prev, [question.id]: 'Please upload a CSV file first.' }));
      return;
    }

    setLoadingStates(prev => ({ ...prev, [question.id]: true }));
    setErrorStates(prev => ({ ...prev, [question.id]: null }));

    try {
      const result = await generateInstructions(csvSample, question.text);
      setInstructions(prev => ({ ...prev, [question.id]: result }));
    } catch (err) {
      console.error(err);
      setErrorStates(prev => ({ ...prev, [question.id]: 'Failed to generate instructions. Please try again.' }));
    } finally {
      setLoadingStates(prev => ({ ...prev, [question.id]: false }));
    }
  }, [csvSample, instructions, loadingStates]);
  
  const handleDownloadAll = useCallback(async () => {
    if (!csvSample) {
      alert('Please upload a CSV file before downloading.');
      return;
    }

    setIsDownloading(true);
    setDownloadProgress(0);

    const allInstructions: Record<string, string> = {};
    const totalQuestions = ALL_QUESTIONS.length;

    for (let i = 0; i < totalQuestions; i++) {
        const question = ALL_QUESTIONS[i];
        const fileName = `Q${question.id}_${question.text.substring(0, 50).replace(/ /g, '_')}.md`;

        try {
            if (instructions[question.id]) {
                allInstructions[fileName] = instructions[question.id];
            } else {
                const result = await generateInstructions(csvSample, question.text);
                setInstructions(prev => ({...prev, [question.id]: result}));
                allInstructions[fileName] = result;
            }
        } catch (err) {
            console.error(`Failed to generate instructions for Q${question.id}:`, err);
            allInstructions[fileName] = `Error: Could not generate instructions for this question.`;
        }
        setDownloadProgress(((i + 1) / totalQuestions) * 100);
    }
    
    await createAndDownloadZip(allInstructions, "PowerBI_Instructions.zip");
    
    setIsDownloading(false);
  }, [csvSample, instructions]);


  return (
    <div className="flex h-screen bg-gray-900 text-gray-200 font-sans">
      {/* Left Sidebar */}
      <aside className="w-80 flex-shrink-0 bg-gray-800 p-6 flex flex-col space-y-6 overflow-y-auto">
        <Header />
        <FileUpload onFileLoad={handleFileLoad} fileName={csvFileName} />
        <div className="flex-grow"></div>
        <button
          onClick={handleDownloadAll}
          disabled={!csvContent || isDownloading}
          className="w-full flex items-center justify-center py-3 px-4 bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-600 disabled:cursor-not-allowed rounded-lg font-semibold transition-all duration-200 shadow-lg"
        >
          {isDownloading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Generating... ({Math.round(downloadProgress)}%)
            </>
          ) : (
            <>
              <DownloadIcon className="w-5 h-5 mr-2" />
              Download All as ZIP
            </>
          )}
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex overflow-hidden">
        <div className="w-2/5 border-l border-r border-gray-700 overflow-y-auto">
           <QuestionList 
             questions={ALL_QUESTIONS}
             onQuestionSelect={handleQuestionSelect}
             selectedQuestionId={selectedQuestion?.id}
             generatedQuestionIds={Object.keys(instructions).map(Number)}
             disabled={!csvContent}
           />
        </div>
        <div className="w-3/5 overflow-y-auto">
           <InstructionPanel 
             question={selectedQuestion}
             instruction={selectedQuestion ? instructions[selectedQuestion.id] : null}
             isLoading={selectedQuestion ? loadingStates[selectedQuestion.id] : false}
             error={selectedQuestion ? errorStates[selectedQuestion.id] : null}
             isReady={!!csvContent}
           />
        </div>
      </main>
    </div>
  );
}
