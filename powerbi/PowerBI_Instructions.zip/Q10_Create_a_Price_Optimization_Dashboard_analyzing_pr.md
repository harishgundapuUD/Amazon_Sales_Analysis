Here's a comprehensive guide to building your Price Optimization Dashboard in Power BI, tailored for a user new to the platform.

---

## Price Optimization Dashboard in Power BI

### 1. Objective

The primary goal of this dashboard is to provide a comprehensive view of pricing strategies, their effectiveness, and their impact on key business metrics. It aims to help analyze:
*   **Price Elasticity:** How changes in price or discount affect sales volume.
*   **Discount Effectiveness:** The revenue and quantity impact of applying discounts.
*   **Competitive Pricing (Internal Proxy):** How internal pricing compares across categories, brands, or customer segments. (True competitive pricing requires external data, but this dashboard will analyze internal pricing dynamics).
*   **Revenue Impact:** The overall financial outcomes of different pricing approaches.

### 2. Data Loading & Preparation

#### Step 2.1: Load Data into Power BI

1.  **Open Power BI Desktop.**
2.  Go to the **Home** tab in the ribbon.
3.  Click on **Get Data** -> **Text/CSV**.
4.  Navigate to your CSV file, select it, and click **Open**.
5.  In the preview window, Power BI will automatically detect the delimiter. Ensure "Comma" is selected.
6.  Click **Transform Data**. This will open the Power Query Editor.

#### Step 2.2: Data Cleaning and Transformation in Power Query Editor

The Power Query Editor is where you clean and shape your data before loading it into your Power BI model.

1.  **Rename Table:** In the "Query Settings" pane on the right, under "Name," rename `Query1` (or whatever it's called) to `Sales Transactions`.
2.  **Review and Set Data Types:** This is crucial for correct calculations and visualizations. Power BI often auto-detects, but it's good practice to verify.
    *   Select each column header.
    *   Go to the **Transform** tab, then click on **Data Type** and select the appropriate type.
    *   **`transaction_id`**, **`customer_id`**, **`product_id`**: Text
    *   **`product_name`**, **`subcategory`**, **`brand`**, **`customer_state`**, **`customer_tier`**, **`customer_spending_tier`**, **`customer_age_group`**, **`delivery_type`**, **`festival_name`**, **`return_status`**, **`cleaned_customer_city`**, **`cleaned_category`**, **`duplicate_type`**, **`standard_payment_method`**: Text
    *   **`quantity`**: Whole Number
    *   **`order_month`**, **`order_year`**, **`order_quarter`**: Whole Number
    *   **`product_weight_kg`**: Decimal Number
    *   **`clean_order_date`**: Date (make sure it's `Date` type, not `Date/Time`)
    *   **`clean_original_price_inr`**, **`clean_discount_percent`**, **`clean_final_amount_inr`**, **`clean_delivery_charges`**, **`corrected_price`**: Decimal Number
    *   **`cleaned_customer_rating`**, **`cleaned_product_rating`**: Decimal Number. *Handling Nulls*: For these columns, `AVERAGE` DAX functions automatically ignore nulls, so you can leave them as is. If you prefer to replace nulls (e.g., with 0 or a median), select the column, go to **Transform** -> **Replace Values**, leave "Value to Find" blank (for nulls), and enter your replacement value. However, for ratings, keeping nulls is generally better for accurate averages.
    *   **`cleaned_is_prime_member`**, **`cleaned_is_prime_eligible`**, **`cleaned_is_festival_sale`**: True/False
    *   **`cleaned_delivery_days`**: Decimal Number

3.  **Create New Columns (Optional but Recommended for Analysis):**
    *   **`Unit Selling Price`**: This is the price per unit after discount.
        *   Go to **Add Column** tab -> **Custom Column**.
        *   **New column name**: `Unit Selling Price`
        *   **Custom column formula**: `if [quantity] = 0 then 0 else [clean_final_amount_inr] / [quantity]` (This handles potential division by zero).
        *   Ensure its data type is **Decimal Number**.
    *   **`Discount Amount Per Unit`**: The actual monetary discount applied per unit.
        *   Go to **Add Column** tab -> **Custom Column**.
        *   **New column name**: `Discount Amount Per Unit`
        *   **Custom column formula**: `[clean_original_price_inr] * [clean_discount_percent] / 100`
        *   Ensure its data type is **Decimal Number**.
    *   **`Discount Category`**: To group discounts for easier analysis.
        *   Go to **Add Column** tab -> **Custom Column**.
        *   **New column name**: `Discount Category`
        *   **Custom column formula**:
            ```
            if [clean_discount_percent] = 0 then "No Discount"
            else if [clean_discount_percent] < 10 then "0-10% Discount"
            else if [clean_discount_percent] < 25 then "10-25% Discount"
            else if [clean_discount_percent] < 50 then "25-50% Discount"
            else "50%+ Discount"
            ```
        *   Ensure its data type is **Text**.

4.  Once all transformations are complete, click **Close & Apply** on the **Home** tab to load the data into Power BI Desktop.

### 3. Data Modeling

#### Step 3.1: Create a Date Table

A separate Date table is crucial for robust time-intelligence calculations and filtering.

1.  Go to the **Table Tools** tab (it appears when you select a table in the "Data" view).
2.  Click on **New Table**.
3.  Enter the following DAX formula in the formula bar:

    ```dax
    Date Table = 
    VAR MinDate = CALCULATE(MIN('Sales Transactions'[clean_order_date]), ALL('Sales Transactions'))
    VAR MaxDate = CALCULATE(MAX('Sales Transactions'[clean_order_date]), ALL('Sales Transactions'))
    RETURN
        ADDCOLUMNS(
            CALENDAR(MinDate, MaxDate),
            "Year", YEAR([Date]),
            "Month Number", MONTH([Date]),
            "Month Name", FORMAT([Date], "MMM"),
            "Quarter", "Q" & FORMAT([Date], "Q"),
            "Day of Week", FORMAT([Date], "dddd"),
            "Weekday", WEEKDAY([Date], 2) // Monday=1, Sunday=7
        )
    ```

4.  After the table is created, select the `Date` column in the `Date Table`. In the "Column tools" ribbon, click **Mark as Date table** and select `Date` again.

#### Step 3.2: Create Relationships

1.  Go to the **Model View** (the icon with three interconnected tables on the left pane).
2.  Drag the `Date` column from the `Date Table` and drop it onto the `clean_order_date` column in the `Sales Transactions` table.
3.  This will create a one-to-many relationship (`1` on `Date Table` to `*` on `Sales Transactions`). Ensure the cross-filter direction is **Single**.

### 4. DAX Measures

These measures will be the backbone of your dashboard, providing the calculations needed for insights. To create a measure, right-click on your `Sales Transactions` table in the "Fields" pane and select "New Measure."

1.  **Total Sales Quantity:**
    ```dax
    Total Sales Quantity = SUM('Sales Transactions'[quantity])
    ```
    *Explanation: Total number of products sold across all transactions.*

2.  **Total Revenue (INR):**
    ```dax
    Total Revenue (INR) = SUM('Sales Transactions'[clean_final_amount_inr])
    ```
    *Explanation: Total revenue generated after discounts and before delivery charges.*

3.  **Gross Revenue (INR):**
    ```dax
    Gross Revenue (INR) = SUMX('Sales Transactions', 'Sales Transactions'[clean_original_price_inr] * 'Sales Transactions'[quantity])
    ```
    *Explanation: Total revenue if no discounts were applied (original price * quantity).*

4.  **Total Discount Amount (INR):**
    ```dax
    Total Discount Amount (INR) = [Gross Revenue (INR)] - [Total Revenue (INR)]
    ```
    *Explanation: The total monetary value of discounts given.*

5.  **Average Discount %:**
    ```dax
    Average Discount % = AVERAGEX(
        FILTER('Sales Transactions', 'Sales Transactions'[clean_discount_percent] > 0),
        'Sales Transactions'[clean_discount_percent]
    )
    ```
    *Explanation: Average discount percentage applied, considering only transactions where a discount was given. If you want to include 0% discounts, remove the `FILTER` part.*

6.  **Overall Discount Rate %:**
    ```dax
    Overall Discount Rate % = DIVIDE([Total Discount Amount (INR)], [Gross Revenue (INR)])
    ```
    *Explanation: The overall discount rate across all sales, including non-discounted items.*

7.  **Average Original Price per Unit:**
    ```dax
    Average Original Price per Unit = AVERAGEX('Sales Transactions', 'Sales Transactions'[clean_original_price_inr])
    ```
    *Explanation: Average original selling price per unit.*

8.  **Average Selling Price per Unit:**
    ```dax
    Average Selling Price per Unit = AVERAGEX('Sales Transactions', 'Sales Transactions'[Unit Selling Price])
    ```
    *Explanation: Average price at which a unit was actually sold (after discount).*

9.  **Revenue from Discounted Products:**
    ```dax
    Revenue from Discounted Products = 
    CALCULATE(
        [Total Revenue (INR)], 
        'Sales Transactions'[clean_discount_percent] > 0
    )
    ```
    *Explanation: Total revenue generated only from products that had a discount.*

10. **Revenue from Full Price Products:**
    ```dax
    Revenue from Full Price Products = 
    CALCULATE(
        [Total Revenue (INR)], 
        'Sales Transactions'[clean_discount_percent] = 0
    )
    ```
    *Explanation: Total revenue generated only from products sold at their original price.*

11. **Unique Customers:**
    ```dax
    Unique Customers = DISTINCTCOUNT('Sales Transactions'[customer_id])
    ```
    *Explanation: Number of distinct customers who made purchases.*

12. **Unique Products Sold:**
    ```dax
    Unique Products Sold = DISTINCTCOUNT('Sales Transactions'[product_id])
    ```
    *Explanation: Number of distinct products sold.*

13. **Average Customer Rating:**
    ```dax
    Average Customer Rating = AVERAGE('Sales Transactions'[cleaned_customer_rating])
    ```
    *Explanation: Average rating given by customers. Nulls are ignored.*

14. **Average Product Rating:**
    ```dax
    Average Product Rating = AVERAGE('Sales Transactions'[cleaned_product_rating])
    ```
    *Explanation: Average rating of products. Nulls are ignored.*

15. **Return Rate %:**
    ```dax
    Return Rate % = 
    DIVIDE(
        CALCULATE(
            COUNTROWS('Sales Transactions'),
            'Sales Transactions'[return_status] = "Returned" // Assuming "Returned" is the status for a return
        ),
        COUNTROWS('Sales Transactions')
    )
    ```
    *Explanation: Percentage of transactions that were returned.*

### 5. Visualization

Let's design a multi-page dashboard.

#### Page 1: Executive Summary & Key Performance Indicators (KPIs)

*   **Objective:** Provide a high-level overview of sales and pricing performance.

1.  **Card Visuals (Top Left):**
    *   **Total Revenue (INR)**: Use `Total Revenue (INR)` measure. Format to currency.
    *   **Total Sales Quantity**: Use `Total Sales Quantity` measure.
    *   **Unique Customers**: Use `Unique Customers` measure.
    *   **Overall Discount Rate %**: Use `Overall Discount Rate %` measure. Format to percentage.
    *   **Average Selling Price per Unit**: Use `Average Selling Price per Unit` measure. Format to currency.
    *   **Return Rate %**: Use `Return Rate %` measure. Format to percentage.

2.  **Line Chart (Revenue Trend):**
    *   **X-axis:** `Date Table[Date]` (drill down to month/quarter).
    *   **Y-axis:** `Total Revenue (INR)`.
    *   *Insight:* Shows revenue fluctuation over time.

3.  **Clustered Bar Chart (Revenue by Category):**
    *   **X-axis:** `Total Revenue (INR)`.
    *   **Y-axis:** `Sales Transactions[cleaned_category]`.
    *   *Insight:* Identifies top-performing product categories.

4.  **100% Stacked Bar Chart (Revenue: Discounted vs. Full Price):**
    *   **X-axis:** `Total Revenue (INR)`.
    *   **Y-axis:** `Date Table[Year]` or `Date Table[Month Name]`.
    *   **Legend:** `Discount Category` (created in Power Query).
    *   *Insight:* Shows the proportion of revenue coming from discounted vs. full-price sales over time.

#### Page 2: Discount Effectiveness Analysis

*   **Objective:** Deep dive into how discounts impact sales and customer behavior.

1.  **Clustered Column Chart (Revenue by Discount Category):**
    *   **X-axis:** `Sales Transactions[Discount Category]`.
    *   **Y-axis:** `Total Revenue (INR)`.
    *   *Insight:* Directly compares revenue generated from different discount tiers. Add `Total Sales Quantity` as a secondary Y-axis if needed.

2.  **Line Chart with secondary Y-axis (Average Price & Quantity by Brand):**
    *   **X-axis:** `Sales Transactions[brand]`.
    *   **Primary Y-axis:** `Average Selling Price per Unit`.
    *   **Secondary Y-axis:** `Total Sales Quantity`.
    *   *Insight:* Visually inspect if lower average selling prices for a brand correlate with higher sales quantities, hinting at elasticity.

3.  **Table/Matrix Visual (Product-level Discount Impact):**
    *   **Rows:** `Sales Transactions[product_name]`.
    *   **Values:** `Total Revenue (INR)`, `Total Sales Quantity`, `Average Discount %`, `Average Original Price per Unit`, `Average Selling Price per Unit`, `Average Product Rating`.
    *   *Insight:* Allows detailed review of individual product performance under various discount levels. Conditional formatting can highlight high/low discount rates.

4.  **Donut Chart (Sales by Festival Sale):**
    *   **Values:** `Total Sales Quantity` or `Total Revenue (INR)`.
    *   **Legend:** `Sales Transactions[cleaned_is_festival_sale]`.
    *   *Insight:* Quantifies the impact of festival sales.

#### Page 3: Price Elasticity Observation & Impact

*   **Objective:** Observe potential price elasticity and the relationship between price changes and quantity. (Note: True price elasticity requires advanced statistical methods, but this visual will help *identify areas* for further investigation).

1.  **Scatter Plot (Quantity vs. Selling Price):**
    *   **X-axis:** `Average Selling Price per Unit`.
    *   **Y-axis:** `Total Sales Quantity`.
    *   **Legend/Details:** `Sales Transactions[product_name]` or `Sales Transactions[subcategory]`.
    *   **Size:** `Total Revenue (INR)`.
    *   *Insight:* This is your primary visual for price elasticity observation. Look for downward-sloping clusters: as price decreases (left on X-axis), quantity increases (up on Y-axis). Products with steep downward slopes might be more elastic.
    *   *Tip:* Add a trend line to observe general patterns.

2.  **Area Chart (Sales Quantity vs. Discount % over Time):**
    *   **X-axis:** `Date Table[Month Name]` (and drill down to day).
    *   **Y-axis (Primary):** `Total Sales Quantity`.
    *   **Y-axis (Secondary):** `Average Discount %`.
    *   *Insight:* See if spikes in discount percentages lead to spikes in sales quantity.

3.  **Clustered Column Chart (Avg. Selling Price by Customer Tier):**
    *   **X-axis:** `Sales Transactions[customer_tier]`.
    *   **Y-axis:** `Average Selling Price per Unit`.
    *   *Insight:* Compare average selling prices across different customer tiers to understand if premium customers are getting different pricing or if pricing strategies are uniform.

4.  **Matrix Visual (Product Performance by Customer Segment):**
    *   **Rows:** `Sales Transactions[product_name]`.
    *   **Columns:** `Sales Transactions[customer_spending_tier]`.
    *   **Values:** `Total Revenue (INR)`, `Total Sales Quantity`.
    *   *Insight:* Understand which products are popular with which spending tiers and at what revenue/quantity.

#### Layout and Design Tips:

*   **Consistent Branding:** Use a consistent color scheme, fonts, and logos (if any).
*   **Clear Titles:** Each page and visual should have a descriptive title.
*   **Intuitive Layout:** Arrange visuals logically. Place KPIs at the top, trends below, and detailed analysis further down or on subsequent pages.
*   **White Space:** Don't cram too many visuals on one page. Use white space effectively to make the dashboard easy to read.
*   **Tooltips:** Customize tooltips for your visuals to show additional relevant data when hovering.
*   **Background:** Consider using a light background color or a subtle background image.

### 6. Interactivity

#### 6.1: Slicers

Slicers allow users to filter the entire dashboard interactively. Place them predominantly on the left side or top of each page.

1.  **Date Slicer:**
    *   Use the `Date Table[Year]` or `Date Table[Month Name]` for filtering. A relative date slicer can also be useful (e.g., "Last 30 days").
    *   Set it to "List" or "Dropdown" format.
2.  **Category Slicer:**
    *   Use `Sales Transactions[cleaned_category]`.
3.  **Brand Slicer:**
    *   Use `Sales Transactions[brand]`.
4.  **Customer Slicers:**
    *   `Sales Transactions[customer_tier]`
    *   `Sales Transactions[customer_age_group]`
    *   `Sales Transactions[customer_spending_tier]`
5.  **Festival Sale Slicer:**
    *   `Sales Transactions[cleaned_is_festival_sale]` (Boolean - True/False)
6.  **Discount Category Slicer:**
    *   `Sales Transactions[Discount Category]` (The custom column you created).

#### 6.2: Sync Slicers

To have slicers filter across multiple pages:
1.  Select a slicer.
2.  Go to the **View** tab -> **Sync Slicers**.
3.  In the "Sync Slicers" pane, check the boxes for all pages where you want that slicer to apply.

#### 6.3: Cross-Filtering

By default, clicking on a data point in one visual will cross-filter other visuals on the same page. This is a powerful feature:
*   Click on a specific brand in a bar chart, and all other visuals will show data only for that brand.
*   To change this interaction (e.g., from highlight to filter, or to turn off interaction), select a visual, go to the **Format** tab -> **Edit interactions**, and adjust the icons on other visuals.

#### 6.4: Drill-Through (Optional)

If you wanted to dive deeper into specific transactions for a product:
1.  Create a new blank page (e.g., "Product Details").
2.  Add a **Table visual** to this page with detailed fields like `transaction_id`, `product_name`, `customer_id`, `clean_final_amount_inr`, `clean_discount_percent`, `quantity`, etc.
3.  Drag `Sales Transactions[product_id]` (or `product_name`) to the "Drill-through fields" section of the "Visualizations" pane on the "Product Details" page.
4.  Now, on other pages, when you right-click on a data point (e.g., a bar representing a product), you'll see a "Drill through" option, allowing you to jump to the "Product Details" page filtered for that specific product.

By following these steps, you'll be able to create a powerful and insightful Price Optimization Dashboard in Power BI, empowering you to make data-driven decisions about your pricing strategies.