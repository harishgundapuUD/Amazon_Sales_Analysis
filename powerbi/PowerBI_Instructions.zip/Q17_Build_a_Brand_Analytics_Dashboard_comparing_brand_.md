As a world-class Power BI and data analytics consultant, I'm delighted to guide you through building a comprehensive Brand Analytics Dashboard. This dashboard will provide deep insights into brand performance, market share, customer preferences, and competitive positioning using your provided dataset.

---

## 1. Objective

The primary goal of this dashboard is to provide a holistic view of brand performance. It will enable users to compare brands based on sales revenue, quantity sold, market share evolution, customer demographics and spending habits, and how they stack up against competitors across various product categories and over time.

---

## 2. Data Loading & Preparation

This section will walk you through bringing your CSV data into Power BI and preparing it for analysis using Power Query Editor.

### 2.1. Load Data into Power BI

1.  **Open Power BI Desktop.**
2.  On the Home tab, click **"Get Data"**.
3.  Select **"Text/CSV"** from the common data sources, then click **"Connect"**.
4.  Browse to your CSV file, select it, and click **"Open"**.
5.  Power BI will display a preview of your data. Ensure "Comma" is selected as the Delimiter and "Based on first 200 rows" or "Entire dataset" for Data Type Detection.
6.  Click **"Transform Data"**. This will open the Power Query Editor, where we'll clean and transform the data.

### 2.2. Power Query Editor Transformations

In the Power Query Editor, follow these steps to ensure your data is clean and in the correct format for analysis.

#### A. Rename Table

1.  In the "Query Settings" pane on the right, under "Properties," rename the query from `your_csv_filename` to `Sales`. This makes it easier to reference.

#### B. Change Data Types

Correct data types are crucial for proper calculations and filtering. Go through each column and set its data type:

1.  **Select a column** by clicking its header.
2.  **Click the data type icon** (e.g., "ABC" for text, "123" for number) next to the column name in the header.
3.  **Choose the appropriate data type** from the dropdown menu.

Here's a list of recommended data types for your columns:

*   `transaction_id`: **Text**
*   `customer_id`: **Text**
*   `product_id`: **Text**
*   `product_name`: **Text**
*   `subcategory`: **Text**
*   `brand`: **Text**
*   `quantity`: **Whole Number**
*   `customer_state`: **Text**
*   `customer_tier`: **Text**
*   `customer_spending_tier`: **Text**
*   `customer_age_group`: **Text**
*   `delivery_type`: **Text**
*   `festival_name`: **Text**
*   `return_status`: **Text**
*   `order_month`: **Whole Number**
*   `order_year`: **Whole Number**
*   `order_quarter`: **Whole Number**
*   `product_weight_kg`: **Decimal Number**
*   `clean_order_date`: **Date** (Important for date intelligence)
*   `clean_original_price_inr`: **Decimal Number**
*   `clean_discount_percent`: **Decimal Number** (As a percentage, will be `0.25` for 25%)
*   `clean_final_amount_inr`: **Decimal Number**
*   `clean_delivery_charges`: **Decimal Number**
*   `cleaned_customer_rating`: **Decimal Number**
*   `cleaned_product_rating`: **Decimal Number**
*   `cleaned_customer_city`: **Text**
*   `cleaned_is_prime_member`: **True/False** (or Boolean)
*   `cleaned_is_prime_eligible`: **True/False** (or Boolean)
*   `cleaned_is_festival_sale`: **True/False** (or Boolean)
*   `cleaned_category`: **Text**
*   `cleaned_delivery_days`: **Decimal Number**
*   `duplicate_type`: **Text**
*   `corrected_price`: **Decimal Number**
*   `standard_payment_method`: **Text**

#### C. Handle Null Values

Some columns might have blank or null values that need attention:

1.  **`festival_name`**: If nulls indicate no festival sale, you can replace them.
    *   Select the `festival_name` column.
    *   Right-click the column header and choose **"Replace Values..."**.
    *   In "Value To Find," leave it blank (or type `null` if it appears as text). In "Replace With," type **"No Sale Event"**. Click OK.
2.  **`clean_delivery_charges`**: If nulls mean free delivery, replace with 0.
    *   Select the `clean_delivery_charges` column.
    *   Right-click and choose **"Replace Values..."**.
    *   Leave "Value To Find" blank, enter **`0`** in "Replace With." Click OK.
3.  **`cleaned_customer_rating`** and **`cleaned_product_rating`**: `AVERAGE` functions in DAX will automatically ignore nulls, so no explicit replacement is needed unless you want to treat missing ratings as 0 or another value. For now, leave them as is.

#### D. Create New Columns (Custom Columns)

These columns will enrich your analysis:

1.  **Discount Amount:**
    *   Go to the **"Add Column"** tab.
    *   Click **"Custom Column"**.
    *   **New column name:** `Discount Amount`
    *   **Custom column formula:** `([clean_original_price_inr] * [quantity]) - [clean_final_amount_inr]`
    *   Click OK. Change its data type to **Decimal Number**.

2.  **Order Day of Week:** (Optional, useful for daily trends)
    *   Select the `clean_order_date` column.
    *   Go to the **"Add Column"** tab.
    *   Click **"Date" -> "Day" -> "Name of Day"**. This will add a new column with the day name (e.g., "Monday").

#### E. Review and Apply Changes

1.  Review the "Applied Steps" pane on the right to ensure all transformations are recorded correctly.
2.  On the Home tab, click **"Close & Apply"**. This will load the transformed data into your Power BI data model.

---

## 3. Data Modeling

We'll create a dedicated date table to enable powerful time-intelligence calculations and ensure proper relationships.

### 3.1. Create a Date Table (DimDate)

A separate date table is a best practice in Power BI.

1.  Go to the **"Table view"** (the table icon on the left navigation pane).
2.  On the Home tab, click **"New Table"**.
3.  Enter the following DAX formula to create your `DimDate` table:

    ```dax
    DimDate =
    VAR MinDate = CALCULATE(MIN(Sales[clean_order_date]), ALL(Sales))
    VAR MaxDate = CALCULATE(MAX(Sales[clean_order_date]), ALL(Sales))
    RETURN
        ADDCOLUMNS (
            CALENDAR (MinDate, MaxDate),
            "Year", YEAR ( [Date] ),
            "MonthNum", MONTH ( [Date] ),
            "Month", FORMAT ( [Date], "MMM" ),
            "Month-Year", FORMAT ( [Date], "MMM-YYYY" ),
            "Quarter", "Q" & FORMAT ( [Date], "Q" ),
            "Day", DAY ( [Date] ),
            "DayOfWeekNum", WEEKDAY ( [Date], 2 ),
            "DayOfWeek", FORMAT ( [Date], "ddd" ),
            "DateKey", FORMAT([Date], "YYYYMMDD")
        )
    ```
4.  Press Enter to create the table.
5.  Once `DimDate` is created, select the `DimDate` table in the Fields pane.
6.  Go to the **"Table tools"** tab in the ribbon.
7.  Click **"Mark as date table"** and select the `Date` column as the Date table column. Click OK.

### 3.2. Create Relationships

Establish a relationship between your `Sales` fact table and the new `DimDate` dimension table.

1.  Go to the **"Model view"** (the model icon on the left navigation pane).
2.  You should see your `Sales` table and the `DimDate` table.
3.  **Drag the `clean_order_date` column from the `Sales` table** and **drop it onto the `Date` column in the `DimDate` table.**
4.  Power BI will automatically create a "Many-to-one" (*:1) relationship, with cross-filter direction set to "Single." This is correct.

---

## 4. DAX Measures

Measures are essential for calculating aggregated values and KPIs. Go to the **"Report view"** (the report icon on the left) and click **"New Measure"** on the Home tab for each of these. Store them in your `Sales` table.

### A. Core Sales & Quantity Measures

1.  **Total Sales Revenue:**
    ```dax
    Total Sales Revenue = SUM(Sales[clean_final_amount_inr])
    ```
    *Explanation:* Calculates the sum of the final amount for all transactions, representing total revenue.

2.  **Total Quantity Sold:**
    ```dax
    Total Quantity Sold = SUM(Sales[quantity])
    ```
    *Explanation:* Calculates the total number of products sold across all transactions.

3.  **Number of Orders:**
    ```dax
    Number of Orders = DISTINCTCOUNT(Sales[transaction_id])
    ```
    *Explanation:* Counts the number of unique transactions/orders.

4.  **Number of Unique Customers:**
    ```dax
    Number of Unique Customers = DISTINCTCOUNT(Sales[customer_id])
    ```
    *Explanation:* Counts the number of unique customers who made purchases.

### B. Financial & Rating Measures

5.  **Total Discount Amount:**
    ```dax
    Total Discount Amount = SUM(Sales[Discount Amount])
    ```
    *Explanation:* Calculates the total monetary value of discounts given.

6.  **Average Discount % (per item):**
    ```dax
    Average Discount % = AVERAGE(Sales[clean_discount_percent])
    ```
    *Explanation:* Calculates the average discount percentage applied across all line items. Format as Percentage.

7.  **Average Customer Rating:**
    ```dax
    Average Customer Rating = AVERAGE(Sales[cleaned_customer_rating])
    ```
    *Explanation:* Calculates the average customer rating.

8.  **Average Product Rating:**
    ```dax
    Average Product Rating = AVERAGE(Sales[cleaned_product_rating])
    ```
    *Explanation:* Calculates the average product rating.

9.  **Total Delivery Charges:**
    ```dax
    Total Delivery Charges = SUM(Sales[clean_delivery_charges])
    ```
    *Explanation:* Sums up all delivery charges incurred.

### C. Brand & Market Share Measures

10. **Brand Market Share (by Revenue):**
    ```dax
    Brand Market Share (by Revenue) =
    DIVIDE(
        [Total Sales Revenue],
        CALCULATE(
            [Total Sales Revenue],
            ALLSELECTED(Sales[brand])
        )
    )
    ```
    *Explanation:* This calculates the percentage of total sales revenue contributed by the current brand within the context of *all selected brands* (e.g., if you have a category filter, it will be market share within that category). Format as Percentage.

11. **Avg. Spending per Customer (Brand):**
    ```dax
    Avg. Spending per Customer (Brand) =
    DIVIDE(
        [Total Sales Revenue],
        [Number of Unique Customers]
    )
    ```
    *Explanation:* Calculates the average revenue generated per unique customer for a given brand or filtered context.

---

## 5. Visualization

Let's design the dashboard with key visuals to answer your analytical questions.

### 5.1. Dashboard Layout and Design Tips

*   **Header:** Use a Text Box for the dashboard title: "Brand Analytics Dashboard."
*   **Filters Pane:** Dedicate a section on the left or top for slicers.
*   **Logical Grouping:** Arrange related visuals together.
*   **Consistent Styling:** Use a consistent color palette, font sizes, and visual styles.
*   **White Space:** Don't overcrowd the canvas. Allow some breathing room.
*   **Tooltips:** Enhance tooltips for more detailed info on hover.

### 5.2. Recommended Visuals

Here are the specific visuals for each objective:

#### A. Overall KPIs & Brand Performance

1.  **Total Sales Revenue Card:**
    *   **Visual Type:** Card
    *   **Fields:** `Total Sales Revenue` measure.
    *   **Formatting:** Increase font size, add a title "Total Sales Revenue."

2.  **Total Quantity Sold Card:**
    *   **Visual Type:** Card
    *   **Fields:** `Total Quantity Sold` measure.
    *   **Formatting:** Similar to Revenue Card.

3.  **Number of Unique Customers Card:**
    *   **Visual Type:** Card
    *   **Fields:** `Number of Unique Customers` measure.

4.  **Average Product Rating Card:**
    *   **Visual Type:** Card
    *   **Fields:** `Average Product Rating` measure.
    *   **Formatting:** You might want to display one decimal place.

5.  **Top 10 Brands by Sales Revenue (Bar Chart):**
    *   **Visual Type:** Clustered Bar Chart
    *   **Axis (Y-axis):** `brand` from `Sales` table.
    *   **Values (X-axis):** `Total Sales Revenue` measure.
    *   **Filter:** Apply a "Top N" filter on `brand` (Top 10 by `Total Sales Revenue`).
    *   **Insight:** Quickly identify leading brands.

6.  **Revenue Trend by Brand (Line Chart):**
    *   **Visual Type:** Line Chart
    *   **X-axis:** `Month-Year` from `DimDate` (drag `Date` and select `Month-Year` from the hierarchy options).
    *   **Y-axis:** `Total Sales Revenue` measure.
    *   **Legend:** `brand` from `Sales` table.
    *   **Insight:** Shows how individual brands' sales have evolved over time.

#### B. Market Share Evolution

1.  **Current Market Share by Brand (Donut Chart):**
    *   **Visual Type:** Donut Chart
    *   **Legend:** `brand` from `Sales` table.
    *   **Values:** `Total Sales Revenue` measure.
    *   **Insight:** Visualizes the current distribution of market share among brands based on revenue.

2.  **Market Share Trend Over Time (Stacked Area Chart):**
    *   **Visual Type:** Stacked Area Chart
    *   **X-axis:** `Month-Year` from `DimDate`.
    *   **Y-axis:** `Brand Market Share (by Revenue)` measure.
    *   **Legend:** `brand` from `Sales` table.
    *   **Insight:** Shows how each brand's market share percentage has changed over time.

#### C. Customer Preferences

1.  **Revenue by Customer Age Group & Brand (Stacked Column Chart):**
    *   **Visual Type:** 100% Stacked Column Chart
    *   **X-axis:** `customer_age_group` from `Sales`.
    *   **Y-axis:** `Total Sales Revenue` measure.
    *   **Legend:** `brand` from `Sales`.
    *   **Insight:** Understand which age groups prefer which brands or categories.

2.  **Revenue by Customer Tier & Brand (Clustered Column Chart):**
    *   **Visual Type:** Clustered Column Chart
    *   **Axis (X-axis):** `customer_tier` from `Sales`.
    *   **Values (Y-axis):** `Total Sales Revenue` measure.
    *   **Legend:** `brand` from `Sales`.
    *   **Insight:** Compare brand performance across different customer loyalty tiers.

3.  **Top Subcategories by Sales Revenue (Treemap):**
    *   **Visual Type:** Treemap
    *   **Category:** `subcategory` from `Sales`.
    *   **Values:** `Total Sales Revenue` measure.
    *   **Insight:** Identify the most revenue-generating subcategories overall, which will react to `brand` filters.

#### D. Competitive Positioning

1.  **Brand Comparison within Category (Clustered Bar Chart):**
    *   **Visual Type:** Clustered Bar Chart
    *   **Axis (Y-axis):** `brand` from `Sales`.
    *   **Values (X-axis):** `Total Sales Revenue` measure.
    *   **Small Multiples:** `cleaned_category` from `Sales` (this allows viewing side-by-side charts for each category if space permits, or rely on a `cleaned_category` slicer).
    *   **Insight:** Compare brands head-to-head on sales performance within specific product categories.

2.  **Average Product Rating by Brand (Bar Chart):**
    *   **Visual Type:** Clustered Bar Chart
    *   **Axis (Y-axis):** `brand` from `Sales`.
    *   **Values (X-axis):** `Average Product Rating` measure.
    *   **Insight:** See which brands have the highest-rated products, indicating product quality perception.

---

## 6. Interactivity

Interactivity transforms your static report into a dynamic analytical tool.

### 6.1. Slicers

Place these slicers prominently on your dashboard, preferably in a dedicated filters pane.

1.  **Date Slicer:**
    *   **Visual Type:** Slicer
    *   **Fields:** `Year` from `DimDate`. You can change the slicer type to "Dropdown" or "List." Add `Quarter` and `Month` as well for granular control.
2.  **Category Slicer:**
    *   **Visual Type:** Slicer
    *   **Fields:** `cleaned_category` from `Sales`.
3.  **Brand Slicer:**
    *   **Visual Type:** Slicer
    *   **Fields:** `brand` from `Sales`.
4.  **Customer Tier Slicer:**
    *   **Visual Type:** Slicer
    *   **Fields:** `customer_tier` from `Sales`.
5.  **Customer Age Group Slicer:**
    *   **Visual Type:** Slicer
    *   **Fields:** `customer_age_group` from `Sales`.
6.  **Customer State Slicer:**
    *   **Visual Type:** Slicer
    *   **Fields:** `customer_state` from `Sales`.

#### Sync Slicers

If you use multiple pages and want a slicer selection to apply across all pages, use the "Sync slicers" pane (View tab -> Sync slicers).

### 6.2. Cross-Filtering and Drill-Down

*   **Cross-Filtering:** By default, clicking on a data point in one visual (e.g., a specific brand in the Donut Chart) will filter and highlight related data in all other visuals on the page. This is incredibly powerful for exploring relationships.
*   **Drill-Down:** For visuals with hierarchies (like the `Date` hierarchy on a line chart), you can click the "Drill down" arrows in the visual header to navigate from Year to Quarter to Month, etc.

By following these comprehensive steps, you will be able to construct a robust and insightful Brand Analytics Dashboard in Power BI, empowering you to answer critical business questions about your brand's performance and market standing.