This guide will help you build a comprehensive Customer Retention Dashboard in Power BI, covering cohort analysis, customer lifecycle, and insights into strategies, designed for users new to Power BI.

---

## 1. Objective

The primary objective of this dashboard is to provide a holistic view of customer retention. It will enable users to:
*   Track customer retention rates over time using cohort analysis.
*   Identify periods of high/low retention and understand underlying factors.
*   Segment customers by various attributes (e.g., age, tier, spending) to reveal retention patterns.
*   Gain insights into customer lifecycle stages and potential churn indicators.
*   Evaluate the effectiveness of certain sales events or delivery types on initial customer engagement and retention.

---

## 2. Data Loading & Preparation

Before building any visuals, we need to load your CSV data and perform essential cleaning and transformations in Power Query Editor.

### 2.1 Load Data

1.  **Open Power BI Desktop.**
2.  On the Home tab, click **"Get data"**.
3.  Select **"Text/CSV"** from the list and click **"Connect"**.
4.  Browse to your CSV file, select it, and click **"Open"**.
5.  In the preview window, Power BI will detect the delimiter and data types. Click **"Transform Data"** to open Power Query Editor.

### 2.2 Power Query Editor Transformations

The Power Query Editor is where you'll clean and shape your data.

1.  **Rename Table:**
    *   In the "Query Settings" pane on the right, under "Name," change "transaction_data" (or similar) to `Sales`.

2.  **Change Data Types:**
    *   Select the following columns and change their data type to **"Date"**:
        *   `clean_order_date`
    *   Select the following columns and change their data type to **"Whole Number"**:
        *   `quantity`
        *   `order_month`
        *   `order_year`
        *   `order_quarter`
    *   Select the following columns and change their data type to **"Decimal Number"**:
        *   `product_weight_kg`
        *   `clean_original_price_inr`
        *   `clean_discount_percent`
        *   `clean_final_amount_inr`
        *   `clean_delivery_charges`
        *   `corrected_price`
        *   `cleaned_customer_rating`
        *   `cleaned_product_rating`
        *   `cleaned_delivery_days`
    *   Select the following columns and change their data type to **"True/False"**:
        *   `cleaned_is_prime_member`
        *   `cleaned_is_prime_eligible`
        *   `cleaned_is_festival_sale`

3.  **Handle Missing Values (Nulls):**
    *   For `festival_name`:
        *   Select the `festival_name` column.
        *   Go to the "Transform" tab, click **"Replace Values"**.
        *   In "Value to Find," type `null` (or leave blank if it's an empty string).
        *   In "Replace With," type `No Specific Sale`. Click **"OK"**.
    *   For `cleaned_customer_rating` and `cleaned_product_rating`:
        *   These ratings are important. If `null` implies "not rated", replacing with 0 might skew averages. It's often better to either leave as null (and handle in DAX if averaging) or replace with an appropriate value like the median/average. For simplicity, we'll replace with 0 for now.
        *   Select `cleaned_customer_rating`, click **"Replace Values"**, find `null`, replace with `0`.
        *   Select `cleaned_product_rating`, click **"Replace Values"**, find `null`, replace with `0`.

4.  **Create Key Columns for Cohort Analysis:**
    *   **Identify First Order Date for Each Customer:**
        *   First, make sure `clean_order_date` is sorted ascending.
        *   Go to the **"Add Column"** tab.
        *   Click **"Group By"**.
        *   Select "Basic" option.
        *   **Group by:** `customer_id`
        *   **New column name:** `FirstOrderDate`
        *   **Operation:** `Min`
        *   **Column:** `clean_order_date`
        *   Click **"OK"**. This creates a new table with `customer_id` and their `FirstOrderDate`.
        *   **Merge this back to the `Sales` table:**
            *   Go back to your `Sales` query (click it in the "Queries" pane on the left).
            *   On the **"Home"** tab, click **"Merge Queries"** (or "Merge Queries as New" if you want a new table, but merging into Sales is fine here).
            *   In the Merge dialog:
                *   Select `Sales` table as the current table.
                *   Select the `Grouped Rows` table (which has `customer_id` and `FirstOrderDate`).
                *   Click on `customer_id` in the `Sales` table.
                *   Click on `customer_id` in the `Grouped Rows` table.
                *   Select **"Left Outer (all from first, matching from second)"** as the Join Kind.
                *   Click **"OK"**.
            *   A new column will appear (e.g., "Grouped Rows"). Click the expand icon (two opposing arrows) in its header.
            *   **Uncheck "Select All Columns"** and **only select `FirstOrderDate`**. Uncheck "Use original column name as prefix." Click **"OK"**.
            *   You now have `FirstOrderDate` directly in your `Sales` table for each transaction.

    *   **Create `Cohort Month`:**
        *   Select the `FirstOrderDate` column.
        *   Go to the **"Add Column"** tab, click **"Date"** -> **"Start of Month"**.
        *   Rename this new column to `Cohort Month`. (Right-click column header -> Rename)

    *   **Create `Order Month` (for the current transaction):**
        *   Select the `clean_order_date` column.
        *   Go to the **"Add Column"** tab, click **"Date"** -> **"Start of Month"**.
        *   Rename this new column to `Order Month`.

    *   **Create `Months Since Cohort Start`:** This column will help track how many months have passed since a customer's first order month for each subsequent order.
        *   Go to the **"Add Column"** tab.
        *   Click **"Custom Column"**.
        *   **New column name:** `Months Since Cohort Start`
        *   **Custom column formula:**
            ```powerquery
            (Date.Year([Order Month]) - Date.Year([Cohort Month])) * 12 +
            (Date.Month([Order Month]) - Date.Month([Cohort Month]))
            ```
        *   Click **"OK"**. Change its data type to **"Whole Number"**.

5.  **Remove Duplicate Transactions (if `duplicate_type` indicates actual duplicates):**
    *   The `duplicate_type` column could be useful. If `duplicate_type` is 'genuine_bulk_order', these are not duplicates but legitimate bulk purchases. If there are other values indicating true errors, you might filter them out. For this dashboard, we'll assume `duplicate_type` is for informational purposes and keep all rows.

6.  Once all transformations are complete, click **"Close & Apply"** on the Home tab to load the data into Power BI Desktop.

---

## 3. Data Modeling

### 3.1 Date Table

A separate Date table is crucial for robust time intelligence functions and filtering.

1.  **Create a New Table in Power BI Desktop:**
    *   On the "Home" tab, click **"New table"**.
    *   Paste the following DAX code into the formula bar and press Enter:

    ```dax
    Dim_Date =
    VAR MinDate = MIN(Sales[clean_order_date])
    VAR MaxDate = MAX(Sales[clean_order_date])
    RETURN
        ADDCOLUMNS(
            CALENDAR(MinDate, MaxDate),
            "Year", YEAR([Date]),
            "MonthNum", MONTH([Date]),
            "Month", FORMAT([Date], "MMM"),
            "Month & Year", FORMAT([Date], "MMM YYYY"),
            "Quarter", "Q" & FORMAT([Date], "Q"),
            "Day", DAY([Date]),
            "Weekday", FORMAT([Date], "ddd"),
            "Date Key", FORMAT([Date], "YYYYMMDD")
        )
    ```
2.  **Sort `Month & Year`:**
    *   Go to the "Data" view (table icon on the left).
    *   Select the `Dim_Date` table.
    *   Select the `Month & Year` column.
    *   In the "Column tools" tab, click **"Sort by column"** and select `MonthNum`.
    *   Select the `Month` column and sort it by `MonthNum`.

### 3.2 Relationships

Establish a relationship between your `Sales` (fact) table and the `Dim_Date` (dimension) table.

1.  Go to the "Model" view (model icon on the left).
2.  Drag the `clean_order_date` column from your `Sales` table onto the `Date` column in your `Dim_Date` table.
3.  Power BI should automatically detect a **Many-to-one (*:1)** relationship, with `Sales` being the "Many" side and `Dim_Date` being the "One" side. The filter direction should be "Single" from `Dim_Date` to `Sales`.

---

## 4. DAX Measures

These measures will power your dashboard's insights.

1.  **Total Sales:**
    ```dax
    Total Sales = SUM(Sales[clean_final_amount_inr])
    ```
    *Explanation:* Calculates the total revenue from all transactions.

2.  **Total Quantity Sold:**
    ```dax
    Total Quantity Sold = SUM(Sales[quantity])
    ```
    *Explanation:* Sums up the total number of items sold.

3.  **Total Customers:**
    ```dax
    Total Customers = DISTINCTCOUNT(Sales[customer_id])
    ```
    *Explanation:* Counts the unique number of customers in the current filter context.

4.  **Total Orders:**
    ```dax
    Total Orders = DISTINCTCOUNT(Sales[transaction_id])
    ```
    *Explanation:* Counts the unique number of orders placed.

5.  **Average Order Value (AOV):**
    ```dax
    Average Order Value = DIVIDE([Total Sales], [Total Orders], 0)
    ```
    *Explanation:* Calculates the average revenue per order.

6.  **Average Customer Lifetime Value (CLTV):**
    ```dax
    Average CLTV =
    AVERAGEX(
        SUMMARIZE(Sales, Sales[customer_id], "CustomerTotalSales", [Total Sales]),
        [CustomerTotalSales]
    )
    ```
    *Explanation:* Calculates the average total sales generated by each unique customer across all their transactions.

7.  **New Customers:**
    ```dax
    New Customers =
    CALCULATE(
        DISTINCTCOUNT(Sales[customer_id]),
        FILTER(
            ALL(Sales[customer_id], Sales[FirstOrderDate]),
            Sales[FirstOrderDate] >= MIN(Dim_Date[Date]) &&
            Sales[FirstOrderDate] <= MAX(Dim_Date[Date])
        )
    )
    ```
    *Explanation:* Counts customers whose *first order date* falls within the selected date range.

8.  **Returning Customers:**
    ```dax
    Returning Customers =
    VAR CustomersInPeriod = VALUES(Sales[customer_id])
    VAR FirstOrderDates = CALCULATETABLE(
                                SELECTCOLUMNS(Sales, "Customer", Sales[customer_id], "FirstOrder", Sales[FirstOrderDate]),
                                ALL(Sales)
                            )
    RETURN
        COUNTROWS(
            FILTER(
                CustomersInPeriod,
                LOOKUPVALUE(FirstOrderDates[FirstOrder], FirstOrderDates[Customer], [customer_id]) < MIN(Dim_Date[Date])
            )
        )
    ```
    *Explanation:* Counts customers who made a purchase in the current period AND whose first order was *before* the current period's start date. (Requires the `Dim_Date` to be filtered to current period).
    *   **Simpler alternative for Returning Customers if `FirstOrderDate` is in `Sales` table:**
        ```dax
        Returning Customers (Simpler) =
        VAR CurrentPeriodCustomers = DISTINCT(Sales[customer_id])
        RETURN
            CALCULATE(
                COUNTROWS(
                    FILTER(
                        CurrentPeriodCustomers,
                        CALCULATE(MIN(Sales[FirstOrderDate]), ALL(Sales[clean_order_date], Sales[Order Month])) < MIN(Dim_Date[Date])
                    )
                ),
                -- Ensure the count is for customers within the current date context
                KEEPFILTERS(Dim_Date[Date] >= MIN(Dim_Date[Date]) && Dim_Date[Date] <= MAX(Dim_Date[Date]))
            )
        ```
        This simplified version might require careful context handling. Let's use the explicit filtering for clarity.
        ```dax
        Returning Customers =
        VAR CustomersInSelectedPeriod =
            CALCULATETABLE(
                DISTINCT(Sales[customer_id]),
                ALLSELECTED(Dim_Date) // Get all customers in the currently selected date range
            )
        VAR CustomersWithPreviousOrder =
            FILTER(
                CustomersInSelectedPeriod,
                CALCULATE(
                    MIN(Sales[FirstOrderDate]),
                    KEEPFILTERS(Sales[customer_id] = [customer_id]),
                    ALL(Sales) // Remove all other filters on Sales table
                ) < MIN(Dim_Date[Date])
            )
        RETURN
            COUNTROWS(CustomersWithPreviousOrder)
        ```

9.  **Customers in Cohort (Base for Cohort Analysis):**
    ```dax
    Customers in Cohort =
    CALCULATE(
        DISTINCTCOUNT(Sales[customer_id]),
        ALLEXCEPT(Sales, Sales[Cohort Month])
    )
    ```
    *Explanation:* When used in a matrix with `Cohort Month` on rows, this will give the total number of unique customers who made their first purchase in that specific cohort month.

10. **Customers Retained (for Cohort Analysis):**
    ```dax
    Customers Retained =
    DISTINCTCOUNT(Sales[customer_id])
    ```
    *Explanation:* This measure, when placed in a cohort analysis matrix, will dynamically count the distinct customers present in the intersection of a `Cohort Month` (row) and a `Months Since Cohort Start` (column).

11. **Retention Rate % (Cohort Analysis):**
    ```dax
    Retention Rate % =
    VAR CustomersInPeriod = [Customers Retained]
    VAR BaseCohortCustomers = [Customers in Cohort]
    RETURN
        DIVIDE(CustomersInPeriod, BaseCohortCustomers, 0)
    ```
    *Explanation:* Calculates the percentage of customers from a specific cohort who are still active in a subsequent period. Format this measure as "Percentage".

---

## 5. Visualization

Here are recommended visuals to build your Customer Retention Dashboard.

### Dashboard Layout & Design Tips:

*   **Theme:** Choose a consistent color palette (View tab -> Themes).
*   **Whitespace:** Leave breathing room between visuals.
*   **Alignment:** Align visuals neatly using Power BI's alignment tools.
*   **Page Title:** Add a text box for "Customer Retention Dashboard."
*   **Filters:** Place slicers on the left or top for easy access.
*   **Tooltips:** Customize tooltips for more detail on hover.

### Recommended Visuals:

#### Section 1: Key Performance Indicators (KPIs)

*   **Visual Type:** **Card** (x5)
    *   **Total Sales:** Drag `[Total Sales]` measure to "Fields".
    *   **Total Customers:** Drag `[Total Customers]` measure to "Fields".
    *   **New Customers:** Drag `[New Customers]` measure to "Fields".
    *   **Returning Customers:** Drag `[Returning Customers]` measure to "Fields".
    *   **Average CLTV:** Drag `[Average CLTV]` measure to "Fields".
    *   *Design:* Place these prominently at the top of your dashboard.

#### Section 2: Customer Retention Over Time

*   **Visual Type:** **Line Chart**
    *   **X-axis:** `Dim_Date[Month & Year]`
    *   **Y-axis:** `[Total Customers]`
    *   *Description:* Shows the trend of active customers over time.
*   **Visual Type:** **Clustered Column Chart**
    *   **X-axis:** `Dim_Date[Month & Year]`
    *   **Y-axis (Values):** `[New Customers]` and `[Returning Customers]`
    *   *Description:* Visualizes the split between new and returning customers each month, indicating growth sources.

#### Section 3: Cohort Analysis (The Core)

*   **Visual Type:** **Matrix**
    *   **Rows:** `Sales[Cohort Month]`
    *   **Columns:** `Sales[Months Since Cohort Start]`
    *   **Values:** `[Retention Rate %]` (Apply conditional formatting: "Format by rules," e.g., green for high, red for low, to easily spot patterns).
    *   *Design:* You can also add `[Customers in Cohort]` and `[Customers Retained]` as additional values (drag above `Retention Rate %`) and then collapse them using the "+" icon in the top left of the Matrix visual, so `Retention Rate %` is the primary visible value.
    *   *Description:* This is the heart of the retention dashboard. Each cell `(Row R, Column C)` shows the percentage of customers from `Cohort Month R` who were still active `C` months after their first purchase.

#### Section 4: Customer Lifecycle & Segmentation

*   **Visual Type:** **Clustered Bar Chart**
    *   **Axis:** `customer_age_group`
    *   **Values:** `[Total Customers]`
    *   *Description:* Shows customer distribution by age group. Repeat for `customer_tier`, `customer_spending_tier`.
*   **Visual Type:** **Funnel Chart**
    *   **Category:** `Sales[Months Since Cohort Start]` (filtered to show relevant stages, e.g., 0, 1, 3, 6, 12 months)
    *   **Values:** `[Customers Retained]`
    *   *Description:* A simplified representation of customer drop-off at different stages of their lifecycle (months since their first order). Filter out months where there are too few customers for clarity.

#### Section 5: Retention Strategies & Product Insights

*   **Visual Type:** **Bar Chart**
    *   **Axis:** `festival_name`
    *   **Values:** `[New Customers]`
    *   *Description:* Shows which festivals attracted the most *new* customers. This helps assess acquisition effectiveness of sales events.
*   **Visual Type:** **Stacked Bar Chart**
    *   **Axis:** `cleaned_category`
    *   **Legend:** `customer_spending_tier`
    *   **Values:** `[Total Sales]`
    *   *Description:* See which categories are driving sales from different spending tiers, potentially indicating product stickiness for certain customer segments.
*   **Visual Type:** **Map (Filled Map or Shape Map)**
    *   **Location:** `customer_state` or `cleaned_customer_city`
    *   **Color saturation:** `[Total Customers]` or `[Total Sales]`
    *   *Description:* Visualize geographical distribution of customers or sales, useful for localized retention efforts.

---

## 6. Interactivity

Interactivity makes your dashboard dynamic and insightful.

1.  **Slicers:**
    *   Add the following slicers to your dashboard (typically on the left side):
        *   **Year:** From `Dim_Date[Year]`
        *   **Month & Year:** From `Dim_Date[Month & Year]`
        *   **Customer Tier:** From `Sales[customer_tier]`
        *   **Customer Age Group:** From `Sales[customer_age_group]`
        *   **Category:** From `Sales[cleaned_category]`
        *   **Customer State:** From `Sales[customer_state]`
    *   *Design:* Change slicer orientation to "Horizontal" if placing at the top, or keep "Vertical" for sidebars. Use "Dropdown" style for many values to save space.

2.  **Edit Interactions:**
    *   By default, slicers and visuals will filter each other. You can fine-tune this:
    *   Select a visual (e.g., the "Total Sales" card).
    *   Go to the "Format" tab, click **"Edit interactions"**.
    *   Now, when you click on other visuals, you'll see filter/highlight icons. You can choose whether that visual *filters* or *highlights* the selected visual, or has *no interaction*.
    *   For KPI cards, often you want them to be filtered. For some charts, you might prefer highlighting. Ensure your slicers filter all relevant visuals.

3.  **Drill-down / Drill-through (Advanced):**
    *   **Drill-down:** For visuals like Line Charts with `Year` on the axis, you can add `Quarter` and `Month` to the same axis field well. Then, enable drill-down to navigate from year to quarter to month trends.
    *   **Drill-through:** To see details of specific customers:
        1.  Create a new page named "Customer Details".
        2.  Add a visual like a **Table** to this page.
        3.  Drag `customer_id`, `transaction_id`, `clean_order_date`, `product_name`, `clean_final_amount_inr`, `return_status`, etc. into the "Values" of this table.
        4.  Drag `customer_id` into the **"Drill through filters"** section of the "Customer Details" page.
        5.  Now, on your main dashboard, when you right-click on any visual showing customer-level data (e.g., a bar chart by `customer_tier`), you'll see "Drill through" -> "Customer Details". Clicking this will take you to the "Customer Details" page, filtered for the selected customer(s).

By following these steps, you will create a powerful and insightful Customer Retention Dashboard in Power BI, allowing you to effectively monitor and analyze customer behavior.