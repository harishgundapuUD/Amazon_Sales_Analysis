Here are the comprehensive, step-by-step instructions to create your Power BI Demographics & Behavior Dashboard.

---

## Power BI Demographics & Behavior Dashboard

### 1. Objective

The primary goal of this dashboard is to gain deep insights into customer demographics and behavioral patterns. By analyzing age group preferences, spending habits, geographic distribution, and key marketing indicators, we aim to identify opportunities for targeted marketing campaigns, optimize product offerings, and enhance customer satisfaction.

### 2. Data Loading & Preparation

This section details how to load your CSV file into Power BI and perform essential cleaning and transformation steps using Power Query Editor.

1.  **Load Data:**
    *   Open Power BI Desktop.
    *   Click on **"Get data"** from the Home tab.
    *   Select **"Text/CSV"** from the common data sources, then click **"Connect"**.
    *   Navigate to your CSV file, select it, and click **"Open"**.
    *   In the preview window, Power BI will detect the delimiter and data types. Ensure the delimiter is set to Comma.
    *   Click **"Transform Data"** to open the Power Query Editor.

2.  **Power Query Editor Transformations:**
    *   **Rename Table:** In the "Queries" pane on the left, right-click on your table (it might be named after your CSV file) and rename it to `Sales Data` for clarity.
    *   **Review and Adjust Data Types:**
        *   Go through each column and verify its data type. Power BI usually does a good job, but manual checks are crucial.
        *   `transaction_id`, `customer_id`, `product_id`, `product_name`, `subcategory`, `brand`, `customer_state`, `customer_tier`, `customer_spending_tier`, `customer_age_group`, `delivery_type`, `festival_name`, `return_status`, `cleaned_customer_city`, `cleaned_category`, `duplicate_type`, `standard_payment_method`: **Text**
        *   `quantity`, `order_month`, `order_year`, `order_quarter`: **Whole Number**
        *   `product_weight_kg`, `clean_original_price_inr`, `clean_discount_percent`, `clean_final_amount_inr`, `clean_delivery_charges`, `cleaned_customer_rating`, `cleaned_product_rating`, `cleaned_delivery_days`, `corrected_price`: **Decimal Number**
        *   `clean_order_date`: **Date** (important!)
        *   `cleaned_is_prime_member`, `cleaned_is_prime_eligible`, `cleaned_is_festival_sale`: **True/False** (Boolean)
        *   *To change a data type:* Click the icon to the left of the column header (e.g., `ABC`, `123`), then select the appropriate type.
    *   **Handle Nulls in `festival_name`:**
        *   Select the `festival_name` column.
        *   Go to the **Transform** tab in the ribbon.
        *   Click **"Replace Values"**.
        *   In "Value To Find", leave it blank (or type `null` if that's how it appears).
        *   In "Replace With", type `No Festival`. Click **"OK"**.
    *   **Rename Columns for Readability:**
        *   Rename `clean_order_date` to `Order Date`.
        *   Rename `clean_final_amount_inr` to `Revenue`.
        *   Rename `cleaned_is_prime_member` to `Is Prime Member`.
        *   Rename `cleaned_is_festival_sale` to `Is Festival Sale`.
        *   Rename `cleaned_category` to `Category`.
        *   *To rename:* Double-click the column header and type the new name, or right-click and select "Rename".
    *   **Remove Duplicate Columns (Optional but good practice):**
        *   The dataset has `order_month`, `order_year`, `order_quarter`. If you plan to use a separate Date table for time intelligence (which we will), these columns become redundant in the fact table. You can remove them or keep them for quick filtering if you prefer not to use the Date table for those specifics. For this guide, we'll keep them as they might be easier for a new user, but if a full date table is used they are truly redundant for analysis but can stay for reporting if desired.
    *   Once all transformations are complete, click **"Close & Apply"** from the Home tab in Power Query Editor to load the data into Power BI Desktop.

### 3. Data Modeling

We will create a separate Date table to enable robust time-intelligence calculations and filtering.

1.  **Create a Date Table:**
    *   Go to the **Table Tools** tab in Power BI Desktop (after clicking on any table).
    *   Click on **"New Table"**.
    *   Enter the following DAX formula into the formula bar and press Enter:

    ```dax
    Date Table = 
    VAR MinDate = MIN('Sales Data'[Order Date])
    VAR MaxDate = MAX('Sales Data'[Order Date])
    RETURN
        ADDCOLUMNS (
            CALENDAR (MinDate, MaxDate),
            "Year", YEAR ( [Date] ),
            "Month Number", MONTH ( [Date] ),
            "Month", FORMAT ( [Date], "MMM" ),
            "Month Name", FORMAT ( [Date], "MMMM" ),
            "Quarter", "Q" & FORMAT ( [Date], "Q" ),
            "Day", DAY ( [Date] ),
            "Day of Week", WEEKDAY([Date], 2), // Monday=1, Sunday=7
            "Full Date", FORMAT([Date], "YYYY-MM-DD")
        )
    ```
2.  **Mark as Date Table:**
    *   Select the newly created `Date Table` in the Fields pane.
    *   Go to **Table Tools** tab in the ribbon.
    *   Click **"Mark as date table"**, then select the `Date` column as the Date column. Click **"OK"**.
3.  **Create Relationships:**
    *   Go to the **Model view** (the third icon on the left navigation pane, resembling three interconnected tables).
    *   Drag the `Order Date` column from the `Sales Data` table and drop it onto the `Date` column in the `Date Table`.
    *   This will create a one-to-many relationship (one date in `Date Table` can have many orders in `Sales Data`). Ensure the direction is from `Date Table` to `Sales Data`.

### 4. DAX Measures

These measures will be the foundation of your dashboard's calculations.

1.  **Total Revenue:**
    ```dax
    Total Revenue = SUM('Sales Data'[Revenue])
    ```
    *Explanation:* Calculates the sum of all final transaction amounts.

2.  **Total Quantity Sold:**
    ```dax
    Total Quantity Sold = SUM('Sales Data'[quantity])
    ```
    *Explanation:* Sums up the quantity of all products sold.

3.  **Total Orders:**
    ```dax
    Total Orders = DISTINCTCOUNT('Sales Data'[transaction_id])
    ```
    *Explanation:* Counts the unique number of transactions.

4.  **Average Order Value:**
    ```dax
    Average Order Value = DIVIDE([Total Revenue], [Total Orders], 0)
    ```
    *Explanation:* Calculates the average revenue per order. `0` is for handling division by zero if `Total Orders` is blank.

5.  **Total Customers:**
    ```dax
    Total Customers = DISTINCTCOUNT('Sales Data'[customer_id])
    ```
    *Explanation:* Counts the unique number of customers.

6.  **Average Customer Rating:**
    ```dax
    Average Customer Rating = AVERAGEX(
        FILTER('Sales Data', NOT ISBLANK('Sales Data'[cleaned_customer_rating])),
        'Sales Data'[cleaned_customer_rating]
    )
    ```
    *Explanation:* Calculates the average customer rating, excluding blank values.

7.  **Average Product Rating:**
    ```dax
    Average Product Rating = AVERAGEX(
        FILTER('Sales Data', NOT ISBLANK('Sales Data'[cleaned_product_rating])),
        'Sales Data'[cleaned_product_rating]
    )
    ```
    *Explanation:* Calculates the average product rating, excluding blank values.

8.  **Sales During Festival:**
    ```dax
    Sales During Festival = CALCULATE([Total Revenue], 'Sales Data'[Is Festival Sale] = TRUE)
    ```
    *Explanation:* Calculates total revenue specifically from festival sales.

9.  **Sales (Non-Festival):**
    ```dax
    Sales (Non-Festival) = CALCULATE([Total Revenue], 'Sales Data'[Is Festival Sale] = FALSE || ISBLANK('Sales Data'[Is Festival Sale]))
    ```
    *Explanation:* Calculates total revenue from sales not during a festival.

10. **Prime Member Sales:**
    ```dax
    Prime Member Sales = CALCULATE([Total Revenue], 'Sales Data'[Is Prime Member] = TRUE)
    ```
    *Explanation:* Calculates total revenue from sales to prime members.

11. **Non-Prime Member Sales:**
    ```dax
    Non-Prime Member Sales = CALCULATE([Total Revenue], 'Sales Data'[Is Prime Member] = FALSE || ISBLANK('Sales Data'[Is Prime Member]))
    ```
    *Explanation:* Calculates total revenue from sales to non-prime members.

12. **Total Delivery Charges:**
    ```dax
    Total Delivery Charges = SUM('Sales Data'[clean_delivery_charges])
    ```
    *Explanation:* Sums up all delivery charges.

13. **Count of Returns:**
    ```dax
    Count of Returns = CALCULATE([Total Orders], 'Sales Data'[return_status] = "Returned")
    ```
    *Explanation:* Counts the number of orders with a "Returned" status. (Note: Based on sample data, all are "Delivered". Please verify if "Returned" exists in your full dataset for this measure to be meaningful).

### 5. Visualization

Let's design a single-page dashboard for Demographics & Behavior.

**Dashboard Layout:**
Aim for a clean, grid-like layout. Place key performance indicators (KPIs) at the top, followed by demographic and behavioral charts. Use consistent colors and fonts.

**Visuals Breakdown:**

1.  **Overall KPIs (Top Left Section):**
    *   **Card Visuals:**
        *   `Total Revenue`: Use `Total Revenue` measure.
        *   `Total Orders`: Use `Total Orders` measure.
        *   `Total Customers`: Use `Total Customers` measure.
        *   `Average Order Value`: Use `Average Order Value` measure.
        *   `Total Quantity Sold`: Use `Total Quantity Sold` measure.
        *   `Total Delivery Charges`: Use `Total Delivery Charges` measure.
    *   *Design Tip:* Arrange these in a row or two at the top for quick overview.

2.  **Age Group Preferences (Middle Section):**
    *   **Revenue by Age Group (Clustered Column Chart):**
        *   **X-axis:** `customer_age_group` from `Sales Data`
        *   **Y-axis:** `Total Revenue` measure
        *   *Insight:* Shows which age groups contribute most to revenue.
    *   **Quantity Sold by Age Group (Clustered Column Chart):**
        *   **X-axis:** `customer_age_group` from `Sales Data`
        *   **Y-axis:** `Total Quantity Sold` measure
        *   *Insight:* Shows product purchase volume across age groups.
    *   **Top 5 Categories by Age Group (Stacked Bar Chart or Table with TopN Filter):**
        *   **Y-axis:** `Category` from `Sales Data`
        *   **X-axis:** `Total Revenue` measure
        *   **Legend:** `customer_age_group` (optional, or use age group as a slicer to view top categories for specific age groups).
        *   *Insight:* Reveals category preferences within different age groups. A Top N filter on `Category` for `Total Revenue` would be useful here.

3.  **Spending Patterns (Middle Right Section):**
    *   **Revenue by Customer Tier (Donut Chart):**
        *   **Values:** `Total Revenue` measure
        *   **Legend:** `customer_tier` from `Sales Data`
        *   *Insight:* Understand revenue distribution across customer tiers (Metro, Tier1, etc.).
    *   **Average Order Value by Customer Spending Tier (Bar Chart):**
        *   **X-axis:** `customer_spending_tier` from `Sales Data`
        *   **Y-axis:** `Average Order Value` measure
        *   *Insight:* Highlights average spending habits per customer spending tier.

4.  **Geographic Behaviors (Bottom Left Section):**
    *   **Revenue by Customer State (Filled Map):**
        *   **Location:** `customer_state` from `Sales Data`
        *   **Color saturation:** `Total Revenue` measure
        *   *Insight:* Visualizes geographic sales performance at a glance.
    *   **Revenue by Cleaned Customer City (Bar Chart):**
        *   **Y-axis:** `cleaned_customer_city` from `Sales Data` (apply a Top N filter for Top 5 or Top 10)
        *   **X-axis:** `Total Revenue` measure
        *   *Insight:* Identifies top-performing cities.

5.  **Targeted Marketing Opportunities (Bottom Right Section):**
    *   **Sales During Festival vs. Non-Festival (100% Stacked Bar Chart or 2 Card Visuals):**
        *   Use `Sales During Festival` and `Sales (Non-Festival)` measures in a 100% stacked column chart to show their proportion of total sales over time (e.g., by Year/Month from Date Table on X-axis), or just display as two card visuals.
        *   *Insight:* Quantifies the impact of festival sales for strategic planning.
    *   **Prime vs. Non-Prime Member Sales (Donut Chart):**
        *   **Values:** `Prime Member Sales` and `Non-Prime Member Sales` (drag both into values, or create a `Prime Status` grouping if preferred)
        *   *Insight:* Shows the revenue contribution from Prime vs. Non-Prime members.
    *   **Sales by Payment Method (Bar Chart):**
        *   **Y-axis:** `standard_payment_method` from `Sales Data`
        *   **X-axis:** `Total Revenue` measure
        *   *Insight:* Understand preferred payment methods, useful for payment gateway partnerships/promotions.
    *   **Average Customer Rating (Card Visual):**
        *   Use `Average Customer Rating` measure.
        *   *Insight:* Quick view of overall customer satisfaction.

**Design Tips:**
*   **Titles:** Give clear and descriptive titles to all your visuals.
*   **Colors:** Use a cohesive color palette. Power BI offers several built-in themes or you can customize your own.
*   **Background:** Consider a light background for clarity.
*   **Tooltips:** Enable tooltips on charts to show detailed information when hovering.
*   **Formatting:** Ensure currency values are formatted appropriately (e.g., INR, with commas).

### 6. Interactivity

Interactivity makes your dashboard dynamic and exploratory.

1.  **Slicers (Right Panel or Top Area):**
    *   **Order Year (from `Date Table`):** Use the `Year` field from `Date Table`. Set it as a "List" or "Dropdown" slicer.
    *   **Order Month (from `Date Table`):** Use the `Month Name` field from `Date Table`. Set it as a "List" or "Dropdown" slicer.
    *   **Category (`Sales Data`):** Use `Category` from `Sales Data`.
    *   **Brand (`Sales Data`):** Use `brand` from `Sales Data`.
    *   **Customer State (`Sales Data`):** Use `customer_state` from `Sales Data`.
    *   **Customer Age Group (`Sales Data`):** Use `customer_age_group` from `Sales Data`.
    *   **Customer Tier (`Sales Data`):** Use `customer_tier` from `Sales Data`.
    *   **Customer Spending Tier (`Sales Data`):** Use `customer_spending_tier` from `Sales Data`.
    *   *To create a slicer:* Select the Slicer visual icon, drag the desired field into the "Field" well.
    *   *Slicer Interaction:* By default, slicers filter all other visuals on the page. To manage interactions (e.g., if you don't want a specific slicer to affect a particular visual), select the slicer, go to **Format** tab > **Edit interactions**, and adjust.

2.  **Drill-down Functionality:**
    *   For visuals like time-based charts (e.g., `Total Revenue` by `Date`), Power BI automatically creates a date hierarchy. You can enable drill-down by clicking the "down arrow" icon on the visual header to navigate from Year to Quarter to Month to Day.
    *   Similarly, if you put `Category` and then `Subcategory` on the X-axis of a bar chart, you can use the drill-down arrow to see subcategory details within a category.

This comprehensive guide should equip you to build a powerful and insightful Demographics & Behavior Dashboard in Power BI, empowering you to make data-driven decisions.