This guide will walk you through building a "Festival Sales Analytics Dashboard" in Power BI Desktop. This dashboard will help you understand sales performance during festive periods, assess campaign effectiveness, analyze promotional impacts, and gain insights for seasonal revenue optimization.

---

### 1. Objective

The primary objective of this dashboard is to provide a comprehensive view of sales performance specifically related to festive periods. It will enable users to:
*   Track total sales and quantity sold during festivals.
*   Compare festival sales against non-festival sales.
*   Analyze the impact of promotions (discounts) during festive campaigns.
*   Identify top-performing products, categories, and customer segments during festivals.
*   Evaluate customer and product ratings during these periods.
*   Optimize future seasonal revenue strategies.

### 2. Data Loading & Preparation

This section details how to load your CSV data and perform essential cleaning and transformations in Power Query Editor.

#### 2.1. Loading the CSV Data

1.  **Open Power BI Desktop.**
2.  Go to the **Home** tab on the ribbon.
3.  Click **Get data**.
4.  Select **Text/CSV** from the common data sources, then click **Connect**.
5.  Browse to your CSV file, select it, and click **Open**.
6.  A preview window will appear. Ensure the **Delimiter** is set to `Comma` and **Data Type Detection** is `Based on first 200 rows`.
7.  Click **Transform Data**. This will open the Power Query Editor.

#### 2.2. Data Cleaning & Transformation in Power Query Editor

Once in Power Query Editor, follow these steps to prepare your data. Rename the query to `Sales Data` (or a similar descriptive name) by right-clicking `Query1` in the `Queries` pane and selecting `Rename`.

**a. Changing Data Types:**
Correct data types are crucial for accurate analysis and calculations. Go through each column and ensure it has the correct type as described below:

*   **`transaction_id`**: Text
*   **`customer_id`**: Text
*   **`product_id`**: Text
*   **`product_name`**: Text
*   **`subcategory`**: Text
*   **`brand`**: Text
*   **`quantity`**: Whole Number
*   **`customer_state`**: Text
*   **`customer_tier`**: Text
*   **`customer_spending_tier`**: Text
*   **`customer_age_group`**: Text
*   **`delivery_type`**: Text
*   **`festival_name`**: Text
*   **`return_status`**: Text
*   **`order_month`**: Whole Number
*   **`order_year`**: Whole Number
*   **`order_quarter`**: Whole Number
*   **`product_weight_kg`**: Decimal Number
*   **`clean_order_date`**: Date (Important! Make sure this is `Date` type, not Date/Time).
*   **`clean_original_price_inr`**: Decimal Number
*   **`clean_discount_percent`**: Decimal Number
*   **`clean_final_amount_inr`**: Decimal Number
*   **`clean_delivery_charges`**: Decimal Number
*   **`cleaned_customer_rating`**: Decimal Number
*   **`cleaned_product_rating`**: Decimal Number
*   **`cleaned_customer_city`**: Text
*   **`cleaned_is_prime_member`**: True/False
*   **`cleaned_is_prime_eligible`**: True/False
*   **`cleaned_is_festival_sale`**: True/False
*   **`cleaned_category`**: Text
*   **`cleaned_delivery_days`**: Whole Number
*   **`duplicate_type`**: Text
*   **`corrected_price`**: Decimal Number
*   **`standard_payment_method`**: Text

*To change a data type:* Click the icon next to the column header (e.g., `ABC` for text, `123` for whole number), then select the correct type.

**b. Handling Nulls:**
*   For numeric columns like `cleaned_customer_rating`, `cleaned_product_rating`, `clean_delivery_charges`, `cleaned_delivery_days`, it's generally best to leave nulls as they are. Power BI's aggregate functions (like `AVERAGE`, `SUM`) will ignore nulls correctly. If you wish to treat null ratings as 0, you can:
    1.  Select the column (e.g., `cleaned_customer_rating`).
    2.  Go to the **Transform** tab.
    3.  Click **Replace Values**.
    4.  In "Value To Find", type `null`. In "Replace With", type `0`. Click **OK**.
    *   *Self-correction*: For ratings, leaving nulls is often preferred. For `cleaned_delivery_days` it might be fine to replace with 0 if it means "delivered same day" or "no delivery days info". Let's assume for this dashboard we leave nulls as they are for ratings and delivery days, as `AVERAGE` will handle them.

**c. Creating New Columns (in Power Query):**
These columns will simplify DAX calculations and provide more immediate insights.

1.  **`Potential Revenue`**: This calculates the revenue before any discounts.
    *   Go to **Add Column** tab.
    *   Click **Custom Column**.
    *   **New column name:** `Potential Revenue`
    *   **Custom column formula:** `[clean_original_price_inr] * [quantity]`
    *   Click **OK**. Change its data type to `Decimal Number`.

2.  **`Total Discount Given`**: This calculates the actual monetary value of the discount applied.
    *   Go to **Add Column** tab.
    *   Click **Custom Column**.
    *   **New column name:** `Total Discount Given`
    *   **Custom column formula:** `[Potential Revenue] - [clean_final_amount_inr]`
    *   Click **OK**. Change its data type to `Decimal Number`.

3.  **`Actual Discount Percentage`**: This calculates the true discount percentage applied to the transaction.
    *   Go to **Add Column** tab.
    *   Click **Custom Column**.
    *   **New column name:** `Actual Discount Percentage`
    *   **Custom column formula:** `if [Potential Revenue] > 0 then [Total Discount Given] / [Potential Revenue] else 0`
    *   Click **OK**. Change its data type to `Decimal Number`. You might want to format this as a percentage in Power BI Desktop later.

4.  **`Festival Status`**: A descriptive column for slicers/legends.
    *   Go to **Add Column** tab.
    *   Click **Conditional Column**.
    *   **New column name:** `Festival Status`
    *   **If:** `cleaned_is_festival_sale` **operator:** `is true` **Output:** `Festival Sale`
    *   **Else:** `Non-Festival Sale`
    *   Click **OK**.

Once all transformations are done, click **Close & Apply** on the Home tab to load the data into Power BI Desktop.

### 3. Data Modeling

#### 3.1. Date Table

A dedicated Date table is essential for robust time-intelligence calculations (like Year-over-Year growth, Month-over-Month, etc.) and consistent date filtering.

1.  In Power BI Desktop, go to the **Table Tools** tab (it might appear after selecting `Sales Data` in the Fields pane).
2.  Click **New Table**.
3.  Paste the following DAX code into the formula bar and press Enter:

    ```dax
    Date Table =
    VAR MinDate = CALCULATE(MIN('Sales Data'[clean_order_date]), ALL('Sales Data'))
    VAR MaxDate = CALCULATE(MAX('Sales Data'[clean_order_date]), ALL('Sales Data'))
    RETURN
        ADDCOLUMNS (
            CALENDAR (MinDate, MaxDate),
            "Year", YEAR ( [Date] ),
            "Month Number", MONTH ( [Date] ),
            "Month Name", FORMAT ( [Date], "MMM" ), // e.g., Jan, Feb
            "Full Month Name", FORMAT ( [Date], "MMMM" ), // e.g., January, February
            "Quarter", "Q" & FORMAT ( [Date], "Q" ),
            "Quarter Name", "Quarter " & FORMAT ( [Date], "Q" ),
            "Day of Week", WEEKDAY ( [Date], 2 ), // 1 for Sunday, 2 for Monday
            "Day Name", FORMAT ( [Date], "DDD" ), // e.g., Mon, Tue
            "Full Day Name", FORMAT ( [Date], "DDDD" ), // e.g., Monday, Tuesday
            "Week Number", WEEKNUM ( [Date] )
        )
    ```

4.  **Sort Columns by:** For `Month Name`, select the column in the `Date Table` and in `Column tools`, click **Sort by column** and choose `Month Number`. Do the same for `Day Name` and sort by `Day of Week`. This ensures your months and days appear in chronological order in visuals.
5.  **Mark as Date Table:** With `Date Table` selected, go to `Table tools`, click **Mark as date table**, select `Date` column, and click **OK**.

#### 3.2. Creating Relationships

You need to link your `Sales Data` table to the `Date Table` so that filters from the date table propagate correctly to your sales data.

1.  Go to the **Model view** (the third icon on the left navigation pane).
2.  Drag the `clean_order_date` column from your `Sales Data` table to the `Date` column in your `Date Table`.
3.  Power BI will automatically create a **one-to-many relationship** (single direction filter from `Date Table` to `Sales Data`), which is correct.

### 4. DAX Measures

Measures are critical for calculating key metrics. Create these measures in your `Sales Data` table by right-clicking the table in the `Fields` pane and selecting **New measure**.

1.  **Total Sales (INR)**
    ```dax
    Total Sales (INR) = SUM('Sales Data'[clean_final_amount_inr])
    ```
    *   *Explanation:* Calculates the sum of all final amounts after discounts and charges.

2.  **Total Quantity Sold**
    ```dax
    Total Quantity Sold = SUM('Sales Data'[quantity])
    ```
    *   *Explanation:* Total number of products sold.

3.  **Total Discount Value (INR)**
    ```dax
    Total Discount Value (INR) = SUM('Sales Data'[Total Discount Given])
    ```
    *   *Explanation:* The total monetary value of discounts applied across all transactions.

4.  **Average Discount Percentage**
    ```dax
    Average Discount Percentage = AVERAGEX(FILTER('Sales Data', 'Sales Data'[Potential Revenue] > 0), 'Sales Data'[Total Discount Given] / 'Sales Data'[Potential Revenue])
    ```
    *   *Explanation:* Calculates the average actual discount percentage applied per transaction, considering only transactions with potential revenue to avoid division by zero.
    *   *Alternative (if you created PQ column `Actual Discount Percentage`):* `AVERAGE('Sales Data'[Actual Discount Percentage])`

5.  **Number of Transactions**
    ```dax
    Number of Transactions = DISTINCTCOUNT('Sales Data'[transaction_id])
    ```
    *   *Explanation:* Counts the unique number of orders.

6.  **Number of Unique Customers**
    ```dax
    Number of Unique Customers = DISTINCTCOUNT('Sales Data'[customer_id])
    ```
    *   *Explanation:* Counts the unique number of customers who made purchases.

7.  **Average Customer Rating**
    ```dax
    Average Customer Rating = AVERAGE('Sales Data'[cleaned_customer_rating])
    ```
    *   *Explanation:* Average customer feedback rating.

8.  **Average Product Rating**
    ```dax
    Average Product Rating = AVERAGE('Sales Data'[cleaned_product_rating])
    ```
    *   *Explanation:* Average rating given to products.

9.  **Festival Sales Revenue (INR)**
    ```dax
    Festival Sales Revenue (INR) = CALCULATE([Total Sales (INR)], 'Sales Data'[cleaned_is_festival_sale] = TRUE())
    ```
    *   *Explanation:* Total sales specifically during festival periods.

10. **Non-Festival Sales Revenue (INR)**
    ```dax
    Non-Festival Sales Revenue (INR) = CALCULATE([Total Sales (INR)], 'Sales Data'[cleaned_is_festival_sale] = FALSE())
    ```
    *   *Explanation:* Total sales outside of festival periods.

11. **Festival Sales % of Total**
    ```dax
    Festival Sales % of Total = DIVIDE([Festival Sales Revenue (INR)], [Total Sales (INR)], 0)
    ```
    *   *Explanation:* The proportion of total sales generated during festivals.

12. **Average Order Value (INR)**
    ```dax
    Average Order Value (INR) = DIVIDE([Total Sales (INR)], [Number of Transactions], 0)
    ```
    *   *Explanation:* The average revenue generated per transaction.

13. **YoY Sales Growth %**
    ```dax
    YoY Sales Growth % =
    VAR CurrentYearSales = [Total Sales (INR)]
    VAR PreviousYearSales = CALCULATE(
                                [Total Sales (INR)],
                                SAMEPERIODLASTYEAR('Date Table'[Date])
                            )
    RETURN
        DIVIDE(CurrentYearSales - PreviousYearSales, PreviousYearSales, 0)
    ```
    *   *Explanation:* Calculates the year-over-year percentage growth in total sales.

14. **Prime Member Sales (INR)**
    ```dax
    Prime Member Sales (INR) = CALCULATE([Total Sales (INR)], 'Sales Data'[cleaned_is_prime_member] = TRUE())
    ```
    *   *Explanation:* Total sales from customers identified as prime members.

15. **Non-Prime Member Sales (INR)**
    ```dax
    Non-Prime Member Sales (INR) = CALCULATE([Total Sales (INR)], 'Sales Data'[cleaned_is_prime_member] = FALSE())
    ```
    *   *Explanation:* Total sales from non-prime member customers.

### 5. Visualization

Design a dashboard that is intuitive and highlights festival-related insights.

#### Dashboard Layout & Design Tips:
*   **Theme:** Choose a consistent color palette.
*   **Titles:** Use clear and descriptive titles for each visual.
*   **Spacing:** Ensure adequate spacing between visuals for readability.
*   **Labels:** Enable data labels for charts for easy understanding.
*   **Tooltips:** Customize tooltips to show relevant details on hover.
*   **Background:** Consider a subtle background image or color.
*   **Grouping:** Group related visuals (e.g., all KPI cards at the top).

#### Recommended Visuals:

**1. KPI Cards (Top Section)**

*   **Total Sales (INR):**
    *   **Visual Type:** Card
    *   **Field:** `Total Sales (INR)` measure
    *   *Formatting:* Display units as 'Millions' or 'Billions' with 2 decimal places.
*   **Festival Sales Revenue (INR):**
    *   **Visual Type:** Card
    *   **Field:** `Festival Sales Revenue (INR)` measure
*   **Festival Sales % of Total:**
    *   **Visual Type:** Card
    *   **Field:** `Festival Sales % of Total` measure
    *   *Formatting:* Display as Percentage with 1-2 decimal places.
*   **Total Discount Value (INR):**
    *   **Visual Type:** Card
    *   **Field:** `Total Discount Value (INR)` measure
*   **Average Discount Percentage:**
    *   **Visual Type:** Card
    *   **Field:** `Average Discount Percentage` measure
    *   *Formatting:* Display as Percentage with 1-2 decimal places.
*   **Number of Transactions:**
    *   **Visual Type:** Card
    *   **Field:** `Number of Transactions` measure
*   **Number of Unique Customers:**
    *   **Visual Type:** Card
    *   **Field:** `Number of Unique Customers` measure
*   **Average Order Value (INR):**
    *   **Visual Type:** Card
    *   **Field:** `Average Order Value (INR)` measure

**2. Sales Trend (Line Chart)**

*   **Visual Type:** Line chart
*   **X-axis:** `Date Table` -> `Year` (and enable drill-down to `Quarter`, `Month Name`)
*   **Y-axis:** `Total Sales (INR)` measure
*   **Legend:** `Sales Data` -> `Festival Status`
*   *Insight:* Shows how sales fluctuate over time, highlighting peaks during festival periods.

**3. Sales by Festival (Bar Chart)**

*   **Visual Type:** Clustered Column Chart
*   **Axis:** `Sales Data` -> `festival_name`
*   **Values:** `Festival Sales Revenue (INR)` measure
*   *Insight:* Compares sales performance across different festivals.

**4. Category Performance during Festivals (Stacked Bar Chart)**

*   **Visual Type:** 100% Stacked Column Chart
*   **Axis:** `Sales Data` -> `cleaned_category`
*   **Values:** `Total Sales (INR)` measure
*   **Legend:** `Sales Data` -> `Festival Status`
*   *Insight:* Identifies which categories perform best during festival vs. non-festival sales.

**5. Customer Segmentation Festival Performance (Clustered Column Chart)**

*   **Visual Type:** Clustered Column Chart
*   **Axis:** `Sales Data` -> `customer_tier` or `customer_age_group`
*   **Values:** `Festival Sales Revenue (INR)` measure
*   **Secondary Value (optional):** `Non-Festival Sales Revenue (INR)` measure (to compare side-by-side)
*   *Insight:* Understands which customer segments drive the most sales during festivals.

**6. Promotional Impact: Discount % by Festival (Bar Chart)**

*   **Visual Type:** Clustered Column Chart
*   **Axis:** `Sales Data` -> `festival_name`
*   **Values:** `Average Discount Percentage` measure
*   *Insight:* Visualizes the average discount offered during each festival, indicating promotional intensity.

**7. Sales by Customer State (Map or Treemap)**

*   **Visual Type:** Filled Map (if geographical data is accurate enough for states) OR Treemap
*   **Location/Group:** `Sales Data` -> `customer_state`
*   **Values/Values:** `Festival Sales Revenue (INR)` measure
*   *Insight:* Shows the geographical distribution of festival sales.

**8. Ratings during Festival Sales (Card/Gauge)**

*   **Visual Type:** Card or Gauge
*   **Field:** `Average Customer Rating` measure (filter visual by `Festival Status` = 'Festival Sale')
*   **Visual Type:** Card or Gauge
*   **Field:** `Average Product Rating` measure (filter visual by `Festival Status` = 'Festival Sale')
*   *Insight:* Quick view of customer and product satisfaction during festivals.

### 6. Interactivity

Interactivity makes your dashboard dynamic and allows users to explore data.

#### 6.1. Slicers

Place slicers prominently on your dashboard, usually on the left-hand side or top.

*   **Year Slicer:**
    *   **Visual Type:** Slicer
    *   **Field:** `Date Table` -> `Year`
    *   *Settings:* Change to "Dropdown" for space efficiency.
*   **Festival Name Slicer:**
    *   **Visual Type:** Slicer
    *   **Field:** `Sales Data` -> `festival_name`
    *   *Settings:* Change to "Dropdown".
*   **Category Slicer:**
    *   **Visual Type:** Slicer
    *   **Field:** `Sales Data` -> `cleaned_category`
    *   *Settings:* Change to "Dropdown".
*   **Customer Tier Slicer:**
    *   **Visual Type:** Slicer
    *   **Field:** `Sales Data` -> `customer_tier`
    *   *Settings:* Change to "Dropdown".
*   **Prime Member Status Slicer:**
    *   **Visual Type:** Slicer
    *   **Field:** `Sales Data` -> `cleaned_is_prime_member`
    *   *Settings:* Change to "List" or "Dropdown".
*   **Return Status Slicer:**
    *   **Visual Type:** Slicer
    *   **Field:** `Sales Data` -> `return_status`
    *   *Settings:* Change to "List" or "Dropdown".

#### 6.2. Drill-Down Functionality

*   **Time Series Line Chart:** Power BI automatically creates a date hierarchy for the `Date` column from your `Date Table`. For the Sales Trend chart, ensure the `Year` field is dragged to the X-axis, then use the drill-down buttons on the visual (located at the top-right of the visual when selected) to move from Year to Quarter to Month, and even Day if desired.
*   **Category/Subcategory Drill-down:** For visuals like "Category Performance," you could add `subcategory` below `cleaned_category` on the Axis well to enable drill-down into specific product groups.

#### 6.3. Sync Slicers

If you use multiple pages or want slicer selections to persist across different views, use **Sync Slicers**:
1.  Select a slicer.
2.  Go to the **View** tab on the ribbon.
3.  Click **Sync Slicers**.
4.  In the `Sync Slicers` pane, check the boxes for all pages where you want this slicer to apply.

---

By following these steps, you will build a robust and insightful Festival Sales Analytics Dashboard, empowering you to make data-driven decisions for your future sales strategies. Remember to save your Power BI file regularly!