As a world-class Power BI and data analytics consultant, I will guide you through building a powerful Financial Performance Dashboard. This dashboard will help you understand your revenue, profit margins, cost structure, and even provide basic forecasting, giving you a clear picture of your business's financial health.

---

### 1. Objective

The primary objective of this dashboard is to provide a comprehensive view of your company's financial performance. It will enable you to:
*   Analyze revenue distribution across different product categories and geographies.
*   Evaluate profit margins at various levels (gross and net).
*   Understand the key components of your cost structure, including discounts, delivery charges, and assumed cost of goods sold (COGS).
*   Observe financial trends over time and perform basic forecasting.
*   Identify opportunities for revenue growth and cost optimization.

---

### 2. Data Loading & Preparation

First, let's get your data into Power BI and ensure it's in the correct format for analysis.

1.  **Load the CSV Data:**
    *   Open **Power BI Desktop**.
    *   On the Home tab, click **Get Data**.
    *   Select **Text/CSV**, then click **Connect**.
    *   Navigate to your CSV file, select it, and click **Open**.
    *   In the preview window, ensure **Comma** is selected as the Delimiter, and **Based on first 200 rows** (or entire dataset if needed) for Data Type Detection.
    *   Click **Transform Data**. This will open the Power Query Editor.

2.  **Data Cleaning & Transformation in Power Query Editor:**
    *   **Rename Table:** In the "Queries" pane on the left, right-click `Query1` (or whatever your file is named) and rename it to `Sales Data`.
    *   **Review Data Types:** Power Query often does a good job, but it's crucial to verify.
        *   Scroll through all columns. For each column, click on the data type icon (e.g., `ABC`, `123`) in the header and ensure it's correct.
        *   **`clean_order_date`**: Change to **Date** type.
        *   **`quantity`**: Change to **Whole Number**.
        *   **`product_weight_kg`**: Change to **Decimal Number**.
        *   **`clean_original_price_inr`**: Change to **Decimal Number**.
        *   **`clean_discount_percent`**: Change to **Decimal Number**.
        *   **`clean_final_amount_inr`**: Change to **Decimal Number**.
        *   **`clean_delivery_charges`**: Change to **Decimal Number**.
        *   **`cleaned_customer_rating`**, **`cleaned_product_rating`**: Change to **Decimal Number**.
        *   **`cleaned_is_prime_member`**, **`cleaned_is_prime_eligible`**, **`cleaned_is_festival_sale`**: Change to **True/False**.
        *   **`cleaned_delivery_days`**: Change to **Decimal Number**.
    *   **Handle Nulls (if any for numerical columns):**
        *   For `cleaned_delivery_days`, if you plan to use it in calculations and there are nulls, select the column, go to `Transform` tab, click `Replace Values`, and replace `null` with `0` (or the average/median if more appropriate for your analysis). For this financial dashboard, we won't heavily rely on it, but it's good practice.
        *   `cleaned_customer_rating` and `cleaned_product_rating` may have nulls. If you don't use them directly in financial calculations, they can remain as is.
    *   **Create New Columns (for easier DAX later):**
        *   **Assumption for Cost of Goods Sold (COGS):** Your data does not explicitly provide COGS. For profit analysis, we will *assume* COGS is 60% of the original unit price for each item. **It's critical to note this is an assumption for demonstration purposes; in a real-world scenario, you would need actual COGS data.**
        *   Go to the **Add Column** tab.
        *   Click **Custom Column**.
        *   **`Total Original Price`**: This is the price before any discount for the entire quantity.
            *   New column name: `Total Original Price`
            *   Custom column formula: `[quantity] * [clean_original_price_inr]`
            *   Click OK. Ensure its type is **Decimal Number**.
        *   **`Total Discount Amount`**:
            *   New column name: `Total Discount Amount`
            *   Custom column formula: `[Total Original Price] * [clean_discount_percent] / 100`
            *   Click OK. Ensure its type is **Decimal Number**.
        *   **`Assumed COGS`**: (Crucial for profit calculations)
            *   New column name: `Assumed COGS`
            *   Custom column formula: `[quantity] * [clean_original_price_inr] * 0.60`
            *   Click OK. Ensure its type is **Decimal Number**.

3.  **Apply Changes:**
    *   Once all transformations are done, click **Close & Apply** on the Home tab in Power Query Editor. This will load the cleaned data into Power BI Desktop.

---

### 3. Data Modeling

We'll create a Date table to enable powerful time intelligence functions for trend analysis and forecasting.

1.  **Create a Date Table:**
    *   In Power BI Desktop, go to the **Table view** (the grid icon on the left pane).
    *   On the Home tab, click **New Table**.
    *   Enter the following DAX formula to create a robust Date table. This formula dynamically generates dates from the earliest to the latest order date in your `Sales Data`.

    ```dax
    Date Table = 
    VAR MinDate = MIN('Sales Data'[clean_order_date])
    VAR MaxDate = MAX('Sales Data'[clean_order_date])
    RETURN
        ADDCOLUMNS (
            CALENDAR (MinDate, MaxDate),
            "Year", YEAR ( [Date] ),
            "Month Number", MONTH ( [Date] ),
            "Month Name", FORMAT ( [Date], "MMM" ),
            "Month Name Long", FORMAT ( [Date], "MMMM" ),
            "Quarter", "Q" & FORMAT ( [Date], "Q" ),
            "Day of Week", FORMAT ( [Date], "ddd" ),
            "Day of Week Name", FORMAT ( [Date], "dddd" ),
            "Day of Month", DAY ( [Date] ),
            "Date Key", FORMAT ( [Date], "YYYYMMDD" )
        )
    ```
    *   After the table is created, select the `Date` column in `Date Table`, go to `Column tools` tab, and click `Mark as Date table`. Select `Date` as the Date column.

2.  **Create Relationship:**
    *   Go to the **Model view** (the icon with three tables on the left pane).
    *   You will see your `Sales Data` table and your `Date Table`.
    *   Drag the `Date` column from `Date Table` and drop it onto the `clean_order_date` column in `Sales Data` to create a relationship.
    *   Ensure the relationship is one-to-many (`Date Table` (1) to `Sales Data` (*)). This will allow your date table to filter your sales data correctly.

---

### 4. DAX Measures

Now, let's create the key financial measures using DAX. These measures will be the backbone of your dashboard. Go to the **Report view** (the chart icon on the left pane), right-click on your `Sales Data` table in the "Fields" pane, and select **New Measure** for each.

1.  **Revenue Measures:**

    *   **`Total Gross Revenue`**: Total revenue before any discounts.
        ```dax
        Total Gross Revenue = SUM('Sales Data'[Total Original Price])
        ```
    *   **`Total Net Revenue`**: The actual money received after discounts.
        ```dax
        Total Net Revenue = SUM('Sales Data'[clean_final_amount_inr])
        ```

2.  **Cost Measures:**

    *   **`Total Discount Cost`**: Total amount given as discounts.
        ```dax
        Total Discount Cost = SUM('Sales Data'[Total Discount Amount])
        ```
    *   **`Total Delivery Charges`**: Total delivery costs incurred.
        ```dax
        Total Delivery Charges = SUM('Sales Data'[clean_delivery_charges])
        ```
    *   **`Total Assumed COGS`**: Our calculated Cost of Goods Sold. **(Remember the assumption!)**
        ```dax
        Total Assumed COGS = SUM('Sales Data'[Assumed COGS])
        ```
    *   **`Total Operating Costs`**: Sum of COGS, delivery, and discounts.
        ```dax
        Total Operating Costs = 
        [Total Assumed COGS] + [Total Delivery Charges] + [Total Discount Cost]
        ```

3.  **Profit Measures:**

    *   **`Gross Profit`**: `Total Net Revenue` - `Total Assumed COGS`.
        ```dax
        Gross Profit = [Total Net Revenue] - [Total Assumed COGS]
        ```
    *   **`Net Profit`**: `Gross Profit` - `Total Delivery Charges`. This represents a simplified operating profit after direct costs.
        ```dax
        Net Profit = [Gross Profit] - [Total Delivery Charges]
        ```

4.  **Margin Measures:**

    *   **`Gross Profit Margin %`**: Percentage of revenue left after COGS.
        ```dax
        Gross Profit Margin % = DIVIDE([Gross Profit], [Total Net Revenue], 0)
        ```
        *   *Format this measure as Percentage (`%`) with 2 decimal places.*
    *   **`Net Profit Margin %`**: Percentage of revenue left after COGS and delivery.
        ```dax
        Net Profit Margin % = DIVIDE([Net Profit], [Total Net Revenue], 0)
        ```
        *   *Format this measure as Percentage (`%`) with 2 decimal places.*

5.  **Other Useful Measures:**

    *   **`Average Order Value`**: Average revenue per transaction.
        ```dax
        Average Order Value = DIVIDE([Total Net Revenue], DISTINCTCOUNT('Sales Data'[transaction_id]), 0)
        ```
    *   **`Total Transactions`**: Count of unique transactions.
        ```dax
        Total Transactions = DISTINCTCOUNT('Sales Data'[transaction_id])
        ```

---

### 5. Visualization

Now, let's bring these measures to life with compelling visuals. Go to the **Report view**.

**Dashboard Layout & Design Tips:**
*   **Canvas Size:** Go to `Format` (paint roller icon) -> `Canvas settings` -> `Type` and choose `Custom`. A common size is `1280 x 720` or `1920 x 1080` for higher resolution.
*   **Theme:** Apply a built-in theme (`View` tab -> `Themes`) or create a custom one for consistent branding.
*   **Headers/Titles:** Use text boxes for clear, concise titles for the dashboard and each section.
*   **Colors:** Use a consistent color palette that is easy on the eyes.
*   **Alignment:** Ensure visuals are neatly aligned and distributed.
*   **White Space:** Don't overcrowd the dashboard; leave some white space for readability.

---

**Recommended Visuals:**

1.  **Key Financial KPIs (Card Visuals):**
    *   **Visual Type:** `Card`
    *   **Fields:**
        *   `Total Net Revenue`
        *   `Total Gross Profit`
        *   `Total Net Profit`
        *   `Gross Profit Margin %`
        *   `Net Profit Margin %`
        *   `Total Transactions`
    *   **Placement:** Place these prominently at the top of your dashboard.

2.  **Revenue Breakdown by Category (Bar Chart / Treemap):**
    *   **Visual Type:** `Clustered Column Chart` or `Treemap`
    *   **Fields:**
        *   **Axis/Category:** `cleaned_category` from `Sales Data`
        *   **Values:** `Total Net Revenue`
    *   **Insights:** Shows which product categories are driving the most revenue.

3.  **Revenue Breakdown by Subcategory (Bar Chart - with drill-down):**
    *   **Visual Type:** `Clustered Column Chart`
    *   **Fields:**
        *   **Axis/Category:** `cleaned_category`, then `subcategory` (drag `subcategory` below `cleaned_category` in the Axis field well to enable drill-down).
        *   **Values:** `Total Net Revenue`
    *   **Insights:** Provides a more granular view of revenue contribution.

4.  **Revenue by Customer State (Map Visual):**
    *   **Visual Type:** `Map` (or `Filled Map` for regions)
    *   **Fields:**
        *   **Location:** `customer_state` from `Sales Data`
        *   **Bubble size/Color saturation:** `Total Net Revenue`
    *   **Insights:** Identify top-performing geographical regions.

5.  **Profit Margin Analysis by Category (Bar Chart):**
    *   **Visual Type:** `Clustered Column Chart` or `Clustered Bar Chart`
    *   **Fields:**
        *   **Axis/Category:** `cleaned_category` from `Sales Data`
        *   **Values:** `Gross Profit Margin %`, `Net Profit Margin %`
    *   **Insights:** Compare profitability across different product categories.

6.  **Revenue & Profit Trends Over Time (Line Chart):**
    *   **Visual Type:** `Line Chart`
    *   **Fields:**
        *   **X-axis:** `Date` from `Date Table` (use the hierarchy: Year, Quarter, Month).
        *   **Y-axis:** `Total Net Revenue`, `Gross Profit`, `Net Profit`
    *   **Insights:** Visualize growth, seasonality, and overall trends. This is where you can enable forecasting.

7.  **Cost Structure Breakdown (Donut Chart):**
    *   **Visual Type:** `Donut Chart`
    *   **Fields:**
        *   **Legend:** Create a new table/parameter for cost types (or just drag the measures into Values for a direct breakdown).
        *   **Values:** Drag `Total Assumed COGS`, `Total Discount Cost`, `Total Delivery Charges` into the "Values" field well. Power BI will aggregate these.
    *   **Insights:** Understand the proportion of different cost components relative to each other.

8.  **Financial Forecasting (on Line Chart for `Total Net Revenue`):**
    *   Select the `Line Chart` visual showing `Total Net Revenue` over `Date`.
    *   Go to the **Analytics pane** (magnifying glass icon next to the format roller).
    *   Expand **Forecast**.
    *   Click **Add**.
    *   **Forecast length:** Enter a number (e.g., `12` for 12 months).
    *   **Ignore last:** If your data is incomplete for the current period.
    *   **Confidence interval:** Adjust as needed (e.g., 95%).
    *   **Seasonality:** If your data has clear seasonal patterns (e.g., monthly sales), set this (e.g., `12` for monthly seasonality, `4` for quarterly). Power BI can also auto-detect.
    *   **Insights:** Provides an estimated future trend for your revenue.

---

### 6. Interactivity

Interactivity makes your dashboard dynamic and insightful, allowing users to explore data at their own pace.

1.  **Slicers (Filter the entire dashboard):**
    *   **Visual Type:** `Slicer`
    *   **Fields:**
        *   `Year` from `Date Table` (set as a List or Dropdown)
        *   `Month Name Long` from `Date Table` (set as a List or Dropdown)
        *   `cleaned_category` from `Sales Data` (set as a List or Dropdown)
        *   `customer_tier` from `Sales Data` (set as a List or Dropdown)
        *   `customer_state` from `Sales Data` (set as a List or Dropdown)
        *   `customer_age_group` from `Sales Data` (set as a List or Dropdown)
    *   **Placement:** Typically placed on the left side or top of the dashboard.
    *   **Configuration:** For Year and Month slicers, you might prefer a "List" format, while for others, a "Dropdown" saves space. Enable "Select All" option for convenience.

2.  **Drill-Down Functionality:**
    *   For charts with hierarchies (like `Year` -> `Quarter` -> `Month` on your Line chart, or `cleaned_category` -> `subcategory` on your Bar chart), ensure the drill-down arrows are enabled (top right of the visual).
    *   Users can click the single-down arrow to go to the next level of the hierarchy or the double-down arrow to expand all levels.

3.  **Edit Interactions:**
    *   By default, visuals interact with each other (clicking on one filters others). Sometimes you want to change this behavior (e.g., a slicer filters everything, but clicking on a bar in one chart highlights data in another instead of filtering).
    *   Go to the `Format` tab -> `Edit interactions`.
    *   Select a visual (e.g., a slicer). Then for every other visual, you can choose to `Filter` (the default) or `Highlight` (a small funnel icon vs. a highlighter icon). Or, no interaction at all.

This comprehensive guide should equip you to build a powerful and insightful Financial Performance Dashboard in Power BI, enabling you to derive valuable insights from your sales data. Remember to iterate and refine based on specific questions your business stakeholders might have.