Here's a comprehensive, step-by-step guide to building your Inventory Optimization Dashboard in Power BI, tailored for a new user.

---

### Inventory Optimization Dashboard

#### 1. Objective

The primary objective of this dashboard is to provide a holistic view of product demand patterns, seasonal trends, and sales velocity to facilitate better inventory management and demand forecasting. By analyzing key metrics, users can identify fast-moving products, understand demand drivers, and make informed decisions to optimize stock levels, reduce carrying costs, and prevent stockouts.

#### 2. Data Loading & Preparation

**Step 2.1: Load Data into Power BI**

1.  Open Power BI Desktop.
2.  Click on **Get data** from the Home tab.
3.  Select **Text/CSV** from the common data sources list.
4.  Navigate to your CSV file, select it, and click **Open**.
5.  In the preview window, Power BI should correctly detect the delimiter and data types. Click **Transform Data** to open the Power Query Editor.

**Step 2.2: Data Cleaning and Transformation in Power Query Editor**

The Power Query Editor is where you clean, transform, and shape your data before loading it into the Power BI data model. This is crucial for accurate analysis. We'll assume the loaded table is named `Sales` (you can rename it in Power Query on the left pane under "Query Settings").

1.  **Rename Columns for Readability:**
    *   `clean_order_date` -> `Order Date`
    *   `clean_original_price_inr` -> `Original Price per Unit`
    *   `clean_discount_percent` -> `Discount Percent`
    *   `clean_final_amount_inr` -> `Final Amount`
    *   `clean_delivery_charges` -> `Delivery Charges`
    *   `cleaned_customer_rating` -> `Customer Rating`
    *   `cleaned_product_rating` -> `Product Rating`
    *   `cleaned_customer_city` -> `Customer City`
    *   `cleaned_is_prime_member` -> `Is Prime Member`
    *   `cleaned_is_prime_eligible` -> `Is Prime Eligible`
    *   `cleaned_is_festival_sale` -> `Is Festival Sale`
    *   `cleaned_category` -> `Category`
    *   `cleaned_delivery_days` -> `Delivery Days`

    *To rename: Right-click on the column header -> Rename, or double-click the header.*

2.  **Change Data Types:**
    *   Select the column `Order Date`. Go to the `Transform` tab, click `Data Type` and select **Date**.
    *   Select `quantity`. Set Data Type to **Whole Number**.
    *   Select `product_weight_kg`, `Original Price per Unit`, `Discount Percent`, `Final Amount`, `Delivery Charges`, `corrected_price`. Set Data Type to **Decimal Number**.
    *   Select `Customer Rating`, `Product Rating`. Set Data Type to **Decimal Number**. Power BI's `AVERAGE` function will automatically ignore nulls, so leaving empty values as nulls is acceptable.
    *   Select `Is Prime Member`, `Is Prime Eligible`, `Is Festival Sale`. Set Data Type to **True/False**.
    *   `Delivery Days`: Set Data Type to **Whole Number**.

    *To change data type: Click the icon next to the column name in the header (e.g., "123" for number, "ABC" for text) and choose the appropriate type.*

3.  **Handle Nulls (Optional but Recommended):**
    *   For `Delivery Days`: Some rows might have nulls. If you want to calculate average delivery days, it's better to leave nulls. If you prefer to replace with 0 or an average for some specific use case, you can:
        *   Right-click `Delivery Days` column -> `Replace Values...` -> Leave `Value to Find` empty, enter `0` (or another appropriate value) in `Replace With`. (For this dashboard, leaving as null is fine).
    *   For `Customer Rating` and `Product Rating`: Leaving them as null is standard practice for average calculations.

4.  **Create New Columns (Recommended for Time Intelligence):**
    *   Select the `Order Date` column. Go to the `Add Column` tab.
    *   Click `Date` -> `Year` -> `Year` to extract the year. Rename this to `Year` if desired.
    *   Click `Date` -> `Month` -> `Month` to extract the month number. Rename this to `Month Number`.
    *   Click `Date` -> `Month` -> `Name of Month` to get the month name. Rename this to `Month Name`.
    *   Click `Date` -> `Day` -> `Day of Week` to get the day of the week number. Rename this to `Day of Week Number`.
    *   Click `Date` -> `Day` -> `Name of Day` to get the day of the week name. Rename this to `Day of Week Name`.

5.  **Remove Duplicate Rows (if `duplicate_type` indicates them):**
    *   If `duplicate_type` column indicates actual duplicate transaction, you might want to filter them out. For `duplicate_type` values like `genuine_bulk_order`, these are *not* duplicates but intentional bulk orders. Only remove if `duplicate_type` indicates an actual data entry error or identical rows that shouldn't exist. Based on the sample, we'll assume `genuine_bulk_order` is a valid transaction type and no rows need to be removed for true duplicates.

6.  Once all transformations are complete, click **Close & Apply** from the Home tab to load the cleaned data into Power BI Desktop.

#### 3. Data Modeling

**Step 3.1: Create a Date Table (Calendar Table)**

A dedicated date table is essential for robust time intelligence analysis (e.g., year-over-year, month-over-month comparisons, seasonal trends).

1.  Go to the **Data view** (table icon on the left pane).
2.  Click on **New table** under the `Table tools` tab.
3.  Enter the following DAX formula to create your `Date` table:

    ```dax
    Date = 
    VAR MinDate = CALCULATE(MIN(Sales[Order Date]), ALL(Sales))
    VAR MaxDate = CALCULATE(MAX(Sales[Order Date]), ALL(Sales))
    RETURN
        ADDCOLUMNS (
            CALENDAR (MinDate, MaxDate),
            "Year", YEAR ( [Date] ),
            "Month Number", MONTH ( [Date] ),
            "Month Name", FORMAT ( [Date], "MMM" ),
            "Quarter", "Q" & FORMAT ( [Date], "Q" ),
            "Day of Week", FORMAT ( [Date], "DDD" ),
            "Day Name", FORMAT ( [Date], "DDDD" ),
            "Week Number", WEEKNUM ( [Date], 2 )
        )
    ```

4.  After creating the table, go to the `Date` table. Select the `Month Name` column, then under `Column tools` tab, click `Sort by column` and select `Month Number`. Do the same for `Day of Week` sorting by `Day of Week Name` or `Day of Week Number`.

**Step 3.2: Create Relationships**

1.  Go to the **Model view** (model icon on the left pane).
2.  You will see your `Sales` table and the newly created `Date` table.
3.  Drag the `Order Date` column from the `Sales` table and drop it onto the `Date` column in your `Date` table. This creates a one-to-many relationship (one date in the `Date` table can relate to many transactions in the `Sales` table). Ensure the arrow points from `Date` (one) to `Sales` (many).

#### 4. DAX Measures

Measures are calculations performed on your data. Create these measures in the `Sales` table by right-clicking the table in the `Fields` pane and selecting `New measure`.

1.  **Total Quantity Sold:**
    ```dax
    Total Quantity Sold = SUM(Sales[quantity])
    ```
    *Explanation: Sums the total quantity of products sold.*

2.  **Total Revenue:**
    ```dax
    Total Revenue = SUM(Sales[Final Amount])
    ```
    *Explanation: Sums the final amount paid for all transactions, representing total revenue.*

3.  **Total Gross Sales Value:**
    ```dax
    Total Gross Sales Value = SUMX(Sales, Sales[quantity] * Sales[Original Price per Unit])
    ```
    *Explanation: Calculates the total value of sales at original price before any discounts, per line item, then sums it up.*

4.  **Total Discount Given:**
    ```dax
    Total Discount Given = [Total Gross Sales Value] - [Total Revenue]
    ```
    *Explanation: Calculates the total monetary value of discounts applied.*

5.  **Average Discount Percentage:**
    ```dax
    Average Discount Percentage = DIVIDE([Total Discount Given], [Total Gross Sales Value])
    ```
    *Explanation: Calculates the average discount rate across all sales as a percentage.*

6.  **Average Order Value:**
    ```dax
    Average Order Value = AVERAGEX(DISTINCT(Sales[transaction_id]), CALCULATE(SUM(Sales[Final Amount])))
    ```
    *Explanation: Calculates the average revenue per unique transaction.*

7.  **Number of Unique Products Sold:**
    ```dax
    Number of Unique Products Sold = DISTINCTCOUNT(Sales[product_id])
    ```
    *Explanation: Counts the distinct product IDs that have been sold.*

8.  **Number of Unique Customers:**
    ```dax
    Number of Unique Customers = DISTINCTCOUNT(Sales[customer_id])
    ```
    *Explanation: Counts the distinct customer IDs who made purchases.*

9.  **Average Customer Rating:**
    ```dax
    Average Customer Rating = AVERAGE(Sales[Customer Rating])
    ```
    *Explanation: Calculates the average of customer ratings, ignoring blank values.*

10. **Average Product Rating:**
    ```dax
    Average Product Rating = AVERAGE(Sales[Product Rating])
    ```
    *Explanation: Calculates the average of product ratings, ignoring blank values.*

11. **Average Daily Units Sold (Sales Velocity):**
    ```dax
    Average Daily Units Sold = 
    VAR SelectedDates = VALUES('Date'[Date])
    VAR NumberOfDays = COUNTROWS(SelectedDates)
    RETURN
        IF(NumberOfDays > 0, DIVIDE([Total Quantity Sold], NumberOfDays), 0)
    ```
    *Explanation: Calculates the average quantity of units sold per day for the currently selected period. This is a key metric for inventory velocity.*

12. **Units Sold MoM Growth %:**
    ```dax
    Units Sold MoM Growth % = 
    VAR CurrentMonthUnits = [Total Quantity Sold]
    VAR PreviousMonthUnits = CALCULATE([Total Quantity Sold], PREVIOUSMONTH('Date'[Date]))
    RETURN
        IF(NOT ISBLANK(PreviousMonthUnits) && PreviousMonthUnits <> 0,
            DIVIDE(CurrentMonthUnits - PreviousMonthUnits, PreviousMonthUnits),
            BLANK()
        )
    ```
    *Explanation: Compares the total quantity sold in the current month to the previous month, showing growth percentage.*

13. **Units Sold YoY Growth %:**
    ```dax
    Units Sold YoY Growth % = 
    VAR CurrentYearUnits = [Total Quantity Sold]
    VAR LastYearUnits = CALCULATE([Total Quantity Sold], SAMEPERIODLASTYEAR('Date'[Date]))
    RETURN
        IF(NOT ISBLANK(LastYearUnits) && LastYearUnits <> 0,
            DIVIDE(CurrentYearUnits - LastYearUnits, LastYearUnits),
            BLANK()
        )
    ```
    *Explanation: Compares the total quantity sold in the current period to the same period last year, showing growth percentage.*

#### 5. Visualization

Start with a new blank page. A good dashboard typically has 1-3 pages for different levels of detail.

**Page 1: Overview & Key Performance Indicators**

*   **Layout & Design Tips:**
    *   Use a consistent color palette (e.g., 3-5 colors).
    *   Ensure good contrast for readability.
    *   Align visuals neatly using gridlines (`View` tab -> `Show gridlines`).
    *   Use clear, concise titles for each visual.
    *   Consider a light background with darker text/visuals or vice-versa.
    *   Add a title to the dashboard page, e.g., "Inventory Optimization Dashboard".

*   **Visuals:**

    1.  **Card Visuals (for KPIs):**
        *   Drag **Card** visual.
        *   Add `Total Quantity Sold`.
        *   Add `Total Revenue`.
        *   Add `Average Order Value`.
        *   Add `Average Daily Units Sold`.
        *   Add `Number of Unique Products Sold`.
        *   Add `Number of Unique Customers`.
        *   *Format:* Set font size, category labels, and display units for readability.

    2.  **Line Chart (Demand Trend - Units):**
        *   Drag **Line chart** visual.
        *   **X-axis:** `Date` from `Date` table (use the `Year`, `Quarter`, `Month`, `Day` hierarchy).
        *   **Y-axis:** `Total Quantity Sold`.
        *   *Insight:* Shows overall demand fluctuations over time. Drill down to see monthly/daily patterns.

    3.  **Line Chart (Demand Trend - Revenue):**
        *   Drag **Line chart** visual.
        *   **X-axis:** `Date` from `Date` table (use the `Year`, `Quarter`, `Month`, `Day` hierarchy).
        *   **Y-axis:** `Total Revenue`.
        *   *Insight:* Similar to units, but shows revenue impact.

    4.  **Clustered Column Chart (Seasonal Trend - Units by Month):**
        *   Drag **Clustered column chart** visual.
        *   **X-axis:** `Month Name` from `Date` table.
        *   **Y-axis:** `Total Quantity Sold`.
        *   *Insight:* Clearly highlights peak and trough months for demand.

    5.  **Table/Matrix (Top 10 Products by Quantity):**
        *   Drag **Table** or **Matrix** visual.
        *   **Columns/Rows:** `product_name`, `subcategory`, `brand`.
        *   **Values:** `Total Quantity Sold`, `Average Product Rating`, `Average Daily Units Sold`.
        *   *Filter:* Add a Top N filter on `product_name` for `Top 10` by `Total Quantity Sold`.
        *   *Insight:* Identify best-selling products that require consistent stock.

    6.  **Clustered Bar Chart (Sales by Category):**
        *   Drag **Clustered bar chart** visual.
        *   **Axis:** `Category`.
        *   **Values:** `Total Quantity Sold`.
        *   *Insight:* Understand which product categories drive the most sales volume.

**Page 2: Demand Drivers & Customer Analysis (Optional, can be integrated into Page 1)**

1.  **Clustered Bar Chart (Sales by Customer Tier):**
    *   **Axis:** `customer_tier`.
    *   **Values:** `Total Quantity Sold`, `Total Revenue`.
    *   *Insight:* Helps identify which customer segments contribute most to demand.

2.  **Clustered Bar Chart (Sales by Age Group):**
    *   **Axis:** `customer_age_group`.
    *   **Values:** `Total Quantity Sold`, `Total Revenue`.
    *   *Insight:* Understand demand drivers based on age demographics.

3.  **Funnel Chart (Return Status):**
    *   **Category:** `return_status`.
    *   **Values:** `transaction_id` (Count of).
    *   *Insight:* Visualize the proportion of delivered vs. returned items.

4.  **Stacked Column Chart (Sales by Festival vs. Non-Festival):**
    *   **X-axis:** `Year` from `Date` table.
    *   **Legend:** `Is Festival Sale`.
    *   **Values:** `Total Quantity Sold`.
    *   *Insight:* Quantify the impact of festival sales on demand.

5.  **Map Visual (Sales by Customer State):**
    *   Drag **Map** visual.
    *   **Location:** `customer_state`.
    *   **Bubble Size:** `Total Quantity Sold` or `Total Revenue`.
    *   *Insight:* Geographic demand patterns.

#### 6. Interactivity

**6.1: Slicers**

Slicers allow users to filter the dashboard dynamically. Place them on the right or left side of your dashboard pages.

1.  **Year Slicer:**
    *   Drag **Slicer** visual.
    *   **Field:** `Year` from `Date` table. (Set to `List` or `Dropdown`).

2.  **Month Name Slicer:**
    *   Drag **Slicer** visual.
    *   **Field:** `Month Name` from `Date` table. (Set to `List` or `Dropdown`).

3.  **Category Slicer:**
    *   Drag **Slicer** visual.
    *   **Field:** `Category`.

4.  **Brand Slicer:**
    *   Drag **Slicer** visual.
    *   **Field:** `brand`.

5.  **Customer Tier Slicer:**
    *   Drag **Slicer** visual.
    *   **Field:** `customer_tier`.

6.  **Delivery Type Slicer:**
    *   Drag **Slicer** visual.
    *   **Field:** `delivery_type`.

7.  **Is Festival Sale Slicer:**
    *   Drag **Slicer** visual.
    *   **Field:** `Is Festival Sale` (use `True` / `False`).

**6.2: Cross-filtering**

By default, Power BI visuals cross-filter each other. When you click on a segment in one chart (e.g., a specific month in the seasonal trend chart), other charts will update to show data for that selected month.

*   To modify interactions: Select a visual, then go to the `Format` tab -> `Edit interactions`. You can choose `Filter` or `Highlight` for how other visuals respond, or `None` to prevent interaction.

**6.3: Drill-down/Drill-through (Advanced)**

*   **Drill-down:** For visuals with hierarchies (like the date hierarchy in line charts), Power BI automatically enables drill-down. Users can click the "down arrow" icon in the visual header to navigate from Year to Quarter to Month, etc.
*   **Drill-through (for specific product analysis):**
    1.  Create a new page, name it "Product Details".
    2.  Add `product_name` to the "Drill through" section of this new page's Visualizations pane.
    3.  On the "Product Details" page, create visuals that show details for a *single product* (e.g., a card with its `Average Product Rating`, a line chart showing `Total Quantity Sold` for that product over time, a table of top customers for that product).
    4.  Now, on your main dashboard page, when you right-click on a `product_name` in a table or chart, you'll see a "Drill through" option to go to "Product Details", passing the context of the selected product.

---

This comprehensive guide should equip you to build a powerful and insightful Inventory Optimization Dashboard in Power BI, allowing you to effectively analyze your product demand and make data-driven inventory decisions. Remember to save your Power BI file regularly!