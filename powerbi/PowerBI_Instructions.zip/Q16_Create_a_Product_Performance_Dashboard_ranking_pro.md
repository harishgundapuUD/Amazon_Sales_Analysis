This guide will walk you through building a Product Performance Dashboard in Power BI, enabling you to analyze product revenue, units sold, ratings, and return rates, along with category-wise insights and performance trends over time.

---

### 1. Objective

The primary objective of this dashboard is to provide a comprehensive view of product performance. It aims to rank products based on key metrics (revenue, units sold, average rating, return rate), offer category-specific analysis, and visualize how these metrics evolve over time, giving insights into product lifecycle stages based on sales performance.

---

### 2. Data Loading & Preparation

First, you need to load your CSV data into Power BI and perform essential cleaning and transformations.

**Step 1: Load Data from CSV**

1.  Open Power BI Desktop.
2.  On the Home tab, click **"Get Data"**.
3.  Select **"Text/CSV"** from the common data sources, then click **"Connect"**.
4.  Browse to your CSV file, select it, and click **"Open"**.
5.  A preview window will appear. Ensure "Delimiter" is set to "Comma" and "Data Type Detection" is "Based on first 200 rows" (or "Entire dataset" if preferred).
6.  Click **"Transform Data"**. This will open the Power Query Editor.

**Step 2: Data Cleaning and Transformation in Power Query Editor**

In Power Query Editor, you'll refine your data types and create a useful derived column.

1.  **Rename Table:** In the "Queries" pane on the left, right-click on your table (likely named after your CSV file) and rename it to something descriptive, e.g., `Sales Transactions`.

2.  **Change Data Types:**
    *   Go through each column and ensure it has the correct data type. You can change a data type by clicking the icon next to the column header (e.g., `ABC` for text, `123` for whole number, `1.2` for decimal number, calendar for date).
    *   **Text/String (`ABC`):**
        *   `transaction_id`, `customer_id`, `product_id`, `product_name`, `subcategory`, `brand`, `customer_state`, `customer_tier`, `customer_spending_tier`, `customer_age_group`, `delivery_type`, `festival_name`, `return_status`, `cleaned_customer_city`, `cleaned_category`, `duplicate_type`, `standard_payment_method`
    *   **Whole Number (`123`):**
        *   `quantity`, `order_month`, `order_year`, `order_quarter`
    *   **Decimal Number (`1.2`):**
        *   `product_weight_kg`, `clean_original_price_inr`, `clean_discount_percent`, `clean_final_amount_inr`, `clean_delivery_charges`, `corrected_price`, `cleaned_customer_rating`, `cleaned_product_rating`, `cleaned_delivery_days`
    *   **Date (`Date` icon):**
        *   `clean_order_date` (ensure it's just `Date`, not `Date/Time` if no time component is relevant)
    *   **True/False (`True/False`):**
        *   `cleaned_is_prime_member`, `cleaned_is_prime_eligible`, `cleaned_is_festival_sale`

3.  **Handle Null Values:**
    *   **`cleaned_customer_rating`, `cleaned_product_rating`:** If these columns have nulls, `AVERAGE` measures in DAX will automatically ignore them, which is usually desired. If you want null ratings to count as zero, you can select the columns, right-click, choose "Replace Values", and replace `null` with `0`. For this dashboard, we'll let `AVERAGE` ignore nulls.
    *   **`clean_delivery_charges`:** If a null value implies free delivery, select the column, right-click, choose "Replace Values", and replace `null` with `0`.

4.  **Create a "Is Returned" Column:**
    This column will simplify return rate calculations.
    *   Select the `return_status` column.
    *   Go to the **"Add Column"** tab.
    *   Click **"Conditional Column"**.
    *   Configure it as follows:
        *   New column name: `Is Returned`
        *   If `return_status` `equals` `Returned`
        *   Output: `TRUE`
        *   Else: `FALSE`
    *   Click **"OK"**. Power BI will automatically set its type to True/False.

5.  **Close & Apply:**
    *   Once all transformations are done, click **"Close & Apply"** on the Home tab of Power Query Editor. This will load the transformed data into your Power BI model.

---

### 3. Data Modeling

A robust data model, especially including a date table, is crucial for time-based analysis.

**Step 1: Create a Date Table (DimDate)**

A dedicated date table is essential for time intelligence functions and consistent date filtering.

1.  In Power BI Desktop, go to the **"Table view"** (icon resembling a grid on the left pane).
2.  On the Home tab, click **"New Table"**.
3.  Enter the following DAX formula to create your `DimDate` table. This formula generates a date table covering a wide range, which you can adjust based on your data's earliest and latest dates.

    ```dax
    DimDate = 
    VAR MinDate = MIN('Sales Transactions'[clean_order_date])
    VAR MaxDate = MAX('Sales Transactions'[clean_order_date])
    RETURN
        ADDCOLUMNS (
            CALENDAR (MinDate, MaxDate),
            "DateKey", FORMAT ( [Date], "YYYYMMDD" ),
            "Year", YEAR ( [Date] ),
            "MonthNum", MONTH ( [Date] ),
            "Month", FORMAT ( [Date], "MMM" ),
            "Month Name", FORMAT ( [Date], "MMMM" ),
            "Quarter", "Q" & FORMAT ( [Date], "Q" ),
            "Day", DAY ( [Date] ),
            "Day of Week", WEEKDAY ( [Date] ),
            "Day Name", FORMAT ( [Date], "DDD" ),
            "Full Date", FORMAT ( [Date], "YYYY-MM-DD" ),
            "WeekNum", WEEKNUM ( [Date] )
        )
    ```

4.  After the table is created, go to the **"Model view"** (icon resembling linked tables on the left pane).
5.  Select the `DimDate` table, and in the "Properties" pane (or by right-clicking `DimDate` in the "Fields" pane), mark it as a Date table: **"Mark as date table"** > select `Date` column > click **"OK"**.

**Step 2: Create Relationships**

You need to establish a relationship between your `Sales Transactions` table and the `DimDate` table.

1.  In the **"Model view"**, drag the `clean_order_date` column from your `Sales Transactions` table onto the `Date` column in your `DimDate` table.
2.  This will create a one-to-many relationship (one date in `DimDate` can relate to many transactions in `Sales Transactions`). Ensure the relationship is active and set up correctly.

---

### 4. DAX Measures

These measures will be the backbone of your dashboard's calculations. Go to the **"Report view"** (first icon on the left pane), select your `Sales Transactions` table in the "Fields" pane, and click **"New Measure"** on the Home tab for each measure.

1.  **Total Revenue**
    Calculates the sum of the final amount for all transactions.
    ```dax
    Total Revenue = SUM('Sales Transactions'[clean_final_amount_inr])
    ```

2.  **Total Units Sold**
    Calculates the sum of all quantities sold.
    ```dax
    Total Units Sold = SUM('Sales Transactions'[quantity])
    ```

3.  **Total Transactions**
    Counts the number of unique transactions.
    ```dax
    Total Transactions = DISTINCTCOUNT('Sales Transactions'[transaction_id])
    ```

4.  **Average Product Rating**
    Calculates the average of product ratings. Nulls are ignored.
    ```dax
    Average Product Rating = AVERAGE('Sales Transactions'[cleaned_product_rating])
    ```
    *Note: This averages all ratings. If you want the average of distinct product ratings (i.e., each product counts once), it's more complex and often not necessary unless the `cleaned_product_rating` can vary wildly for the *same* `product_id` across transactions, which is less common for a product's intrinsic rating.*

5.  **Total Returns**
    Counts transactions where the `Is Returned` flag is TRUE.
    ```dax
    Total Returns = CALCULATE([Total Transactions], 'Sales Transactions'[Is Returned] = TRUE())
    ```

6.  **Return Rate**
    Calculates the percentage of returned transactions out of total transactions.
    ```dax
    Return Rate = DIVIDE([Total Returns], [Total Transactions])
    ```
    *Format this measure as a Percentage (e.g., 0.00%).*

7.  **Average Order Value**
    Calculates the average revenue per transaction.
    ```dax
    Average Order Value = DIVIDE([Total Revenue], [Total Transactions])
    ```

8.  **Unique Products Sold**
    Counts the distinct number of products sold.
    ```dax
    Unique Products Sold = DISTINCTCOUNT('Sales Transactions'[product_id])
    ```

---

### 5. Visualization

Now, let's build the dashboard visuals. Go to the **"Report view"** in Power BI Desktop.

**Dashboard Layout & Design Tips:**

*   **Page Title:** Add a Text Box at the top, e.g., "Product Performance Dashboard".
*   **Consistent Branding:** Use a consistent color palette and font scheme.
*   **Clear Headings:** Ensure each visual has a descriptive title.
*   **Tooltips:** Enable tooltips for all visuals to provide more detail on hover.

**Visuals to Create:**

#### A. Key Performance Indicators (KPIs) - Use Card Visuals

Place these prominently at the top of your dashboard.

1.  **Total Revenue:**
    *   **Visual:** Card
    *   **Field:** `Total Revenue` measure
    *   *Formatting:* Set display units to `Auto` or `Millions`.

2.  **Total Units Sold:**
    *   **Visual:** Card
    *   **Field:** `Total Units Sold` measure

3.  **Average Product Rating:**
    *   **Visual:** Card
    *   **Field:** `Average Product Rating` measure
    *   *Formatting:* Display as a decimal number (e.g., 3.9).

4.  **Return Rate:**
    *   **Visual:** Card
    *   **Field:** `Return Rate` measure
    *   *Formatting:* Ensure it's displayed as a percentage.

5.  **Unique Products Sold:**
    *   **Visual:** Card
    *   **Field:** `Unique Products Sold` measure

#### B. Product Ranking - Use Clustered Bar Charts

These visuals will help identify top-performing (and underperforming) products. Use filters to show "Top N" items (e.g., Top 10).

1.  **Top 10 Products by Revenue:**
    *   **Visual:** Clustered Bar Chart
    *   **Y-axis:** `product_name` (from `Sales Transactions`)
    *   **X-axis:** `Total Revenue` measure
    *   **Filter:** On the `product_name` field, apply a "Top N" filter, showing "Top 10" by `Total Revenue`.

2.  **Top 10 Products by Units Sold:**
    *   **Visual:** Clustered Bar Chart
    *   **Y-axis:** `product_name`
    *   **X-axis:** `Total Units Sold` measure
    *   **Filter:** On `product_name`, "Top 10" by `Total Units Sold`.

3.  **Top 10 Products by Average Rating:**
    *   **Visual:** Clustered Bar Chart
    *   **Y-axis:** `product_name`
    *   **X-axis:** `Average Product Rating` measure
    *   **Filter:** On `product_name`, "Top 10" by `Average Product Rating`.

4.  **Top 10 Products by Return Rate:**
    *   **Visual:** Clustered Bar Chart
    *   **Y-axis:** `product_name`
    *   **X-axis:** `Return Rate` measure
    *   **Filter:** On `product_name`, "Top 10" by `Return Rate`. (You might want "Bottom 10" for high return rates, adjust the filter accordingly).

#### C. Category-Wise Analysis

1.  **Revenue by Category:**
    *   **Visual:** Donut Chart or Treemap
    *   **Legend/Group:** `cleaned_category` (from `Sales Transactions`)
    *   **Values:** `Total Revenue` measure

2.  **Units Sold by Subcategory:**
    *   **Visual:** Treemap or Clustered Bar Chart
    *   **Group:** `subcategory` (from `Sales Transactions`)
    *   **Values:** `Total Units Sold` measure

3.  **Return Rate by Category:**
    *   **Visual:** Clustered Bar Chart
    *   **Y-axis:** `cleaned_category`
    *   **X-axis:** `Return Rate` measure

#### D. Product Performance Over Time (Lifecycle Tracking)

These line charts help visualize trends and performance phases.

1.  **Total Revenue Over Time:**
    *   **Visual:** Line Chart
    *   **X-axis:** `Date` (from `DimDate`) - You can expand this to `Year` or `Month` for different granularities.
    *   **Y-axis:** `Total Revenue` measure

2.  **Total Units Sold Over Time:**
    *   **Visual:** Line Chart
    *   **X-axis:** `Date` (from `DimDate`)
    *   **Y-axis:** `Total Units Sold` measure

*Note on Product Lifecycle Tracking:* True product lifecycle tracking (from launch to obsolescence) often requires explicit launch/end dates per product. With this dataset, "lifecycle tracking" primarily means observing performance trends over time using the available transaction data. If you want to identify when a product first appeared, you could use a DAX measure like `MIN('Sales Transactions'[clean_order_date])` for each product.

---

### 6. Interactivity

Enhance user experience with slicers and drill-down capabilities.

#### A. Slicers

Place slicers strategically, often on the left or top of the dashboard page.

1.  **Year Slicer:**
    *   **Visual:** Slicer
    *   **Field:** `Year` (from `DimDate`)
    *   *Settings:* Set to "List" or "Dropdown" and enable "Select all" option.

2.  **Category Slicer:**
    *   **Visual:** Slicer
    *   **Field:** `cleaned_category` (from `Sales Transactions`)
    *   *Settings:* "List" or "Dropdown", "Select all".

3.  **Subcategory Slicer:**
    *   **Visual:** Slicer
    *   **Field:** `subcategory` (from `Sales Transactions`)
    *   *Settings:* "List" or "Dropdown", "Select all".

4.  **Brand Slicer:**
    *   **Visual:** Slicer
    *   **Field:** `brand` (from `Sales Transactions`)
    *   *Settings:* "List" or "Dropdown", "Select all".

5.  **Customer Tier Slicer:**
    *   **Visual:** Slicer
    *   **Field:** `customer_tier` (from `Sales Transactions`)
    *   *Settings:* "List" or "Dropdown", "Select all".

6.  **Return Status Slicer:**
    *   **Visual:** Slicer
    *   **Field:** `return_status` (from `Sales Transactions`)
    *   *Settings:* "List" or "Dropdown", "Select all".

#### B. Drill-down/Drill-through

1.  **Drill-down:**
    *   For charts showing category or subcategory data (e.g., "Units Sold by Subcategory"), you can enable drill-down. Place `cleaned_category` first, then `subcategory` in the Axis/Group well. Users can then right-click a category and choose "Drill down" to see subcategory details.
    *   For time-series charts, you can add `Year`, `Quarter`, `Month`, `Date` to the X-axis well (in that order) to allow drill-down into different time granularities.

2.  **Edit Interactions:**
    *   By default, visuals interact with each other (clicking on a category in one chart filters others). To customize this, select a visual, go to the **"Format"** tab (under "Visualizations"), and click **"Edit interactions"**. This allows you to specify whether a visual should filter, highlight, or do nothing when another visual is selected. Ensure your slicers filter all relevant charts.

By following these steps, you'll be able to create a powerful and insightful Product Performance Dashboard in Power BI, addressing all the user's requirements.