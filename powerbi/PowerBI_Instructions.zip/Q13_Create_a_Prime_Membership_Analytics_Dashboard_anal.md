This comprehensive guide will walk you through building a Power BI dashboard focused on Prime Membership Analytics. We'll cover everything from data loading and preparation to creating measures, designing visualizations, and setting up interactivity.

---

### 1. Objective

The primary objective of this Power BI dashboard is to provide a deep dive into Prime vs. Non-Prime customer behavior. This includes analyzing sales, order patterns, customer engagement, and identifying key business insights specific to Prime membership, ultimately aiding in understanding membership value and potential retention drivers.

---

### 2. Data Loading & Preparation

First, you need to get your CSV data into Power BI and ensure it's clean and correctly formatted.

1.  **Load the CSV Data:**
    *   Open Power BI Desktop.
    *   Go to the "Home" tab on the ribbon.
    *   Click "Get data" -> "Text/CSV".
    *   Navigate to your CSV file, select it, and click "Open".
    *   In the preview window, Power BI should automatically detect the delimiter (comma) and data types.
    *   Click "Transform Data" to open the Power Query Editor. This is where we'll clean and prepare our data.

2.  **Power Query Editor: Data Cleaning & Transformation:**
    *   **Rename Query:** In the "Query Settings" pane on the right, under "Name," rename "your_csv_file_name" to something more descriptive, like `Sales Transactions`.
    *   **Review and Adjust Data Types:** It's crucial that each column has the correct data type for accurate calculations and visualization. Go through each column and ensure it's set correctly.
        *   `transaction_id`, `customer_id`, `product_id`, `product_name`, `subcategory`, `brand`, `customer_state`, `customer_tier`, `customer_spending_tier`, `customer_age_group`, `delivery_type`, `festival_name`, `return_status`, `cleaned_customer_city`, `duplicate_type`, `standard_payment_method`, `cleaned_category`: **Text** (ABC icon).
        *   `quantity`, `order_month`, `order_year`, `order_quarter`: **Whole Number** (123 icon).
        *   `product_weight_kg`, `clean_original_price_inr`, `clean_discount_percent`, `clean_final_amount_inr`, `clean_delivery_charges`, `corrected_price`, `cleaned_customer_rating`, `cleaned_product_rating`, `cleaned_delivery_days`: **Decimal Number** (1.2 icon).
        *   `clean_order_date`: **Date** (Calendar icon). Ensure it's correctly parsed.
        *   `cleaned_is_prime_member`, `cleaned_is_prime_eligible`, `cleaned_is_festival_sale`: **True/False (Boolean)** icon.
    *   **Handle Nulls/Errors:**
        *   **Ratings (`cleaned_customer_rating`, `cleaned_product_rating`):** Right-click column header -> "Replace Values". For "Value To Find," leave blank (or type 'null' if it's explicitly 'null' text), for "Replace With," type `0` or `(Blank)` to treat missing ratings as nulls or zero. This depends on interpretation; `0` might skew averages. For averages, it's often better to leave them as `null` and let DAX measures ignore them.
        *   **Delivery Days (`cleaned_delivery_days`):** Handle similarly to ratings if nulls are present.
        *   **Festival Name (`festival_name`):** If there are blank values, right-click -> "Replace Values", find blank/null, replace with "No Festival".
    *   **Create a "Prime Status" Column (Conditional Column):** This will make your visuals easier to read.
        *   Go to the "Add Column" tab on the ribbon.
        *   Click "Conditional Column".
        *   **New column name:** `Prime Status`
        *   **If:** `cleaned_is_prime_member` **equals** `TRUE`
        *   **Output:** `Prime Member`
        *   **Else If:** `cleaned_is_prime_member` **equals** `FALSE`
        *   **Output:** `Non-Prime Member`
        *   **Else:** `Unknown` (or `Non-Prime Member` if you're sure `FALSE` covers all non-prime cases).
        *   Click "OK".
    *   **Close & Apply:** Once all transformations are done, click "Close & Apply" on the "Home" tab of Power Query Editor. This will load the transformed data into your Power BI data model.

---

### 3. Data Modeling

A robust data model is essential for time-intelligence functions and clear relationships.

1.  **Create a Date Table (DAX):**
    *   Go to the "Table tools" tab (or "Modeling" tab in older versions).
    *   Click "New Table".
    *   Paste the following DAX code to create a dynamic Date Table. Rename `Sales Transactions` to your actual table name if different.
    ```DAX
    Date Table = 
    VAR MinDate = MIN('Sales Transactions'[clean_order_date])
    VAR MaxDate = MAX('Sales Transactions'[clean_order_date])
    VAR CalendarTable = 
        CALENDAR(MinDate, MaxDate)
    RETURN
        ADDCOLUMNS(
            CalendarTable,
            "Year", YEAR([Date]),
            "MonthNum", MONTH([Date]),
            "Month", FORMAT([Date], "MMM"),
            "Month Name", FORMAT([Date], "MMMM"),
            "Quarter", "Q" & FORMAT([Date], "Q"),
            "Day", DAY([Date]),
            "Day of Week", FORMAT([Date], "ddd"),
            "Day Name", FORMAT([Date], "dddd"),
            "Week Num", WEEKNUM([Date])
        )
    ```
    *   **Sort Columns:** To ensure Month and Quarter slicers/charts sort correctly, go to the "Data" view, select the `Date Table`.
        *   Select the `Month` column, go to "Column tools" -> "Sort by column" -> `MonthNum`.
        *   Select the `Month Name` column, go to "Column tools" -> "Sort by column" -> `MonthNum`.
        *   Select the `Day of Week` column, sort by `Day` (or create a custom sort order for days if needed).
    *   **Mark as Date Table:** With the `Date Table` selected, go to "Table tools" -> "Mark as date table" -> select the `Date` column.

2.  **Create Relationships:**
    *   Go to the "Model" view (the three tables icon on the left pane).
    *   Drag the `Date` column from your `Date Table` to the `clean_order_date` column in your `Sales Transactions` table.
    *   This will create a `One-to-Many` relationship (Date Table to Sales Transactions) with `Single` filter direction.

---

### 4. DAX Measures

These measures will form the backbone of your analytics. To create a measure, go to the "Home" tab -> "New Measure", or right-click on your `Sales Transactions` table in the "Fields" pane -> "New measure".

1.  **Core Sales & Order Metrics:**

    ```DAX
    Total Sales (INR) = SUM('Sales Transactions'[clean_final_amount_inr])
    ```
    *   *Explanation:* Calculates the sum of the final amount for all transactions.

    ```DAX
    Total Quantity Sold = SUM('Sales Transactions'[quantity])
    ```
    *   *Explanation:* Calculates the total number of products sold.

    ```DAX
    Total Orders = DISTINCTCOUNT('Sales Transactions'[transaction_id])
    ```
    *   *Explanation:* Counts the unique number of transactions.

    ```DAX
    Average Order Value (INR) = DIVIDE([Total Sales (INR)], [Total Orders], 0)
    ```
    *   *Explanation:* Average revenue per transaction. `DIVIDE` handles division by zero errors.

    ```DAX
    Total Customers = DISTINCTCOUNT('Sales Transactions'[customer_id])
    ```
    *   *Explanation:* Total number of unique customers.

2.  **Prime vs. Non-Prime Breakdown:**

    ```DAX
    Total Sales - Prime (INR) = CALCULATE([Total Sales (INR)], 'Sales Transactions'[cleaned_is_prime_member] = TRUE())
    ```
    *   *Explanation:* Total sales generated specifically by Prime members.

    ```DAX
    Total Sales - Non-Prime (INR) = CALCULATE([Total Sales (INR)], 'Sales Transactions'[cleaned_is_prime_member] = FALSE())
    ```
    *   *Explanation:* Total sales generated by Non-Prime members.

    ```DAX
    Total Orders - Prime = CALCULATE([Total Orders], 'Sales Transactions'[cleaned_is_prime_member] = TRUE())
    ```
    *   *Explanation:* Total orders placed by Prime members.

    ```DAX
    Total Orders - Non-Prime = CALCULATE([Total Orders], 'Sales Transactions'[cleaned_is_prime_member] = FALSE())
    ```
    *   *Explanation:* Total orders placed by Non-Prime members.

    ```DAX
    Prime Sales % = DIVIDE([Total Sales - Prime (INR)], [Total Sales (INR)], 0)
    ```
    *   *Explanation:* Percentage of total sales coming from Prime members. Format as Percentage.

    ```DAX
    Prime Order % = DIVIDE([Total Orders - Prime], [Total Orders], 0)
    ```
    *   *Explanation:* Percentage of total orders placed by Prime members. Format as Percentage.

    ```DAX
    Unique Customers - Prime = CALCULATE([Total Customers], 'Sales Transactions'[cleaned_is_prime_member] = TRUE())
    ```
    *   *Explanation:* Total unique Prime customers.

    ```DAX
    Unique Customers - Non-Prime = CALCULATE([Total Customers], 'Sales Transactions'[cleaned_is_prime_member] = FALSE())
    ```
    *   *Explanation:* Total unique Non-Prime customers.

3.  **Engagement & Value Metrics:**

    ```DAX
    Avg Customer Rating - Prime = CALCULATE(AVERAGE('Sales Transactions'[cleaned_customer_rating]), 'Sales Transactions'[cleaned_is_prime_member] = TRUE())
    ```
    *   *Explanation:* Average customer rating given by Prime members.

    ```DAX
    Avg Customer Rating - Non-Prime = CALCULATE(AVERAGE('Sales Transactions'[cleaned_customer_rating]), 'Sales Transactions'[cleaned_is_prime_member] = FALSE())
    ```
    *   *Explanation:* Average customer rating given by Non-Prime members.

    ```DAX
    Avg Delivery Days - Prime = CALCULATE(AVERAGE('Sales Transactions'[cleaned_delivery_days]), 'Sales Transactions'[cleaned_is_prime_member] = TRUE())
    ```
    *   *Explanation:* Average delivery days for Prime member orders.

    ```DAX
    Avg Delivery Days - Non-Prime = CALCULATE(AVERAGE('Sales Transactions'[cleaned_delivery_days]), 'Sales Transactions'[cleaned_is_prime_member] = FALSE())
    ```
    *   *Explanation:* Average delivery days for Non-Prime member orders.

    ```DAX
    Avg Items per Order - Prime = DIVIDE(CALCULATE([Total Quantity Sold], 'Sales Transactions'[cleaned_is_prime_member] = TRUE()), [Total Orders - Prime], 0)
    ```
    *   *Explanation:* Average number of items in an order placed by Prime members.

    ```DAX
    Avg Items per Order - Non-Prime = DIVIDE(CALCULATE([Total Quantity Sold], 'Sales Transactions'[cleaned_is_prime_member] = FALSE()), [Total Orders - Non-Prime], 0)
    ```
    *   *Explanation:* Average number of items in an order placed by Non-Prime members.

4.  **Repeat Purchase/Retention (Proxy):**
    *   *Note:* True retention requires tracking customers over time across multiple orders. This measure calculates the percentage of customers who have made *more than one order within the currently filtered period*.

    ```DAX
    Repeat Customers = 
    VAR CustomersWithOrders =
        SUMMARIZE(
            'Sales Transactions',
            'Sales Transactions'[customer_id],
            "OrderCount", DISTINCTCOUNT('Sales Transactions'[transaction_id])
        )
    RETURN
        CALCULATE(
            COUNTROWS(CustomersWithOrders),
            FILTER(
                CustomersWithOrders,
                [OrderCount] > 1
            )
        )
    ```
    *   *Explanation:* Counts customers who have placed more than one distinct order in the current filter context.

    ```DAX
    Repeat Customer Rate = DIVIDE([Repeat Customers], [Total Customers], 0)
    ```
    *   *Explanation:* Percentage of customers who are repeat buyers in the period. Format as Percentage.

    ```DAX
    Repeat Customer Rate - Prime = 
    VAR PrimeCustomersWithOrders =
        SUMMARIZE(
            FILTER('Sales Transactions', 'Sales Transactions'[cleaned_is_prime_member] = TRUE()),
            'Sales Transactions'[customer_id],
            "OrderCount", DISTINCTCOUNT('Sales Transactions'[transaction_id])
        )
    VAR PrimeRepeatCustomers =
        CALCULATE(
            COUNTROWS(PrimeCustomersWithOrders),
            FILTER(
                PrimeCustomersWithOrders,
                [OrderCount] > 1
            )
        )
    VAR TotalPrimeCustomers = CALCULATE([Total Customers], 'Sales Transactions'[cleaned_is_prime_member] = TRUE())
    RETURN
        DIVIDE(PrimeRepeatCustomers, TotalPrimeCustomers, 0)
    ```
    *   *Explanation:* Repeat customer rate specifically for Prime members. Format as Percentage.
    *   *Create `Repeat Customer Rate - Non-Prime` by changing `TRUE()` to `FALSE()` in the above formula.*

---

### 5. Visualization

Let's design a two-page dashboard for clarity:
*   **Page 1: Prime Membership Overview**
*   **Page 2: Prime Member Deep Dive & Insights**

#### Page 1: Prime Membership Overview

1.  **Dashboard Title:** Add a "Text box" with a title like "Prime Membership Analytics Dashboard". (Font size ~28-36, Bold)

2.  **Key Performance Indicators (KPIs) - Card Visuals:**
    *   **Total Sales (INR):** Card visual, Field: `Total Sales (INR)`.
    *   **Total Orders:** Card visual, Field: `Total Orders`.
    *   **Prime Sales %:** Card visual, Field: `Prime Sales %`.
    *   **Total Prime Customers:** Card visual, Field: `Unique Customers - Prime`.
    *   **Repeat Customer Rate - Prime:** Card visual, Field: `Repeat Customer Rate - Prime`.
    *   *Styling:* Place these cards prominently at the top, perhaps in a row. Use clear labels and a consistent font.

3.  **Sales & Orders Comparison (Prime vs. Non-Prime) - Clustered Column Charts:**
    *   **Visual 1 (Total Sales):** Clustered Column Chart.
        *   X-axis: `Prime Status` (from `Sales Transactions` table).
        *   Y-axis: `Total Sales (INR)`.
    *   **Visual 2 (Total Orders):** Clustered Column Chart.
        *   X-axis: `Prime Status`.
        *   Y-axis: `Total Orders`.
    *   *Insights:* Directly compare the scale of sales and orders between Prime and Non-Prime.

4.  **Sales Trend Over Time - Line Chart:**
    *   **Visual:** Line Chart.
        *   X-axis: `Date` (from `Date Table`).
        *   Y-axis: `Total Sales (INR)`.
        *   Legend: `Prime Status`.
    *   *Insights:* Observe how Prime and Non-Prime sales evolve over months/years, especially during sale events.

5.  **Average Engagement Metrics - Multi-row Card or Table:**
    *   **Visual:** Multi-row Card or Table.
        *   Fields: `Avg Customer Rating - Prime`, `Avg Customer Rating - Non-Prime`, `Avg Delivery Days - Prime`, `Avg Delivery Days - Non-Prime`, `Avg Items per Order - Prime`, `Avg Items per Order - Non-Prime`.
    *   *Insights:* Compare service expectations and behavior. Lower delivery days for Prime is expected; higher ratings indicate satisfaction.

6.  **Top Categories by Sales (Prime vs Non-Prime) - Matrix Visual:**
    *   **Visual:** Matrix.
        *   Rows: `cleaned_category`.
        *   Columns: `Prime Status`.
        *   Values: `Total Sales (INR)`.
    *   *Insights:* Identify which product categories perform well with each membership type.

#### Page 2: Prime Member Deep Dive & Insights

1.  **Dashboard Title:** Add a "Text box" with a title like "Prime Member Deep Dive".

2.  **Prime Sales by Customer Demographics - Donut & Bar Charts:**
    *   **Visual 1 (Spending Tier):** Donut Chart.
        *   Legend: `customer_spending_tier`.
        *   Values: `Total Sales - Prime (INR)`.
    *   **Visual 2 (Age Group):** Clustered Bar Chart.
        *   Y-axis: `customer_age_group`.
        *   X-axis: `Total Sales - Prime (INR)`.
    *   *Insights:* Understand the demographics of your highest-value Prime customers.

3.  **Prime Sales by Geography - Filled Map:**
    *   **Visual:** Filled Map.
        *   Location: `customer_state`.
        *   Color saturation: `Total Sales - Prime (INR)`.
    *   *Insights:* Identify regions with strong Prime member activity.

4.  **Top Prime Products/Brands - Clustered Bar Chart:**
    *   **Visual:** Clustered Bar Chart.
        *   Y-axis: `product_name` or `brand` (Filter to Top N, e.g., Top 10 by `Total Sales - Prime (INR)`).
        *   X-axis: `Total Sales - Prime (INR)`.
    *   *Insights:* Discover the most popular products or brands among Prime members.

5.  **Prime Repeat Customer Rate Trend - Line Chart:**
    *   **Visual:** Line Chart.
        *   X-axis: `Date` (Year-Month from `Date Table`).
        *   Y-axis: `Repeat Customer Rate - Prime`.
    *   *Insights:* Monitor the trend of Prime repeat purchases over time.

6.  **Festival Sale Impact (Prime) - Clustered Column Chart:**
    *   **Visual:** Clustered Column Chart.
        *   X-axis: `festival_name` (Filter to exclude "No Festival" if desired).
        *   Y-axis: `Total Sales - Prime (INR)`.
    *   *Insights:* Analyze how Prime sales are influenced by different festival sales.

#### Design Tips:
*   **Layout:** Arrange visuals in a logical flow, perhaps with KPIs at the top, trends below, and comparisons/distributions around. Use gridlines or align objects to keep it neat.
*   **Colors:** Choose a professional and consistent color palette. Use contrasting colors to differentiate Prime vs. Non-Prime.
*   **Titles:** Give each visual a clear, descriptive title.
*   **Formatting:** Apply appropriate formatting to numbers (e.g., currency for sales, percentage for rates, no decimals for counts).

---

### 6. Interactivity

Interactivity allows users to explore data dynamically.

1.  **Slicers (on both pages):**
    *   **Date Slicer:** Slicer visual. Field: `Year` and `Month Name` from `Date Table`. Use a "list" or "dropdown" for year and "list" for month for easy selection.
    *   **Category Slicer:** Slicer visual. Field: `cleaned_category`.
    *   **Subcategory Slicer:** Slicer visual. Field: `subcategory`.
    *   **Brand Slicer:** Slicer visual. Field: `brand`.
    *   **Customer State Slicer:** Slicer visual. Field: `customer_state`.
    *   **Customer Spending Tier Slicer:** Slicer visual. Field: `customer_spending_tier`.
    *   **Customer Age Group Slicer:** Slicer visual. Field: `customer_age_group`.
    *   *Placement:* Place slicers on the left or right side of the dashboard, organized logically.
    *   *Sync Slicers:* Go to "View" tab -> "Sync slicers" pane. Select all slicers you want to apply across multiple pages (e.g., Date, Category) and ensure they are synced to both pages.

2.  **Cross-Filtering:** By default, clicking on a data point in one visual will filter other visuals on the page. This is usually desirable. If you want to change this behavior (e.g., make a visual *not* filter others), select the visual, go to "Format" tab -> "Edit interactions", and choose the desired interaction type (filter, highlight, or none).

3.  **Drill Down/Up (for hierarchical data):**
    *   For visuals like the line chart with `Date` on the X-axis, Power BI automatically allows drilling down from Year to Quarter, then Month, then Day. Use the drill-down/up arrows on the visual header to navigate.
    *   For the Matrix visual, if you add `cleaned_category` and then `subcategory` under Rows, you can use the drill-down options to explore categories and their subcategories.

By following these steps, you will construct a powerful and insightful Power BI dashboard for Prime Membership Analytics, enabling you to understand and leverage the value of your Prime customers effectively.