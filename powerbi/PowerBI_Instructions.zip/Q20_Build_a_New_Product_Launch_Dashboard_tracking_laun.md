As a world-class Power BI consultant, I'm thrilled to help you build a robust "New Product Launch Dashboard." This dashboard will provide critical insights into product performance, market acceptance, and customer engagement, empowering your product development teams to make data-driven decisions.

Here’s a step-by-step guide to building your dashboard in Power BI Desktop:

---

### 1. Objective

The primary objective of this dashboard is to monitor and analyze the performance of newly launched products. It aims to provide insights into sales trajectory, market acceptance (via ratings and returns), customer demographics, and competitive positioning (brands/categories), enabling product teams to understand success metrics and identify areas for improvement.

---

### 2. Data Loading & Preparation

First, let's get your data into Power BI and ensure it's clean and ready for analysis.

1.  **Load the CSV Data:**
    *   Open Power BI Desktop.
    *   Go to the "Home" tab.
    *   Click on "Get Data" and select "Text/CSV".
    *   Navigate to your CSV file, select it, and click "Open".
    *   In the preview window, Power BI will usually detect the delimiter and data types automatically. Review it.
    *   Click "Transform Data" to open the Power Query Editor. This is crucial for cleaning and shaping your data.

2.  **Data Cleaning & Transformation in Power Query Editor:**
    *   **Rename Query:** In the "Queries" pane on the left, right-click `Query1` (or whatever your CSV file name is) and rename it to `Sales`.
    *   **Review and Correct Data Types:** Power BI often does a good job, but always double-check. Click on the icon next to each column header to change its data type if necessary.
        *   `transaction_id`, `customer_id`, `product_id`, `product_name`, `subcategory`, `brand`, `customer_state`, `customer_tier`, `customer_spending_tier`, `customer_age_group`, `delivery_type`, `festival_name`, `return_status`, `cleaned_customer_city`, `cleaned_category`, `duplicate_type`, `standard_payment_method`: **Text**
        *   `quantity`, `order_month`, `order_year`, `order_quarter`: **Whole Number**
        *   `product_weight_kg`, `clean_original_price_inr`, `clean_discount_percent`, `clean_final_amount_inr`, `clean_delivery_charges`, `cleaned_customer_rating`, `cleaned_product_rating`, `cleaned_delivery_days`, `corrected_price`: **Decimal Number**
        *   `clean_order_date`: **Date** (ensure it's just Date, not Date/Time if time isn't relevant)
        *   `cleaned_is_prime_member`, `cleaned_is_prime_eligible`, `cleaned_is_festival_sale`: **True/False** (Boolean)
    *   **Handle Nulls:**
        *   `festival_name`: Right-click the column header, select "Replace Values". In "Value To Find", type `null` (or leave blank if it appears blank), and in "Replace With", type `No Festival`. Click OK.
        *   `product_weight_kg`, `clean_delivery_charges`, `cleaned_delivery_days`: Right-click column header, select "Replace Values". In "Value To Find", type `null` (or leave blank), and in "Replace With", type `0`. Click OK.
        *   For `cleaned_customer_rating` and `cleaned_product_rating`, it's best to leave nulls as they are. When calculating averages, Power BI's DAX functions like `AVERAGE` automatically ignore nulls, which is typically the desired behavior for ratings.
    *   **Remove Duplicate Columns (Optional but Recommended):** You have `clean_original_price_inr` and `corrected_price`. If `corrected_price` is the definitive value, you might remove `clean_original_price_inr` if it's no longer needed. For this guide, we'll keep it but rely on `clean_final_amount_inr` for revenue calculations. `order_month`, `order_year`, `order_quarter` will be superseded by the Date Table, but can be kept for initial filtering if preferred.
    *   Once all transformations are complete, click "Close & Apply" from the "Home" tab in Power Query Editor.

---

### 3. Data Modeling

A robust data model is essential for effective analysis.

1.  **Create a Date Table:**
    A separate date table allows for powerful time-based analysis and filtering.
    *   Go to the "Table view" (Data view) on the left side of Power BI Desktop.
    *   Click "New Table" from the "Table tools" tab.
    *   Paste the following DAX code to create your Date table:
        ```dax
        Date =
        ADDCOLUMNS (
            CALENDARAUTO (),
            "Year", YEAR ( [Date] ),
            "MonthNum", MONTH ( [Date] ),
            "Month", FORMAT ( [Date], "MMM" ),
            "Year Month", FORMAT ( [Date], "YYYY-MM" ),
            "Quarter", "Q" & FORMAT ( [Date], "Q" ),
            "Day of Week", FORMAT ( [Date], "dddd" )
        )
        ```
    *   After creating the table, select the `Month` column and click "Sort by column" in the "Column tools" tab, then select `MonthNum` to ensure months sort correctly (Jan-Dec).
    *   Mark `Date` table as a Date table: With `Date` table selected, in "Table tools" tab, click "Mark as Date table" -> "Mark as Date table", then select `Date` column.

2.  **Create Relationship:**
    *   Go to the "Model view" on the left side of Power BI Desktop.
    *   You will see your `Sales` table and your newly created `Date` table.
    *   Drag the `Date` column from the `Date` table and drop it onto the `clean_order_date` column in the `Sales` table.
    *   This will create a one-to-many relationship (one date in the Date table can correspond to many orders in the Sales table) with a single filter direction from `Date` to `Sales`.

3.  **Add Calculated Column for Product First Order Date (for "New Product Launch" tracking):**
    This column will help us identify when a product first appeared in the dataset.
    *   Select the `Sales` table in the "Data view".
    *   Click "New column" from the "Table tools" tab.
    *   Enter the following DAX formula:
        ```dax
        Product_First_Order_Date =
        CALCULATE(
            MIN(Sales[clean_order_date]),
            ALLEXCEPT(Sales, Sales[product_id])
        )
        ```
    *   This column will show the earliest `clean_order_date` for each unique `product_id` across all transactions.

---

### 4. DAX Measures

DAX (Data Analysis Expressions) measures are crucial for calculations and aggregations.

1.  **Sales & Revenue Measures:**
    *   **Total Revenue:**
        ```dax
        Total Revenue = SUM(Sales[clean_final_amount_inr])
        ```
        *Explanation: Calculates the sum of the final amount for all transactions.*
    *   **Total Quantity Sold:**
        ```dax
        Total Quantity Sold = SUM(Sales[quantity])
        ```
        *Explanation: Calculates the total number of units sold.*
    *   **Average Order Value:**
        ```dax
        Average Order Value = DIVIDE([Total Revenue], DISTINCTCOUNT(Sales[transaction_id]))
        ```
        *Explanation: Calculates the average revenue per unique transaction.*
    *   **Revenue per Unit:**
        ```dax
        Revenue per Unit = DIVIDE([Total Revenue], [Total Quantity Sold])
        ```
        *Explanation: Calculates the average revenue generated per unit sold.*

2.  **Product Performance & Acceptance Measures:**
    *   **Unique Products Sold:**
        ```dax
        Unique Products Sold = DISTINCTCOUNT(Sales[product_id])
        ```
        *Explanation: Counts the number of distinct products that have been sold.*
    *   **Average Product Rating:**
        ```dax
        Average Product Rating = AVERAGE(Sales[cleaned_product_rating])
        ```
        *Explanation: Calculates the average rating given to products. Nulls are ignored.*
    *   **Total Delivery Charges:**
        ```dax
        Total Delivery Charges = SUM(Sales[clean_delivery_charges])
        ```
        *Explanation: Sums up all delivery charges incurred.*

3.  **Customer Insights Measures:**
    *   **Unique Customers:**
        ```dax
        Unique Customers = DISTINCTCOUNT(Sales[customer_id])
        ```
        *Explanation: Counts the number of distinct customers who made purchases.*
    *   **Average Customer Rating:**
        ```dax
        Average Customer Rating = AVERAGE(Sales[cleaned_customer_rating])
        ```
        *Explanation: Calculates the average rating given by customers. Nulls are ignored.*

4.  **Launch & Return Metrics:**
    *   **Total Transactions:**
        ```dax
        Total Transactions = COUNTROWS(Sales)
        ```
        *Explanation: Counts the total number of transaction rows.*
    *   **Return Count:**
        ```dax
        Return Count = CALCULATE([Total Transactions], Sales[return_status] = "Returned")
        ```
        *Explanation: Counts transactions where the return status is "Returned".*
    *   **Return Rate %:**
        ```dax
        Return Rate % = DIVIDE([Return Count], [Total Transactions])
        ```
        *Explanation: Calculates the percentage of transactions that were returned.*
    *   **Average Discount %:**
        ```dax
        Average Discount % = AVERAGEX(Sales, Sales[clean_discount_percent])
        ```
        *Explanation: Calculates the average discount percentage applied across all transactions.*
    *   **New Products Launched (within selected date range):**
        ```dax
        New Products Launched =
        VAR MinDateInContext = MIN('Date'[Date])
        VAR MaxDateInContext = MAX('Date'[Date])
        RETURN
            CALCULATE(
                DISTINCTCOUNT(Sales[product_id]),
                FILTER(
                    ALL(Sales), -- Remove existing filters from Sales table for product context
                    Sales[Product_First_Order_Date] >= MinDateInContext &&
                    Sales[Product_First_Order_Date] <= MaxDateInContext
                )
            )
        ```
        *Explanation: Counts unique products whose very first order date (Product_First_Order_Date) falls within the currently selected date range.*

5.  **Time Intelligence Measures (Optional, for year-over-year comparison):**
    *   **Total Revenue LY (Last Year):**
        ```dax
        Total Revenue LY = CALCULATE([Total Revenue], SAMEPERIODLASTYEAR('Date'[Date]))
        ```
        *Explanation: Calculates the total revenue for the same period last year.*
    *   **Revenue YOY Growth %:**
        ```dax
        Revenue YOY Growth % = DIVIDE([Total Revenue] - [Total Revenue LY], [Total Revenue LY])
        ```
        *Explanation: Calculates the year-over-year growth percentage for total revenue.*

---

### 5. Visualization

Let's design a multi-page dashboard to provide a comprehensive view.

#### Page 1: New Product Launch Overview

*   **Page Title:** New Product Launch Dashboard - Overview
*   **Key Metrics (Card Visuals):**
    *   `Total Revenue`
    *   `Total Quantity Sold`
    *   `New Products Launched`
    *   `Average Product Rating` (Format as 1 decimal place)
    *   `Return Rate %` (Format as Percentage, 1 decimal place)
*   **Launch Trend (Line Chart):**
    *   **Axis:** `Date[Year Month]` (from your Date table)
    *   **Values:** `Total Revenue`, `Total Quantity Sold` (drag `Total Quantity Sold` to Secondary Values for dual axis)
    *   *Insight: Track sales and quantity trends over time after launch.*
*   **Revenue by Category (Clustered Column Chart):**
    *   **Axis:** `Sales[cleaned_category]`
    *   **Values:** `Total Revenue`
    *   *Insight: See which categories are driving the most revenue.*
*   **Revenue by Top Brands (Clustered Column Chart):**
    *   **Axis:** `Sales[brand]`
    *   **Values:** `Total Revenue`
    *   *Filter: Use a Top N filter on `brand` to show, e.g., Top 10 by `Total Revenue`.*
    *   *Insight: Identify leading brands in terms of revenue contribution.*
*   **Recent Product Performance (Table):**
    *   **Columns:** `Sales[product_name]`, `Total Revenue`, `Total Quantity Sold`, `Average Product Rating`, `Return Rate %`
    *   *Filter: Add a visual level filter on `Sales[Product_First_Order_Date]` for, e.g., "is in the last 6 months" to show recent launches.*
    *   *Insight: Quick overview of individual product performance metrics.*

#### Page 2: Market Acceptance & Customer Insights

*   **Page Title:** Market Acceptance & Customer Insights
*   **Key Ratings (Card & Gauge Visuals):**
    *   **Card:** `Average Product Rating`
    *   **Gauge:** `Return Rate %` (Set Target value, e.g., 0.05 for 5%, Max value 1 for 100%)
*   **Product Rating by Category (Clustered Column Chart):**
    *   **Axis:** `Sales[cleaned_category]`
    *   **Legend:** `Sales[subcategory]`
    *   **Values:** `Average Product Rating`
    *   *Insight: Compare how different categories and subcategories are rated.*
*   **Revenue by Customer State (Map Visual - e.g., Filled Map):**
    *   **Location:** `Sales[customer_state]`
    *   **Values:** `Total Revenue`
    *   *Insight: Visualize geographical market acceptance and revenue distribution.*
*   **Revenue by Customer Tier (Donut Chart or Bar Chart):**
    *   **Legend/Axis:** `Sales[customer_tier]`
    *   **Values:** `Total Revenue`
    *   *Insight: Understand which customer segments are contributing most.*
*   **Revenue by Customer Age Group (Bar Chart):**
    *   **Axis:** `Sales[customer_age_group]`
    *   **Values:** `Total Revenue`
    *   *Insight: Identify key age demographics for product purchases.*
*   **Average Delivery Days by Category (Clustered Column Chart):**
    *   **Axis:** `Sales[cleaned_category]`
    *   **Values:** Average of `Sales[cleaned_delivery_days]`
    *   *Insight: See if delivery efficiency varies by product category, impacting customer experience.*

#### Page 3: Competitive & Delivery Analysis

*   **Page Title:** Competitive & Delivery Analysis
*   **Brand Performance vs. Discount (Clustered Column Chart with Line):**
    *   **Shared Axis:** `Sales[brand]`
    *   **Column Values:** `Total Revenue`
    *   **Line Values:** `Average Discount %`
    *   *Insight: Analyze brand revenue alongside their average discount strategy.*
*   **Revenue by Delivery Type (Donut Chart):**
    *   **Legend:** `Sales[delivery_type]`
    *   **Values:** `Total Revenue`
    *   *Insight: Understand preferred delivery methods and their revenue contribution.*
*   **Delivery Charges Trend (Line Chart):**
    *   **Axis:** `Date[Year Month]`
    *   **Values:** `Total Delivery Charges`
    *   *Insight: Monitor delivery costs over time.*
*   **Brand Comparison Detail (Table):**
    *   **Columns:** `Sales[brand]`, `Total Revenue`, `Total Quantity Sold`, `Average Product Rating`, `Average Discount %`, `Unique Customers`
    *   *Insight: A detailed comparison of brands across various metrics.*

**General Layout & Design Tips:**

*   **Consistent Theme:** Use Power BI's built-in themes or customize one for a professional look.
*   **Clear Titles:** Ensure every visual has a descriptive title.
*   **Whitespace:** Don't overcrowd the page. Leave some breathing room between visuals.
*   **Alignment:** Use Power BI's alignment tools to make sure visuals are neatly arranged.
*   **Color Use:** Use colors purposefully to highlight key data points, avoiding too many different colors.
*   **Tooltips:** Customize tooltips for visuals to provide extra detail on hover (e.g., adding `Unique Customers` to a revenue bar chart's tooltip).

---

### 6. Interactivity

Interactivity makes your dashboard dynamic and user-friendly.

1.  **Slicers:**
    Add these slicers to each page (or create a dedicated "Filters" page and use sync slicers) to allow users to filter the data interactively:
    *   **Date Slicer:**
        *   Use `Date[Year]` and `Date[Month]` for easy filtering. You can also use `Date[Date]` as a "Relative date" slicer (e.g., "Last 6 months") for new product launch focus.
    *   **Category & Brand Slicers:**
        *   `Sales[cleaned_category]` (Dropdown or List)
        *   `Sales[brand]` (Dropdown or List)
    *   **Customer & Delivery Slicers:**
        *   `Sales[customer_tier]` (List)
        *   `Sales[customer_state]` (List or Searchable Dropdown if many states)
        *   `Sales[delivery_type]` (List)
    *   **Boolean Filters (if useful):**
        *   `Sales[cleaned_is_prime_member]` (True/False - Use a List slicer)
        *   `Sales[cleaned_is_festival_sale]` (True/False - Use a List slicer)

2.  **Drill-Down / Drill-Through:**

    *   **Drill-Down (Hierarchies):**
        *   For your line charts with `Date[Year Month]`, enable drill-down functionality (the arrow icon in the top right of the visual). This allows users to go from year to quarter to month, etc.
        *   You can also create hierarchies for geographical data (e.g., `customer_state` -> `cleaned_customer_city`) or product categories (`cleaned_category` -> `subcategory`) to enable drill-down in bar charts.

    *   **Drill-Through (Product Detail Page):**
        *   **Create a new page:** Rename it `Product Detail`.
        *   **Add Drill-Through Fields:** In the "Drill through" pane on this new page, drag `Sales[product_id]` and `Sales[product_name]` into the "Add drill-through fields here" well.
        *   **Add Detailed Visuals:** On the `Product Detail` page, add visuals that show granular information about a *single selected product*:
            *   Card: `Sales[product_name]` (title), `Total Revenue`, `Total Quantity Sold`, `Average Product Rating`, `Return Rate %` for the selected product.
            *   Line Chart: `Total Revenue` over `Date[Year Month]` for the specific product.
            *   Table: Top customers for this `product_id` (e.g., `customer_id`, `Total Quantity Sold`, `Total Revenue`).
        *   **How to Use:** From any table or visual on another page that lists `product_name` (e.g., "Recent Product Performance" table), right-click on a specific product name. You will see an option to "Drill through" to your "Product Detail" page. This will filter the `Product Detail` page to show data only for that selected product.

---

By following these steps, you will construct a dynamic and informative Power BI dashboard that provides critical insights into the performance of your new product launches, empowering your team with valuable data for strategic decision-making. Good luck!