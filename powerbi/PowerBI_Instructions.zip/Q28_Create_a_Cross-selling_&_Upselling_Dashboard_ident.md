As a world-class Power BI and data analytics consultant, I'm thrilled to guide you through building a powerful Cross-selling & Upselling Dashboard. This dashboard will help you uncover hidden product associations, evaluate recommendation strategies, pinpoint bundling opportunities, and ultimately optimize your revenue.

Let's dive in!

---

## 1. Objective

The primary objective of this Power BI dashboard is to provide actionable insights into cross-selling and upselling opportunities. By analyzing customer purchasing behavior, product associations, and customer segment performance, we aim to identify potential product bundles, assess the effectiveness of current sales strategies, and inform future revenue optimization efforts.

---

## 2. Data Loading & Preparation

This is the crucial first step to ensure your data is clean and in the correct format for analysis.

1.  **Load the CSV Data:**
    *   Open Power BI Desktop.
    *   On the Home tab, click **Get data**.
    *   Select **Text/CSV** and click **Connect**.
    *   Browse to your CSV file, select it, and click **Open**.
    *   In the preview window, Power BI should automatically detect the delimiter (comma) and data types. Click **Transform Data** to open the Power Query Editor.

2.  **Data Cleaning & Transformation in Power Query Editor:**
    *   **Rename Query:** In the "Query Settings" pane on the right, under "Name," change "your_file_name" to something meaningful like `Sales`.
    *   **Remove Redundant Column:** The `corrected_price` column appears to be a duplicate of `clean_original_price_inr` based on your sample. To keep your model clean, select the `corrected_price` column, right-click, and choose **Remove**.
    *   **Data Type Correction:** Power BI often does a good job, but double-check and correct as follows. Click on the icon next to each column header and select the appropriate data type:
        *   `transaction_id`, `customer_id`, `product_id`, `product_name`, `subcategory`, `brand`, `customer_state`, `customer_tier`, `customer_spending_tier`, `customer_age_group`, `delivery_type`, `festival_name`, `return_status`, `cleaned_customer_city`, `duplicate_type`, `standard_payment_method`, `cleaned_category`: **Text**
        *   `quantity`, `order_month`, `order_year`, `order_quarter`: **Whole Number**
        *   `product_weight_kg`, `clean_original_price_inr`, `clean_discount_percent`, `clean_final_amount_inr`, `clean_delivery_charges`, `cleaned_customer_rating`, `cleaned_product_rating`, `cleaned_delivery_days`: **Decimal Number**
        *   `clean_order_date`: **Date** (ensure it's just `Date`, not `Date/Time`).
        *   `cleaned_is_prime_member`, `cleaned_is_prime_eligible`, `cleaned_is_festival_sale`: **True/False**

    *   **Handle Nulls (Optional but Recommended for Ratings):** For `cleaned_customer_rating`, `cleaned_product_rating`, and `cleaned_delivery_days`, if there are nulls, Power BI's aggregation functions (like AVERAGE) will ignore them, which is usually desired for ratings. If you prefer to explicitly handle them (e.g., replace with 0 for `cleaned_delivery_days` if a missing value means instant delivery, or with an average for ratings if you need all rows to contribute), you can:
        *   Select the column (e.g., `cleaned_delivery_days`).
        *   Right-click the column header, select **Replace Values**.
        *   In the "Value To Find" field, type `null`. Leave "Replace With" blank for now (or type `0` for delivery days if appropriate, or for ratings, it's generally best to leave nulls). For this dashboard, we will let DAX handle nulls in averages.

    *   **Close & Apply:** Once all transformations are done, click **Close & Apply** on the Home tab of the Power Query Editor. This will load the clean data into your Power BI data model.

---

## 3. Data Modeling

For this specific dataset, a single "Sales" fact table is sufficient. However, a dedicated Date table is essential for robust time-intelligence calculations.

1.  **Create a Date Table (DAX):**
    *   On the Home tab of Power BI Desktop, click **New Table**.
    *   Enter the following DAX code to create a comprehensive Date table. Adjust the start and end years to match your data's range. For your sample, 2015 is the only year, but this table will generate years beyond, which is fine.

    ```dax
    Date =
    VAR MinDate = MIN(Sales[clean_order_date])
    VAR MaxDate = MAX(Sales[clean_order_date])
    RETURN
        ADDCOLUMNS (
            CALENDAR ( MinDate, MaxDate ),
            "DateInt", FORMAT ( [Date], "YYYYMMDD" ),
            "Year", YEAR ( [Date] ),
            "MonthNum", FORMAT ( [Date], "MM" ),
            "Month", FORMAT ( [Date], "MMM" ),
            "Day", DAY ( [Date] ),
            "DayOfWeekNum", WEEKDAY ( [Date] ),
            "DayOfWeek", FORMAT ( [Date], "DDD" ),
            "Quarter", "Q" & FORMAT ( [Date], "Q" ),
            "YearQuarter", FORMAT ( [Date], "YYYY" ) & " Q" & FORMAT ( [Date], "Q" ),
            "YearMonth", FORMAT ( [Date], "YYYY-MM" )
        )
    ```
    *   After creating the table, select the `Month` column in the Data pane, go to the "Column tools" tab, and click **Sort by column**. Select `MonthNum`. Do the same for `DayOfWeek` sorted by `DayOfWeekNum`. This ensures chronological sorting in visuals.
    *   Mark this table as a Date table: With the `Date` table selected, go to the "Table tools" tab, click **Mark as date table**, select the `Date` column, and click **OK**.

2.  **Create Relationship:**
    *   Go to the Model view (the third icon on the left navigation pane).
    *   Drag the `Date` column from your `Date` table and drop it onto the `clean_order_date` column in your `Sales` table.
    *   Power BI should automatically create a "Many-to-One" relationship (Sales to Date) with "Single" cross-filter direction.

---

## 4. DAX Measures

These measures will perform the calculations necessary for your dashboard. In Power BI Desktop, go to the "Report" view, select the `Sales` table in the "Fields" pane, right-click, and choose **New Measure**. Copy and paste each formula.

1.  **Core Sales & Revenue Measures:**

    *   **Total Revenue**
        ```dax
        Total Revenue = SUM(Sales[clean_final_amount_inr])
        ```
        *Explanation: Calculates the sum of the final amount after discounts for all transactions.*

    *   **Total Original Price (Before Discount)**
        ```dax
        Total Original Price = SUMX(Sales, Sales[clean_original_price_inr] * Sales[quantity])
        ```
        *Explanation: Calculates the total price before any discounts, by multiplying the original unit price by the quantity for each line item and summing them up.*

    *   **Total Discount Amount**
        ```dax
        Total Discount Amount = [Total Original Price] - [Total Revenue]
        ```
        *Explanation: Calculates the total monetary value of discounts given across all transactions.*

    *   **Average Discount %**
        ```dax
        Average Discount % = DIVIDE([Total Discount Amount], [Total Original Price], 0)
        ```
        *Explanation: Shows the average discount percentage applied across all sales. The `DIVIDE` function handles potential division by zero.*

    *   **Total Quantity Sold**
        ```dax
        Total Quantity Sold = SUM(Sales[quantity])
        ```
        *Explanation: Calculates the total number of products sold.*

2.  **Customer & Transaction Measures:**

    *   **Unique Customers**
        ```dax
        Unique Customers = DISTINCTCOUNT(Sales[customer_id])
        ```
        *Explanation: Counts the number of unique customers who made purchases.*

    *   **Unique Transactions**
        ```dax
        Unique Transactions = DISTINCTCOUNT(Sales[transaction_id])
        ```
        *Explanation: Counts the number of unique order transactions.*

    *   **Average Revenue per Transaction**
        ```dax
        Average Revenue per Transaction = DIVIDE([Total Revenue], [Unique Transactions], 0)
        ```
        *Explanation: Calculates the average monetary value of each transaction.*

    *   **Average Items per Transaction**
        ```dax
        Average Items per Transaction = DIVIDE([Total Quantity Sold], [Unique Transactions], 0)
        ```
        *Explanation: Indicates how many items are typically included in a single transaction, a key cross-selling metric.*

    *   **Average Revenue per Customer**
        ```dax
        Average Revenue per Customer = DIVIDE([Total Revenue], [Unique Customers], 0)
        ```
        *Explanation: Measures the average revenue generated from each unique customer.*

3.  **Ratings & Returns Measures:**

    *   **Average Customer Rating**
        ```dax
        Average Customer Rating = AVERAGE(Sales[cleaned_customer_rating])
        ```
        *Explanation: Calculates the average rating provided by customers. Power BI's `AVERAGE` function automatically ignores blank/null values.*

    *   **Average Product Rating**
        ```dax
        Average Product Rating = AVERAGE(Sales[cleaned_product_rating])
        ```
        *Explanation: Calculates the average rating received by products.*

    *   **Total Returned Transactions**
        ```dax
        Total Returned Transactions = CALCULATE(DISTINCTCOUNT(Sales[transaction_id]), Sales[return_status] = "Returned")
        ```
        *Explanation: Counts the number of unique transactions that have a "Returned" status. (Assumes "Returned" is a value in `return_status` column. Adjust if your data uses a different value like "Cancelled" or specific return reason).*

    *   **Return Rate %**
        ```dax
        Return Rate % = DIVIDE([Total Returned Transactions], [Unique Transactions], 0)
        ```
        *Explanation: Shows the percentage of transactions that resulted in a return.*

4.  **Cross-selling & Upselling Specific Measures:**

    *   **Other Products Revenue (Co-Purchases)**
        ```dax
        Other Products Revenue (Co-Purchases) =
        VAR SelectedProductsCustomers =
            CALCULATETABLE (
                DISTINCT ( Sales[customer_id] ),
                ALLSELECTED ( Sales[product_name] ) // Identifies customers who bought the currently selected product(s)
            )
        VAR SelectedProductNames =
            VALUES ( Sales[product_name] ) // Gets the names of the currently selected products
        RETURN
            CALCULATE (
                [Total Revenue],
                KEEPFILTERS ( TREATAS ( SelectedProductsCustomers, Sales[customer_id] ) ), // Filters entire sales data by these customers
                NOT ( Sales[product_name] IN SelectedProductNames ) // Excludes the selected products themselves from the result
            )
        ```
        *Explanation: This powerful measure calculates the total revenue from *other* products purchased by customers who also bought the product(s) currently selected in a visual or slicer. It's key for identifying cross-selling opportunities.*

    *   **Other Products Quantity (Co-Purchases)**
        ```dax
        Other Products Quantity (Co-Purchases) =
        VAR SelectedProductsCustomers =
            CALCULATETABLE (
                DISTINCT ( Sales[customer_id] ),
                ALLSELECTED ( Sales[product_name] )
            )
        VAR SelectedProductNames =
            VALUES ( Sales[product_name] )
        RETURN
            CALCULATE (
                [Total Quantity Sold],
                KEEPFILTERS ( TREATAS ( SelectedProductsCustomers, Sales[customer_id] ) ),
                NOT ( Sales[product_name] IN SelectedProductNames )
            )
        ```
        *Explanation: Similar to the above, but calculates the total quantity of *other* products purchased by customers who bought the selected product(s).*

---

## 5. Visualization

Design an intuitive layout that guides the user through the insights. Consider using a clean, consistent color palette.

### Dashboard Layout & Design Tips:
*   **Header:** Title "Cross-selling & Upselling Dashboard".
*   **KPI Bar:** A prominent row of Card visuals at the top for key summary metrics.
*   **Filter Pane:** A dedicated section (left or top) for slicers.
*   **Main Content:** Arrange charts logically, grouping related insights.
*   **Interactivity:** Ensure visuals filter each other effectively.
*   **Tooltips:** Customize tooltips for detailed information on hover.

### Recommended Visuals:

#### **I. Key Performance Indicators (KPIs) - Use Card Visuals**

1.  **Total Revenue:**
    *   **Field:** `Total Revenue` measure.
    *   *Insight:* Overall financial performance.

2.  **Total Quantity Sold:**
    *   **Field:** `Total Quantity Sold` measure.
    *   *Insight:* Volume of products moved.

3.  **Unique Customers:**
    *   **Field:** `Unique Customers` measure.
    *   *Insight:* Customer base size.

4.  **Average Revenue per Item:**
    *   **Field:** `Average Revenue per Transaction` measure.
    *   *Insight:* Indicates upselling effectiveness.

5.  **Average Items per Transaction:**
    *   **Field:** `Average Items per Transaction` measure.
    *   *Insight:* Direct measure of cross-selling performance.

6.  **Average Discount %:**
    *   **Field:** `Average Discount %` measure (format as Percentage).
    *   *Insight:* Efficiency of promotional pricing.

#### **II. Upselling Insights**

1.  **Revenue by Customer Tier/Spending Tier/Age Group - Clustered Column Chart**
    *   **Axis:** `customer_tier` (or `customer_spending_tier`, `customer_age_group`).
    *   **Values:** `Total Revenue`.
    *   *Insight:* Identifies which customer segments are most valuable. Target lower-value segments with upselling campaigns.
    *   *Tip:* Create multiple charts or use drill-down for different customer segments.

2.  **Product Performance by Category & Subcategory - Clustered Bar Chart**
    *   **Axis:** `cleaned_category` (and then `subcategory` for drill-down).
    *   **Values:** `Total Revenue`, `Total Quantity Sold` (add both to values and allow users to switch).
    *   *Insight:* Highlights top-performing product categories/subcategories. These are good candidates for upselling higher-end versions within the same category.

3.  **Average Revenue per Item by Product Name - Bar Chart**
    *   **Axis:** `product_name`.
    *   **Values:** `Average Revenue per Item` (you'll need to create `Average Revenue per Item = DIVIDE([Total Revenue], [Total Quantity Sold], 0)`).
    *   *Insight:* Identifies products that have higher average revenue per item, suggesting they are either premium or frequently upsold.

#### **III. Cross-selling & Bundle Opportunities**

1.  **Product Selector - Table Visual**
    *   **Columns:** `product_name`, `cleaned_category`, `subcategory`.
    *   *Insight:* This table acts as a filter for the "Co-purchased Products" visual. Users select one or more products here.

2.  **Top Co-purchased Products (Revenue) - Bar Chart**
    *   **Axis:** `product_name`.
    *   **Values:** `Other Products Revenue (Co-Purchases)` measure.
    *   *Filters Pane:* Add `product_name` to Visual Level Filters for this chart and set "Show items when value is not blank". This ensures only products that actually co-occur are shown.
    *   *Interaction:* Ensure this chart *does not* filter the "Product Selector" table.
    *   *Insight:* When a user selects a product in the "Product Selector," this chart dynamically shows which other products are most frequently bought by the same customers, sorted by revenue. This directly identifies cross-selling and bundling opportunities.

3.  **Top Co-purchased Categories (Revenue) - Bar Chart**
    *   **Axis:** `cleaned_category`.
    *   **Values:** `Other Products Revenue (Co-Purchases)` measure.
    *   *Filters Pane:* Add `cleaned_category` to Visual Level Filters for this chart and set "Show items when value is not blank".
    *   *Interaction:* Ensure this chart *does not* filter the "Product Selector" table.
    *   *Insight:* Similar to the product-level chart, but at a category level, providing broader cross-selling strategies.

#### **IV. Recommendation Effectiveness & Strategies**

1.  **Customer Ratings Impact - Card Visuals or Gauges**
    *   **Fields:** `Average Customer Rating`, `Average Product Rating`.
    *   *Insight:* Gauges can visually show the average rating out of 5, indicating overall satisfaction and product quality perceptions.

2.  **Return Rate Analysis - Card Visual & Stacked Column Chart**
    *   **Card:** `Return Rate %` measure (format as Percentage).
    *   **Stacked Column Chart:**
        *   **Axis:** `cleaned_category` or `product_name`.
        *   **Values:** `Total Returned Transactions` and `Unique Transactions` (or `Total Revenue` for returned vs. delivered).
    *   *Insight:* High return rates for certain products/categories might indicate issues with recommendations, product description, or quality, affecting future upselling/cross-selling.

3.  **Festival Sale Impact - Clustered Column Chart**
    *   **Axis:** `festival_name` and `cleaned_is_festival_sale` (to compare festival vs. non-festival).
    *   **Values:** `Total Revenue`.
    *   *Insight:* Evaluates the effectiveness of festival-driven sales in driving revenue, which can inform future promotional bundles.

4.  **Prime Member Performance - Clustered Column Chart**
    *   **Axis:** `cleaned_is_prime_member` (True/False).
    *   **Values:** `Total Revenue`, `Unique Customers`.
    *   *Insight:* Helps understand the value of prime members and if they are more susceptible to upselling/cross-selling efforts.

---

## 6. Interactivity

Interactivity is key to a dynamic and insightful dashboard.

1.  **Slicers:**
    *   Add slicers for:
        *   **Year:** From the `Date` table, use `Year`.
        *   **Quarter:** From the `Date` table, use `Quarter`.
        *   **Month:** From the `Date` table, use `Month`.
        *   **Category:** `cleaned_category` from the `Sales` table.
        *   **Subcategory:** `subcategory` from the `Sales` table.
        *   **Brand:** `brand` from the `Sales` table.
        *   **Customer Tier:** `customer_tier` from the `Sales` table.
        *   **Customer Age Group:** `customer_age_group` from the `Sales` table.
        *   **Prime Member:** `cleaned_is_prime_member` from the `Sales` table (use a single-select or dropdown slicer for True/False).
        *   **Delivery Type:** `delivery_type` from the `Sales` table.
        *   **Festival Name:** `festival_name` from the `Sales` table.
    *   **Placement:** Group all slicers logically, typically in a sidebar or at the top. Use "Dropdown" slicer type for many options to save space.

2.  **Edit Interactions:**
    *   By default, selecting an item in one visual filters all other visuals on the page. You might want to adjust this for specific visuals.
    *   **How to Edit:** Select a visual (e.g., your "Product Selector" table). Go to the "Format" tab in the ribbon and click **Edit interactions**. Now, when you hover over other visuals, you'll see filter and highlight icons.
    *   **Key Interaction Adjustments:**
        *   Ensure that the "Product Selector" table *filters* the "Top Co-purchased Products" charts but *does not* get filtered by them.
        *   Make sure your KPI cards are filtered by all slicers and charts, as they represent the overall summary of the filtered data.

3.  **Drill-Down Functionality:**
    *   For charts like "Product Performance by Category & Subcategory", put `cleaned_category` on the Axis and `subcategory` below it. Enable the drill-down icon (the downward arrow) in the visual header so users can navigate between category and subcategory levels.

---

By following these steps, you will construct a comprehensive and interactive Power BI dashboard capable of answering critical questions about your cross-selling and upselling strategies, leading to more informed business decisions and improved revenue performance. Good luck!