This guide will walk you through creating a Power BI dashboard to analyze geographic revenue, customer tier performance, and market penetration using your provided CSV data. We'll cover everything from data loading and preparation to creating measures, visualizations, and interactive elements.

---

### 1. Objective

The primary goal of this dashboard is to provide a comprehensive **Geographic Revenue Analysis**. This includes:
*   Visualizing revenue performance across different states and cities.
*   Understanding growth patterns associated with various customer tiers.
*   Identifying potential market penetration opportunities through interactive maps and breakdowns.

---

### 2. Data Loading & Preparation

First, you need to load your CSV data into Power BI and perform some essential cleaning and transformations in Power Query.

1.  **Load the CSV Data:**
    *   Open Power BI Desktop.
    *   On the Home tab, click **"Get data"**.
    *   Select **"Text/CSV"** from the list and click **"Connect"**.
    *   Browse to your CSV file, select it, and click **"Open"**.
    *   In the preview window, ensure **"Delimiter"** is set to "Comma" and **"Data Type Detection"** is "Based on first 200 rows".
    *   Click **"Transform Data"**. This will open the Power Query Editor.

2.  **Power Query Editor - Data Cleaning & Transformation:**
    *   In the Power Query Editor, you'll see your data. The goal here is to ensure all columns have the correct data types and handle any inconsistencies.
    *   **Rename Table:** In the "Query Settings" pane on the right, under "Name," rename "Query1" (or your CSV file name) to something descriptive, like `Sales Data`.

    *   **Change Data Types:**
        *   `transaction_id`, `customer_id`, `product_id`, `product_name`, `subcategory`, `brand`, `customer_state`, `customer_tier`, `customer_spending_tier`, `customer_age_group`, `delivery_type`, `festival_name`, `return_status`, `cleaned_customer_city`, `cleaned_category`, `duplicate_type`, `standard_payment_method`: Ensure these are **Text** data type.
        *   `quantity`: Change to **Whole Number**.
        *   `product_weight_kg`, `clean_original_price_inr`, `clean_discount_percent`, `clean_final_amount_inr`, `clean_delivery_charges`, `corrected_price`: Change to **Decimal Number**.
        *   `cleaned_customer_rating`, `cleaned_product_rating`: Change to **Decimal Number**. If you encounter errors (due to blanks/text), right-click the column header, select "Replace Errors," and enter `null` (or `0` if you want to treat blank ratings as zero).
        *   `clean_order_date`: Change to **Date** data type.
        *   `order_month`, `order_year`, `order_quarter`: Change to **Whole Number**.
        *   `cleaned_delivery_days`: Change to **Decimal Number** or **Whole Number** if only whole days.
        *   `cleaned_is_prime_member`, `cleaned_is_prime_eligible`, `cleaned_is_festival_sale`: These are currently "True"/"False" text. Select these columns, go to the "Transform" tab, click "Data Type," and select **"True/False"** (Boolean).

    *   **Handling Nulls/Errors (General Best Practice):**
        *   For numerical columns that might contain errors or blanks (like ratings or prices), it's good practice to handle them. For example, if `cleaned_customer_rating` has errors, right-click the column header, select "Replace Errors," and replace with `null` or `0` depending on how you want to treat unrated items. For `clean_final_amount_inr` or `quantity`, ensure no errors, as these are critical for revenue calculations.

    *   **Geographic Data Categorization:**
        *   After loading and closing Power Query, in the Power BI Data view, select the `customer_state` column. In the "Column tools" tab, set "Data Category" to **"State or Province"**.
        *   Select the `cleaned_customer_city` column. In the "Column tools" tab, set "Data Category" to **"City"**. This helps Power BI recognize these as locations for map visuals.

3.  **Apply Changes:**
    *   Once all transformations are complete, click **"Close & Apply"** on the Home tab of Power Query Editor. Your data will now load into Power BI Desktop.

---

### 3. Data Modeling

A robust data model, particularly with a dedicated date table, is crucial for time-based analysis and flexibility.

1.  **Create a Date Table:**
    *   Go to the "Table tools" tab (or "Modeling" tab in older versions) and click **"New table"**.
    *   Enter the following DAX formula to create a date table that automatically covers all dates present in your `clean_order_date` column:

    ```dax
    Date Table =
    VAR MinDate = CALCULATE(MIN('Sales Data'[clean_order_date]), ALL('Sales Data'))
    VAR MaxDate = CALCULATE(MAX('Sales Data'[clean_order_date]), ALL('Sales Data'))
    RETURN
        ADDCOLUMNS (
            CALENDAR (MinDate, MaxDate),
            "Year", YEAR ( [Date] ),
            "Month Number", MONTH ( [Date] ),
            "Month Name", FORMAT ( [Date], "MMM" ),
            "Quarter", "Q" & CEILING ( MONTH ( [Date] ) / 3, 1 ),
            "Day of Week", FORMAT ( [Date], "DDDD" ),
            "Day of Week Number", WEEKDAY ( [Date], 2 ) -- Monday is 1, Sunday is 7
        )
    ```
    *   After the table is created, ensure `Month Name` is sorted by `Month Number`. Select the `Month Name` column in the "Data" view, then in "Column tools" -> "Sort by column," choose `Month Number`.

2.  **Create Relationships:**
    *   Go to the **"Model view"** (the third icon on the left sidebar).
    *   You should see your `Sales Data` table and your `Date Table`.
    *   Drag the `Date` column from `Date Table` and drop it onto the `clean_order_date` column in `Sales Data`. This creates a one-to-many relationship (`Date Table` (1) to `Sales Data` (*)).

---

### 4. DAX Measures

These measures will be the foundation of your analysis. Go to the "Report view," select your `Sales Data` table in the "Fields" pane, right-click, and select **"New measure"** for each.

1.  **Total Revenue:** Calculates the sum of all final amounts.

    ```dax
    Total Revenue = SUM('Sales Data'[clean_final_amount_inr])
    ```

2.  **Total Quantity Sold:** Calculates the total number of items sold.

    ```dax
    Total Quantity Sold = SUM('Sales Data'[quantity])
    ```

3.  **Number of Orders:** Counts the distinct number of transactions.

    ```dax
    Number of Orders = DISTINCTCOUNT('Sales Data'[transaction_id])
    ```

4.  **Number of Customers:** Counts the distinct number of customers.

    ```dax
    Number of Customers = DISTINCTCOUNT('Sales Data'[customer_id])
    ```

5.  **Average Order Value:** The average revenue per order.

    ```dax
    Average Order Value = DIVIDE([Total Revenue], [Number of Orders], 0)
    ```

6.  **Total Discount Amount:** Calculates the total discount given based on original price and discount percentage.

    ```dax
    Total Discount Amount =
    SUMX(
        'Sales Data',
        ('Sales Data'[clean_original_price_inr] * 'Sales Data'[quantity]) * ('Sales Data'[clean_discount_percent] / 100)
    )
    ```
    *Note: If `clean_final_amount_inr` is already adjusted, you could also calculate Total Discount as `SUMX('Sales Data', 'Sales Data'[clean_original_price_inr] * 'Sales Data'[quantity]) - [Total Revenue]` if `clean_original_price_inr` is per unit and `quantity` is number of units.*

7.  **Revenue Share % (for market penetration visuals):** Calculates the percentage of total revenue for a given context (e.g., state, city).

    ```dax
    Revenue Share % =
    DIVIDE(
        [Total Revenue],
        CALCULATE([Total Revenue], ALLSELECTED('Sales Data')),
        0
    )
    ```
    *This measure calculates the current context's revenue as a percentage of the total revenue selected by all filters on the page. For a specific context like state, you might use `ALL('Sales Data'[customer_state])` instead of `ALLSELECTED('Sales Data')` in the `CALCULATE` part depending on your exact requirement.*

---

### 5. Visualization

Now, let's build the dashboard with various visuals.

#### Page 1: Geographic Revenue & Market Penetration

1.  **Key Performance Indicators (KPIs):**
    *   **Visual Type:** Card (4 separate cards)
    *   **Fields:**
        *   Card 1: `Total Revenue`
        *   Card 2: `Number of Customers`
        *   Card 3: `Number of Orders`
        *   Card 4: `Average Order Value`
    *   **Placement:** Top of the dashboard.
    *   **Formatting:** Set appropriate display units (e.g., "K" or "M") and decimal places.

2.  **State-wise Revenue Performance:**
    *   **Visual Type:** Filled Map (or Shape Map if you have a custom map of India's states)
    *   **Fields:**
        *   **Location:** `customer_state`
        *   **Color saturation:** `Total Revenue`
    *   **Insights:** Visually identify high-revenue states.
    *   **Formatting:** In the "Format" pane -> "Map styles," try "Dark" or "Grayscale" for better contrast. Adjust data colors.

3.  **City-wise Revenue (Top N):**
    *   **Visual Type:** Clustered Column Chart or Bar Chart
    *   **Fields:**
        *   **X-axis:** `cleaned_customer_city`
        *   **Y-axis:** `Total Revenue`
    *   **Filters:** Apply a "Top N" filter to `cleaned_customer_city` (e.g., Top 10 by `Total Revenue`) to avoid clutter.
    *   **Insights:** Pinpoint top-performing cities within states or overall.

4.  **Revenue by Customer Tier:**
    *   **Visual Type:** Donut Chart or Pie Chart
    *   **Fields:**
        *   **Legend:** `customer_tier`
        *   **Values:** `Total Revenue`
    *   **Insights:** See the distribution of revenue across different customer tiers.

5.  **Market Penetration (Customer Count by State):**
    *   **Visual Type:** Filled Map (another one, or a drill-down option on the first map)
    *   **Fields:**
        *   **Location:** `customer_state`
        *   **Color saturation:** `Number of Customers`
    *   **Insights:** Understand where you have a high customer base, which might be different from high revenue areas.

#### Page 2: Tier-wise Growth Patterns (Drill-through target)

1.  **Revenue Trend by Customer Tier:**
    *   **Visual Type:** Line Chart
    *   **Fields:**
        *   **X-axis:** `Month Name` from `Date Table` (ensure it's sorted by `Month Number`)
        *   **Y-axis:** `Total Revenue`
        *   **Legend:** `customer_tier`
    *   **Insights:** Observe how revenue for each customer tier changes over time. Use the drill-down hierarchy (`Year -> Quarter -> Month`) from the `Date Table` for detailed analysis.

2.  **Tier Performance Matrix:**
    *   **Visual Type:** Matrix
    *   **Fields:**
        *   **Rows:** `customer_state`, then `cleaned_customer_city` (add `customer_state` first, then `cleaned_customer_city` below it for hierarchy)
        *   **Columns:** `customer_tier`
        *   **Values:** `Total Revenue`, `Number of Customers`, `Average Order Value`
    *   **Insights:** Detailed breakdown of performance for each tier across geographies.

#### Layout and Design Tips:

*   **Header:** Add a text box at the top of each page with a clear title (e.g., "Geographic Revenue Analysis").
*   **Background:** Use a subtle background color or image.
*   **Consistent Color Palette:** Choose a theme and stick to it for all visuals.
*   **Align and Distribute:** Use Power BI's alignment tools to make your visuals neat.
*   **Meaningful Titles:** Ensure all visual titles are clear and descriptive.
*   **Tooltips:** Ensure relevant fields are added to visual tooltips for extra detail on hover.

---

### 6. Interactivity

Interactivity is key to an effective dashboard, allowing users to explore data dynamically.

1.  **Slicers (on Page 1 and Page 2):**
    *   **Visual Type:** Slicer
    *   **Fields:**
        *   `Year` (from `Date Table`): Use a "List" or "Dropdown" format.
        *   `Month Name` (from `Date Table`): Use a "List" or "Dropdown" format.
        *   `customer_state` (from `Sales Data`): Use a "List" or "Dropdown" format.
        *   `customer_tier` (from `Sales Data`): Use a "List" or "Dropdown" format.
        *   `cleaned_category` (from `Sales Data`): To analyze revenue by product category.
        *   `festival_name` (from `Sales Data`): To see impact of sales events.
    *   **Placement:** Typically on the left or top right side of the dashboard.
    *   **Sync Slicers:** For slicers present on both pages (e.g., Year, Month, State), select the slicer, go to the "View" tab, click "Sync slicers," and check both pages so that filters apply consistently across the report.

2.  **Drill-down Functionality:**
    *   For the "State-wise Revenue Performance" map, you can enable drill-down. If you place `customer_state` and then `cleaned_customer_city` in the "Location" field well, you can click the "Drill down" arrow on the visual header to go from state to city view.
    *   For the "Revenue Trend by Customer Tier" line chart, ensure `Year`, `Quarter`, `Month Name` are added to the X-axis in a hierarchy to allow drilling down through time.

3.  **Drill-through Functionality (from State Map to Tier Growth Page):**
    *   **Goal:** Allow users to right-click on a state in the map and see its specific tier growth patterns on the dedicated "Tier-wise Growth Patterns" page.
    *   **Setup:**
        *   Go to the "Tier-wise Growth Patterns" page.
        *   In the "Visualizations" pane, under "Drill through," drag `customer_state` from the `Sales Data` table into the "Add drill-through fields here" section.
        *   Now, go back to your "Geographic Revenue & Market Penetration" page.
        *   Right-click on any state in the "State-wise Revenue Performance" map. You will see a "Drill through" option, and "Tier-wise Growth Patterns" will appear as a sub-option. Clicking it will navigate to the second page, filtered for that specific state.

---

By following these steps, you will create a powerful and interactive Power BI dashboard that provides deep insights into your geographic revenue performance, helping to identify growth opportunities and understand customer tier dynamics.