Here's a comprehensive, step-by-step guide to create your Category Performance Dashboard in Power BI Desktop.

---

### 1. Objective

The primary objective of this dashboard is to provide a holistic view of category performance. It will enable users to analyze revenue contribution by category, identify growth trends over time, understand changes in market share, and assess category-wise profitability (using revenue per unit as a proxy) with robust drill-down and filtering capabilities.

### 2. Data Loading & Preparation

This section details how to get your CSV data into Power BI and perform essential cleaning and transformations.

1.  **Open Power BI Desktop:**
    *   Launch Power BI Desktop.

2.  **Load the CSV Data:**
    *   In the Home tab, click **"Get Data"**.
    *   Select **"Text/CSV"** from the common data sources, then click **"Connect"**.
    *   Browse to your CSV file, select it, and click **"Open"**.
    *   A preview window will appear. Ensure "Delimiter" is set to "Comma" and "Data Type Detection" is "Based on first 200 rows".
    *   Click **"Transform Data"** to open the Power Query Editor. This is where we'll clean and prepare the data.

3.  **Data Cleaning & Transformation in Power Query Editor:**

    *   **Rename Query:** In the "Query Settings" pane on the right, change the "Name" from `your_csv_file_name` to something more descriptive like `Sales Data`.

    *   **Change Data Types:**
        *   Right-click each column header and select "Change Type" to set the appropriate data type.
        *   `transaction_id`, `customer_id`, `product_id`, `product_name`, `subcategory`, `brand`, `customer_state`, `customer_tier`, `customer_spending_tier`, `customer_age_group`, `delivery_type`, `festival_name`, `return_status`, `cleaned_customer_city`, `cleaned_category`, `duplicate_type`, `standard_payment_method`: **Text**
        *   `quantity`, `order_month`, `order_year`, `order_quarter`: **Whole Number**
        *   `product_weight_kg`, `clean_original_price_inr`, `clean_discount_percent`, `clean_final_amount_inr`, `clean_delivery_charges`, `cleaned_customer_rating`, `cleaned_product_rating`, `cleaned_delivery_days`, `corrected_price`: **Decimal Number**
        *   `clean_order_date`: **Date** (This is crucial for time intelligence. Ensure it's correctly parsed.)
        *   `cleaned_is_prime_member`, `cleaned_is_prime_eligible`, `cleaned_is_festival_sale`: **True/False** (Boolean)

    *   **Handle Null Values (for numerical columns):**
        *   For columns like `clean_final_amount_inr`, `quantity`, `clean_discount_percent`, `clean_delivery_charges`, if there are any nulls, they can cause errors in calculations.
        *   Select these columns, right-click, choose **"Replace Values"**.
        *   In "Value to Find", leave it blank (or type `null` if it's explicitly 'null'). In "Replace With", enter `0`. (Apply this step judiciously, for ratings, you might prefer to leave nulls or treat them separately). For financial calculations, replacing with 0 is generally safe.

    *   **Filter out incomplete/returned transactions (Optional but recommended for accurate revenue):**
        *   Click the filter icon on the `return_status` column header.
        *   Uncheck any statuses that represent non-revenue generating transactions, such as "Returned" or "Cancelled". Ensure only "Delivered" (or similar final statuses) are selected.

    *   **Close & Apply:**
        *   Once all transformations are done, click **"Close & Apply"** in the Home tab of the Power Query Editor. This will load the cleaned data into your Power BI model.

### 3. Data Modeling

A robust data model is essential for accurate and flexible reporting.

1.  **Create a Date Table (Calendar Table):**
    A separate Date table is best practice for time intelligence functions.

    *   Go to the **"Table view"** (icon resembling a grid on the left pane).
    *   In the "Home" tab, click **"New Table"**.
    *   Enter the following DAX formula to create your Date table:

        ```dax
        Date = 
        VAR MinDate = MIN('Sales Data'[clean_order_date])
        VAR MaxDate = MAX('Sales Data'[clean_order_date])
        RETURN
            CALENDAR(MinDate, MaxDate)
        ```
    *   This creates a table named `Date` with a single `Date` column spanning your transaction dates.
    *   Now, add more useful columns to your Date table (click "New Column" for each):

        ```dax
        Year = YEAR('Date'[Date])
        ```

        ```dax
        Month Number = MONTH('Date'[Date])
        ```

        ```dax
        Month Name = FORMAT('Date'[Date], "MMM")
        ```
        *   *Tip: For `Month Name`, sort it by `Month Number` in the "Column tools" tab to ensure correct chronological order in visuals.*

        ```dax
        Quarter = "Q" & QUARTER('Date'[Date])
        ```

        ```dax
        Full Date = FORMAT('Date'[Date], "YYYY-MM-DD")
        ```

    *   **Mark as Date Table:**
        *   Select the `Date` table in the "Fields" pane.
        *   Go to the "Table tools" tab, click **"Mark as Date table"**, and select the `Date` column as the Date column. This helps Power BI optimize time-based calculations.

2.  **Create Relationships:**
    *   Go to the **"Model view"** (icon resembling three linked tables on the left pane).
    *   You will see your `Sales Data` table and your `Date` table.
    *   Drag the `clean_order_date` column from your `Sales Data` table and drop it onto the `Date` column in your `Date` table.
    *   This will create a one-to-many relationship (1 to *) between `Date` (one) and `Sales Data` (many), with cross-filter direction set to "Single".

### 4. DAX Measures

These measures will form the backbone of your dashboard's calculations.

*   Go to the **"Report view"** (icon resembling a bar chart on the left pane).
*   In the "Fields" pane, right-click on your `Sales Data` table and select **"New Measure"** for each of the following:

1.  **Total Revenue:**
    Calculates the sum of the final amount for all transactions.
    ```dax
    Total Revenue = SUM('Sales Data'[clean_final_amount_inr])
    ```

2.  **Total Quantity Sold:**
    Calculates the total number of products sold.
    ```dax
    Total Quantity Sold = SUM('Sales Data'[quantity])
    ```

3.  **Average Revenue per Unit:**
    A proxy for profitability per unit, showing the average revenue generated per item.
    ```dax
    Average Revenue per Unit = DIVIDE([Total Revenue], [Total Quantity Sold], 0)
    ```

4.  **Revenue Last Year:**
    Used for calculating year-over-year growth.
    ```dax
    Revenue Last Year = 
    CALCULATE(
        [Total Revenue], 
        SAMEPERIODLASTYEAR('Date'[Date])
    )
    ```

5.  **YoY Revenue Growth %:**
    Calculates the percentage growth in revenue compared to the previous year.
    ```dax
    YoY Revenue Growth % = 
    DIVIDE(
        ([Total Revenue] - [Revenue Last Year]), 
        [Revenue Last Year], 
        0
    )
    ```
    *   *Format this measure as a Percentage (%) with 2 decimal places in the "Measure tools" tab.*

6.  **Total Revenue All Categories (for Market Share):**
    Calculates the total revenue across all categories, ignoring category filters, but respecting other filters (e.g., date, customer tier).
    ```dax
    Total Revenue All Categories = 
    CALCULATE(
        [Total Revenue], 
        ALLSELECTED('Sales Data'[cleaned_category])
    )
    ```

7.  **Category Revenue Share %:**
    Calculates the revenue contribution of the current category as a percentage of the total revenue of all selected categories.
    ```dax
    Category Revenue Share % = 
    DIVIDE(
        [Total Revenue], 
        [Total Revenue All Categories], 
        0
    )
    ```
    *   *Format this measure as a Percentage (%) with 2 decimal places.*

8.  **Average Discount %:**
    Calculates the average discount percentage applied.
    ```dax
    Average Discount % = AVERAGE('Sales Data'[clean_discount_percent])
    ```
    *   *Format this measure as a Percentage (%) with 2 decimal places.*

### 5. Visualization

Let's build the dashboard using various visuals.

**Dashboard Design Tips:**

*   **Layout:** Use a clean, consistent layout. Consider using shapes and text boxes for titles and sections.
*   **Colors:** Choose a coherent color palette that aligns with your brand or a professional aesthetic.
*   **Titles:** Give each visual a clear, descriptive title.
*   **Interactivity:** Ensure visuals cross-filter each other (Power BI's default behavior).

**Dashboard Structure:**

1.  **Page Title:** Add a text box at the top: "Category Performance Dashboard".
2.  **Key Performance Indicators (KPIs) - Use Card Visuals:**
    *   **Visual Type:** Card
    *   **Metrics:**
        *   **Total Revenue:** Drag `[Total Revenue]` to the "Fields" well.
        *   **YoY Revenue Growth %:** Drag `[YoY Revenue Growth %]` to the "Fields" well.
        *   **Total Quantity Sold:** Drag `[Total Quantity Sold]` to the "Fields" well.
        *   **Average Revenue per Unit:** Drag `[Average Revenue per Unit]` to the "Fields" well.
    *   *Arrange these cards prominently at the top or left side.*

3.  **Revenue Contribution by Category:**
    *   **Visual Type:** Clustered Column Chart
    *   **Axis (X-axis):** `Sales Data[cleaned_category]`
    *   **Values (Y-axis):** `[Total Revenue]`
    *   **Drill-down:** Add `Sales Data[subcategory]` below `cleaned_category` in the "Axis" well to enable drilling down from category to subcategory.
    *   *Duplicate this visual and change it to a Donut Chart for a percentage contribution view. Use `cleaned_category` as "Legend" and `[Total Revenue]` as "Values".*

4.  **Revenue Growth Trends Over Time:**
    *   **Visual Type:** Line Chart
    *   **X-axis:** `Date[Year]` (and then `Date[Month Name]` for drill-down)
    *   **Y-axis:** `[Total Revenue]`
    *   **Legend:** `Sales Data[cleaned_category]` (This will show individual lines for each category's revenue trend).
    *   *Option: Add `[Revenue Last Year]` to the Y-axis as well to compare current year revenue with the previous year directly on the same chart.*

5.  **Category Market Share Changes:**
    *   **Visual Type:** Line Chart
    *   **X-axis:** `Date[Year]` (and then `Date[Month Name]` for drill-down)
    *   **Y-axis:** `[Category Revenue Share %]`
    *   **Legend:** `Sales Data[cleaned_category]`
    *   *Filter this visual to show only the Top N categories (e.g., Top 5) by `[Total Revenue]` to keep it clean.*
    *   *Alternative: A 100% Stacked Column Chart with `Date[Year]` on X-axis, `[Total Revenue]` as Values, and `cleaned_category` as Legend, then enable "Show value as % of grand total" in the formatting pane.*

6.  **Category-wise Profitability Insights:**
    *   **Visual Type:** Clustered Column Chart or Line and Clustered Column Chart
    *   **Scenario 1 (Profitability Proxy):** Clustered Column Chart
        *   **X-axis:** `Sales Data[cleaned_category]`
        *   **Y-axis:** `[Average Revenue per Unit]`
        *   *This helps identify categories with higher average revenue per item.*
    *   **Scenario 2 (Profitability Proxy with Discount Context):** Line and Clustered Column Chart
        *   **Shared Axis:** `Sales Data[cleaned_category]`
        *   **Column values:** `[Average Revenue per Unit]`
        *   **Line values:** `[Average Discount %]`
        *   *This allows you to see if categories with high average revenue per unit also have high discount percentages.*

### 6. Interactivity

Enhance the dashboard's usability with slicers and drill-down features.

1.  **Slicers (Filters):**
    *   **Visual Type:** Slicer
    *   **Date Slicer:**
        *   Add `Date[Year]` to one slicer (choose "Vertical list" or "Dropdown" style).
        *   Add `Date[Full Date]` to another slicer, change its style to "Between" for a date range picker.
    *   **Category Slicer:** Add `Sales Data[cleaned_category]`.
    *   **Customer Tier Slicer:** Add `Sales Data[customer_tier]`.
    *   **Delivery Type Slicer:** Add `Sales Data[delivery_type]`.
    *   **Festival Sale Slicer:** Add `Sales Data[cleaned_is_festival_sale]`.
    *   *Place slicers on the left or top of your dashboard for easy access.*
    *   *Ensure all visuals interact with these slicers (default behavior, but check "Edit interactions" under "Format" if needed).*

2.  **Drill-Down Capabilities:**
    *   **For Category Hierarchy:** On visuals where you've added both `cleaned_category` and `subcategory` to the Axis/Legend well, enable the drill-down functionality.
        *   Look for the drill-down arrows (single down arrow or double down arrow) in the visual's header.
        *   The single down arrow allows you to drill into the next level for a *selected* category.
        *   The double down arrow allows you to drill into the next level for *all* categories shown.
        *   The up arrow will drill back up.
    *   **For Date Hierarchy:** The `Date` table naturally supports drilling down from Year to Quarter to Month to Day in time-based visuals.

3.  **Cross-Filtering:**
    *   By default, clicking on a segment of one visual (e.g., a bar in the Category Revenue chart) will filter all other visuals on the page. This is a powerful way for users to explore relationships in the data.

---

This detailed guide should provide you with all the necessary steps to build a comprehensive and insightful Category Performance Dashboard in Power BI Desktop. Remember to save your work frequently!