Here's a comprehensive, step-by-step guide to building your Supply Chain Dashboard in Power BI, tailored for a new user.

---

# Supply Chain Dashboard in Power BI

## 1. Objective

The primary goal of this dashboard is to provide a comprehensive view of the supply chain's performance. It will allow stakeholders to monitor key aspects such as delivery reliability, analyze costs, evaluate vendor (or product/brand as a proxy) performance, and gain insights into overall operational efficiency.

## 2. Data Loading & Preparation

This section guides you through bringing your CSV data into Power BI and cleaning it for analysis.

### Step-by-Step Instructions:

1.  **Open Power BI Desktop:** Launch the Power BI Desktop application.
2.  **Load Data:**
    *   On the `Home` tab in Power BI Desktop, click `Get Data`.
    *   From the common data sources, select `Text/CSV`, then click `Connect`.
    *   Browse to the location of your CSV file, select it, and click `Open`.
    *   A preview window will appear. Ensure that `Delimiter` is set to `Comma` and `Data Type Detection` is set to `Based on first 200 rows`.
    *   Click `Transform Data`. This will open the Power Query Editor, where we'll clean and prepare the data.

3.  **Power Query Editor - Data Cleaning & Transformation:**

    *   **Rename Query:** In the `Queries` pane on the left, you'll see your loaded table (likely named after your CSV file). Right-click on it and select `Rename`. Change its name to `Transactions` for easier reference.

    *   **Review and Correct Data Types:** It's critical to ensure each column has the correct data type for accurate calculations and visualizations. Power BI makes an educated guess, but you should always verify.
        *   For each column, click on the small icon next to its name in the header (e.g., "ABC" for Text, "123" for Whole Number).
        *   Select the appropriate data type from the dropdown.

        Here are the recommended data types for your columns:
        *   `transaction_id`, `customer_id`, `product_id`, `product_name`, `subcategory`, `brand`, `customer_state`, `customer_tier`, `customer_spending_tier`, `customer_age_group`, `delivery_type`, `festival_name`, `return_status`, `duplicate_type`, `standard_payment_method`, `cleaned_category`, `cleaned_customer_city`: **Text**
        *   `quantity`, `order_month`, `order_year`, `order_quarter`: **Whole Number**
        *   `product_weight_kg`, `clean_discount_percent`: **Decimal Number**
        *   `clean_order_date`: **Date** (This is crucial for time-based analysis. If it's `Date/Time`, change it to `Date` only).
        *   `clean_original_price_inr`, `clean_final_amount_inr`, `clean_delivery_charges`, `corrected_price`: **Decimal Number**
        *   `cleaned_customer_rating`, `cleaned_product_rating`: **Decimal Number**
        *   `cleaned_delivery_days`: **Decimal Number**
        *   `cleaned_is_prime_member`, `cleaned_is_prime_eligible`, `cleaned_is_festival_sale`: **True/False** (Boolean)

    *   **Handle Nulls/Errors:**
        *   **`cleaned_customer_rating`, `cleaned_product_rating`:** These columns often contain blank or null values if a rating wasn't provided. To avoid errors in average calculations and ensure valid averages for existing ratings:
            *   Select both columns (`Ctrl + Click`).
            *   Go to the `Transform` tab, click `Replace Values`.
            *   In the `Value To Find` field, leave it blank (or type `null` if it's explicitly 'null'). In the `Replace With` field, enter `0`.
            *   Click `OK`. (Note: This assumes 0 means "no rating" and will be filtered out for averages later. If 0 is a valid rating, consider replacing nulls with the column's average or median instead, or filter rows with nulls if ratings are mandatory for analysis.)
        *   **`festival_name`:** This column might have blank entries.
            *   Select the `festival_name` column.
            *   Go to `Transform` tab, click `Replace Values`.
            *   In `Value To Find`, leave it blank. In `Replace With`, type `No Festival`. Click `OK`.

    *   **Create New Columns (Power Query):**
        *   **`Order Day of Week`:** This helps in analyzing daily patterns.
            *   Select the `clean_order_date` column.
            *   Go to the `Add Column` tab -> `Date` -> `Day` -> `Name of Day`.
            *   A new column named `Day Name` will be added. Double-click its header and rename it to `Order Day of Week`.

    *   **Close & Apply:** Once all transformations are complete, go to the `Home` tab in Power Query Editor and click `Close & Apply`. This loads your cleaned data into the Power BI data model.

## 3. Data Modeling

A robust data model is essential for accurate and flexible reporting. We'll create a dedicated Date table and establish a relationship with your main data.

### 1. Date Table Creation (DAX)

A date table is a best practice for time intelligence functions (e.g., year-over-year growth).

1.  In Power BI Desktop, go to the `Table view` (the icon resembling a grid on the left sidebar).
2.  On the `Home` tab (or `Modeling` tab), click `New Table`.
3.  Enter the following DAX code into the formula bar to create your `Date` table:

    ```dax
    Date =
    VAR MinDate = MIN(Transactions[clean_order_date])
    VAR MaxDate = MAX(Transactions[clean_order_date])
    VAR CalendarTable =
        ADDCOLUMNS(
            CALENDAR(MinDate, MaxDate),
            "Year", YEAR([Date]),
            "MonthNum", FORMAT([Date], "MM"),
            "Month", FORMAT([Date], "MMM"),
            "Month Year", FORMAT([Date], "MMM YYYY"),
            "Quarter", "Q" & FORMAT([Date], "Q"),
            "Day", DAY([Date]),
            "DayOfWeekNum", WEEKDAY([Date], 2), -- 1=Sunday, 2=Monday
            "DayOfWeek", FORMAT([Date], "DDD"),
            "Weekend", IF(WEEKDAY([Date], 2) IN {6, 7}, "Weekend", "Weekday")
        )
    RETURN
        CalendarTable
    ```

4.  Press `Enter` to create the table.

### 2. Create Relationships

1.  Go to the `Model view` (the icon resembling a flowchart on the left sidebar).
2.  You will see your `Transactions` table and the newly created `Date` table.
3.  Drag the `Date` column from the `Date` table and drop it onto the `clean_order_date` column in the `Transactions` table.
4.  This establishes a `Many-to-One (*:1)` relationship from `Transactions` to `Date` on the `clean_order_date` and `Date` columns respectively. Ensure the `Cross filter direction` is set to `Single`. This allows filters applied to your `Date` table (e.g., selecting a year) to correctly filter your `Transactions` data.

## 4. DAX Measures

Measures are critical for performing calculations on your data. In the `Report view`, select the `Transactions` table in the `Fields` pane, then click `New Measure` from the `Table tools` tab for each measure below.

### Delivery Reliability Measures:

1.  **Total Orders:**
    ```dax
    Total Orders = COUNTROWS(Transactions)
    ```
    *Explanation:* Counts the total number of individual transactions in your dataset.

2.  **Total Delivered Orders:**
    ```dax
    Total Delivered Orders =
    CALCULATE(
        [Total Orders],
        Transactions[return_status] = "Delivered"
    )
    ```
    *Explanation:* Counts only those transactions where the `return_status` is explicitly "Delivered".

3.  **Total Returned Orders:**
    ```dax
    Total Returned Orders =
    CALCULATE(
        [Total Orders],
        Transactions[return_status] = "Returned"
    )
    ```
    *Explanation:* Counts transactions where the `return_status` is "Returned".

4.  **Delivery Rate:**
    ```dax
    Delivery Rate =
    DIVIDE(
        [Total Delivered Orders],
        [Total Orders],
        0
    )
    ```
    *Explanation:* Calculates the percentage of total orders that were successfully delivered. (The `0` is for handling division by zero).

5.  **Return Rate:**
    ```dax
    Return Rate =
    DIVIDE(
        [Total Returned Orders],
        [Total Orders],
        0
    )
    ```
    *Explanation:* Calculates the percentage of total orders that were returned.

6.  **Average Delivery Days (Delivered Orders Only):**
    ```dax
    Average Delivery Days =
    AVERAGEX(
        FILTER(Transactions, Transactions[return_status] = "Delivered"),
        Transactions[cleaned_delivery_days]
    )
    ```
    *Explanation:* Computes the average number of delivery days, considering only orders that were "Delivered".

7.  **On-Time Delivery Rate (Example - assuming SLA of 7 days):**
    ```dax
    On-Time Delivery Rate =
    VAR SLADays = 7 // Define your Service Level Agreement (SLA) for delivery days
    VAR OnTimeDeliveries =
        CALCULATE(
            COUNTROWS(Transactions),
            Transactions[return_status] = "Delivered",
            Transactions[cleaned_delivery_days] <= SLADays
        )
    RETURN
        DIVIDE(
            OnTimeDeliveries,
            [Total Delivered Orders],
            0
        )
    ```
    *Explanation:* This measure calculates the percentage of delivered orders that met a specific Service Level Agreement (SLA) for delivery time (e.g., delivered within 7 days). You can adjust `SLADays` to match your business's actual SLA.

### Cost Analysis Measures:

8.  **Total Final Revenue (INR):**
    ```dax
    Total Final Revenue (INR) = SUM(Transactions[clean_final_amount_inr])
    ```
    *Explanation:* Sums up the `clean_final_amount_inr` for all transactions, representing the total revenue after discounts.

9.  **Total Product Cost (INR - using corrected_price as proxy for cost):**
    ```dax
    Total Product Cost (INR) = SUMX(Transactions, Transactions[corrected_price] * Transactions[quantity])
    ```
    *Explanation:* Calculates the total estimated cost of products sold. It assumes `corrected_price` represents a base cost per unit. **Important:** If you have a true supplier cost column, use that instead of `corrected_price` for more accurate cost analysis.

10. **Total Delivery Charges:**
    ```dax
    Total Delivery Charges = SUM(Transactions[clean_delivery_charges])
    ```
    *Explanation:* Sums all the delivery charges across transactions.

11. **Gross Profit (INR):**
    ```dax
    Gross Profit (INR) = [Total Final Revenue (INR)] - [Total Product Cost (INR)]
    ```
    *Explanation:* Calculates the gross profit by subtracting the estimated total product cost from the total final revenue.

12. **Gross Profit Margin:**
    ```dax
    Gross Profit Margin =
    DIVIDE(
        [Gross Profit (INR)],
        [Total Final Revenue (INR)],
        0
    )
    ```
    *Explanation:* Calculates the gross profit as a percentage of total final revenue, indicating the profitability of sales.

### Vendor/Product Performance Measures:

13. **Total Quantity Sold:**
    ```dax
    Total Quantity Sold = SUM(Transactions[quantity])
    ```
    *Explanation:* Sums the `quantity` of all products sold across all transactions.

14. **Average Product Rating:**
    ```dax
    Average Product Rating =
    CALCULATE(
        AVERAGE(Transactions[cleaned_product_rating]),
        REMOVEFILTERS(Transactions[cleaned_product_rating] = 0)
    )
    ```
    *Explanation:* Calculates the average `cleaned_product_rating`. `REMOVEFILTERS(Transactions[cleaned_product_rating] = 0)` ensures that if you replaced nulls with 0, those 0s are excluded from the average calculation, providing a true average for actually rated products. If 0 is a valid, lowest rating, remove this filter.

15. **Average Customer Rating:**
    ```dax
    Average Customer Rating =
    CALCULATE(
        AVERAGE(Transactions[cleaned_customer_rating]),
        REMOVEFILTERS(Transactions[cleaned_customer_rating] = 0)
    )
    ```
    *Explanation:* Similar to product rating, this calculates the average `cleaned_customer_rating`, excluding 0s if they represent unrated entries.

## 5. Visualization

This section outlines recommended visuals and design considerations for your dashboard.

### Dashboard Layout & Design Tips:

*   **Header:** Start with a clear dashboard title (e.g., "Supply Chain Performance Overview") at the top.
*   **KPI Strip:** Place your key performance indicator (KPI) cards in a prominent row across the top.
*   **Consistency:** Use a consistent color scheme, font styles, and visual sizes across your dashboard for a professional look.
*   **Clear Titles:** Ensure all visuals have descriptive titles.
*   **Tooltips:** Customize tooltips for your visuals to display additional relevant information when a user hovers over data points.
*   **Page Background:** Consider a subtle background color or image to enhance visual appeal.

### Recommended Visuals:

#### Section 1: Key Performance Indicators (KPIs) - Use Card Visuals

Place these at the top of your dashboard for quick insights.

1.  **Total Orders:** Card visual with `Total Orders` measure.
2.  **Total Final Revenue (INR):** Card visual with `Total Final Revenue (INR)` measure (format as Currency).
3.  **Average Delivery Days:** Card visual with `Average Delivery Days` measure (format to 1-2 decimal places).
4.  **Delivery Rate:** Card visual with `Delivery Rate` measure (format as Percentage).
5.  **Return Rate:** Card visual with `Return Rate` measure (format as Percentage).
6.  **Gross Profit Margin:** Card visual with `Gross Profit Margin` measure (format as Percentage).

#### Section 2: Delivery Reliability & Performance

1.  **Average Delivery Days Trend:**
    *   **Visual:** Line Chart
    *   **X-axis:** `Month Year` from your `Date` table.
    *   **Y-axis:** `Average Delivery Days`.
    *   **Insights:** Track changes in delivery speed over time to identify trends or seasonal impacts.

2.  **Delivery Rate by Delivery Type:**
    *   **Visual:** Clustered Column Chart
    *   **X-axis:** `delivery_type`.
    *   **Y-axis:** `Delivery Rate`.
    *   **Insights:** Compare the success rate of different delivery methods.

3.  **Return Analysis by Product Category/Brand:**
    *   **Visual:** Matrix or Table
    *   **Rows:** `cleaned_category` or `brand`.
    *   **Values:** `Total Orders`, `Total Returned Orders`, `Return Rate`.
    *   **Insights:** Pinpoint specific product categories or brands with higher return rates, which might indicate quality issues or mismanaged expectations.

4.  **On-Time Delivery Rate by Customer State:**
    *   **Visual:** Filled Map
    *   **Location:** `customer_state`.
    *   **Color Saturation:** `On-Time Delivery Rate`.
    *   **Tooltip:** Add `Total Delivered Orders` and `Average Delivery Days`.
    *   **Insights:** Visualize geographical areas where delivery performance is strong or needs improvement.

#### Section 3: Cost Analysis

1.  **Revenue, Cost, and Profit by Category:**
    *   **Visual:** Clustered Column Chart
    *   **Axis:** `cleaned_category`.
    *   **Values:** `Total Final Revenue (INR)`, `Total Product Cost (INR)`, `Gross Profit (INR)`.
    *   **Insights:** Understand the financial contribution and cost drivers of different product categories.

2.  **Gross Profit Margin Trend:**
    *   **Visual:** Line Chart
    *   **X-axis:** `Year` or `Month Year` from your `Date` table.
    *   **Y-axis:** `Gross Profit Margin`.
    *   **Insights:** Monitor how profitability changes over time, highlighting periods of high or low margin.

3.  **Total Delivery Charges by Customer State:**
    *   **Visual:** Treemap or Bar Chart
    *   **Group/Axis:** `customer_state`.
    *   **Values:** `Total Delivery Charges`.
    *   **Insights:** Identify which states contribute most to delivery expenses.

#### Section 4: Vendor/Product Performance (Proxy for Supplier)

1.  **Top N Brands by Quantity Sold:**
    *   **Visual:** Bar Chart
    *   **Axis:** `brand`.
    *   **Values:** `Total Quantity Sold`.
    *   **Filter:** Apply a `Top N` filter on the `brand` field in the Filters pane to show, for example, the "Top 10 by Total Quantity Sold".
    *   **Insights:** Highlight the best-performing brands in terms of sales volume.

2.  **Average Product Rating by Brand:**
    *   **Visual:** Bar Chart
    *   **Axis:** `brand`.
    *   **Values:** `Average Product Rating`.
    *   **Insights:** Assess customer satisfaction with products from different brands.

## 6. Interactivity

Interactivity allows users to explore the data dynamically and drill into specific areas of interest.

### 1. Slicers:

Add these slicers to your dashboard to enable dynamic filtering of all visuals on the page.

*   **Date Slicer:**
    *   **Visual:** Slicer
    *   **Field:** Drag `Year` from your `Date` table to the slicer. You can also add `Month` or `Quarter` for more granular control. Set the slicer style to `Dropdown` or `List`. For `Date` field, you can choose a `Relative date slicer` for options like "Last 30 days", "This Year".
*   **Category Slicer:**
    *   **Visual:** Slicer
    *   **Field:** `cleaned_category`
*   **Brand Slicer:**
    *   **Visual:** Slicer
    *   **Field:** `brand`
*   **Customer State Slicer:**
    *   **Visual:** Slicer
    *   **Field:** `customer_state`
*   **Return Status Slicer:**
    *   **Visual:** Slicer
    *   **Field:** `return_status`
*   **Delivery Type Slicer:**
    *   **Visual:** Slicer
    *   **Field:** `delivery_type`

### 2. Drill-down/Drill-through:

*   **Drill-down on Date Hierarchies:** For line charts (e.g., Delivery Days Trend), ensure the date field in the axis has a hierarchy (Year, Quarter, Month, Day). Users can then use the drill-down arrows at the top of the visual to navigate through different levels of time granularity.

*   **Drill-through Page (Optional but powerful for detail):**
    1.  **Create a New Page:** Add a new page to your report and rename it "Product Detail".
    2.  **Add Detail Visuals:** On this "Product Detail" page, add visuals that show granular information about a product, such as a Table visual with `product_name`, `brand`, `subcategory`, `Total Quantity Sold`, `Average Product Rating`, `Return Rate`, `Gross Profit Margin`, etc.
    3.  **Configure Drill-through:** In the `Visualizations` pane for the "Product Detail" page, drag `product_name` from your `Transactions` table into the `Drill through` section. Power BI will automatically add a "Back" button to this page.
    4.  **How to Use:** Now, on your main dashboard, if you right-click on a `product_name` in any visual (like your "Return Analysis by Product Category/Brand" table), you will see an option to `Drill through -> Product Detail`. Clicking this will take you to the "Product Detail" page, filtered specifically for the product you selected.

By meticulously following these instructions, you will create a comprehensive and interactive Supply Chain Dashboard in Power BI, empowering you to monitor and analyze critical aspects of your operations effectively.