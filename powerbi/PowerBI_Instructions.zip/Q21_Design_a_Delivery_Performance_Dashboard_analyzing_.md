Here's a comprehensive guide to building your Delivery Performance Dashboard in Power BI, assuming your CSV data is named `DeliveryData.csv`.

---

### Power BI Delivery Performance Dashboard

#### 1. Objective:
The primary goal of this dashboard is to provide a comprehensive view of delivery performance by analyzing delivery times, on-time delivery rates, identifying geographic variations, and tracking key operational efficiency metrics. This will help in understanding and improving the overall delivery process.

#### 2. Data Loading & Preparation:

**Step 1: Load the CSV Data**
1.  Open Power BI Desktop.
2.  On the Home tab, click **"Get Data"**.
3.  Select **"Text/CSV"** from the list and click **"Connect"**.
4.  Navigate to your `DeliveryData.csv` file, select it, and click **"Open"**.
5.  A preview window will appear. Ensure the "Delimiter" is detected as "Comma" and "Data Type Detection" is "Based on first 200 rows".
6.  Click **"Transform Data"** to open the Power Query Editor. This is crucial for cleaning and preparing your data.

**Step 2: Data Cleaning and Transformation in Power Query Editor**

In the Power Query Editor, you'll perform the following transformations:

1.  **Rename Table:**
    *   In the "Query Settings" pane on the right, under "Name", rename `DeliveryData` (or whatever Power BI named it) to `Sales`.

2.  **Change Data Types:**
    *   **`clean_order_date`**: Select the column, go to the "Transform" tab, click "Data Type" and choose **"Date"**.
    *   **`cleaned_delivery_days`**: Select the column, change Data Type to **"Decimal Number"** or **"Whole Number"** (Decimal is safer if there are non-integer days).
    *   **`quantity`**: Change Data Type to **"Whole Number"**.
    *   **`product_weight_kg`**: Change Data Type to **"Decimal Number"**.
    *   **`clean_original_price_inr`, `clean_discount_percent`, `clean_final_amount_inr`, `clean_delivery_charges`, `corrected_price`**: Change Data Type to **"Decimal Number"**.
    *   **`cleaned_customer_rating`, `cleaned_product_rating`**: Change Data Type to **"Decimal Number"**.
    *   **`cleaned_is_prime_member`, `cleaned_is_prime_eligible`, `cleaned_is_festival_sale`**: Change Data Type to **"True/False"** (Boolean).
    *   Verify other columns like `transaction_id`, `customer_id`, `product_id`, `product_name`, `subcategory`, `brand`, `customer_state`, `customer_tier`, `customer_spending_tier`, `customer_age_group`, `delivery_type`, `festival_name`, `return_status`, `order_month`, `order_year`, `order_quarter`, `cleaned_category`, `cleaned_customer_city`, `duplicate_type`, `standard_payment_method` have appropriate text or whole number types.

3.  **Handle Missing Values:**
    *   **`cleaned_delivery_days`**: This is critical for delivery analysis. If a `cleaned_delivery_days` value is null, it means we cannot calculate delivery performance for that transaction.
        *   Select the `cleaned_delivery_days` column.
        *   Click the dropdown arrow next to the column name.
        *   Uncheck the `null` box to filter out rows with missing delivery days.
        *   *Alternatively, if you want to keep them, you could replace `null` with a default value like 0, but filtering is generally better for performance metrics.*
    *   For other columns like `cleaned_customer_rating`, `cleaned_product_rating`, `festival_name` etc., `null` values can often be left as is or handled on a case-by-case basis if they impact specific visualizations. For this dashboard, `cleaned_delivery_days` is the most important to clean.

4.  **Create Custom Column (if needed for "On-Time" definition):**
    *   Since there's no explicit "Expected Delivery Date" or SLA in the data, we'll define "On-Time" based on a reasonable threshold for `cleaned_delivery_days`. Let's assume **5 days or less is considered "On-Time"**. You can adjust this threshold.
    *   Go to the "Add Column" tab.
    *   Click "Custom Column".
    *   **New column name:** `Is On-Time`
    *   **Custom column formula:**
        ```powerquery
        if [cleaned_delivery_days] <= 5 then "On-Time" else "Late"
        ```
    *   Click "OK". Change the data type of this new column to **"Text"**.

5.  **Close & Apply:**
    *   Once all transformations are complete, click **"Close & Apply"** on the Home tab of Power Query Editor. This will load the cleaned data into Power BI Desktop.

#### 3. Data Modeling:

**Step 1: Create a Date Table (Calendar Table)**
A dedicated date table is essential for robust time-intelligence analysis.

1.  In Power BI Desktop, go to the **"Table tools"** tab (you might need to select any table first).
2.  Click **"New Table"**.
3.  Paste the following DAX formula to create your `Calendar` table:

    ```dax
    Calendar =
    VAR MinDate = CALCULATE(MIN(Sales[clean_order_date]), ALL(Sales))
    VAR MaxDate = CALCULATE(MAX(Sales[clean_order_date]), ALL(Sales))
    RETURN
        ADDCOLUMNS (
            CALENDAR ( MinDate, MaxDate ),
            "DateKey", FORMAT ( [Date], "yyyymmdd" ),
            "Year", YEAR ( [Date] ),
            "Quarter", "Q" & FORMAT( [Date], "q" ),
            "Month Number", MONTH ( [Date] ),
            "Month Name", FORMAT ( [Date], "mmm" ),
            "Full Month Name", FORMAT ( [Date], "mmmm" ),
            "Day of Week", WEEKDAY ( [Date], 2 ),
            "Day Name", FORMAT ( [Date], "ddd" ),
            "Full Day Name", FORMAT ( [Date], "dddd" ),
            "Weekday/Weekend", IF(WEEKDAY([Date],2) IN {6,7}, "Weekend", "Weekday")
        )
    ```
4.  Press Enter to create the table.

**Step 2: Create Relationships**

1.  Go to the **"Model view"** (the icon with three tables connected) on the left sidebar in Power BI Desktop.
2.  Drag the `clean_order_date` column from your `Sales` table to the `Date` column in your `Calendar` table. This will create a one-to-many relationship (Calendar[Date] to Sales[clean_order_date]).
3.  Ensure the relationship is active and correctly configured (one-to-many, single filter direction from Calendar to Sales).

#### 4. DAX Measures:

Now, create the following measures. Go to the "Table tools" tab, click "New Measure" for each, and paste the DAX code. Store these measures in your `Sales` table for organization.

1.  **Total Orders:**
    ```dax
    Total Orders = COUNTROWS(Sales)
    ```
    *Explanation: Counts the total number of transactions in your dataset.*

2.  **Total Delivered Orders:**
    ```dax
    Total Delivered Orders =
    CALCULATE(
        COUNTROWS(Sales),
        Sales[return_status] = "Delivered"
    )
    ```
    *Explanation: Counts only the transactions that have a 'Delivered' status.*

3.  **Avg. Delivery Days (Delivered Orders):**
    ```dax
    Avg. Delivery Days (Delivered) =
    AVERAGEX(
        FILTER(Sales, Sales[return_status] = "Delivered"),
        Sales[cleaned_delivery_days]
    )
    ```
    *Explanation: Calculates the average delivery days, considering only delivered orders to ensure accuracy.*

4.  **On-Time Delivered Orders (<=5 Days):**
    ```dax
    On-Time Delivered Orders =
    CALCULATE(
        [Total Delivered Orders],
        Sales[cleaned_delivery_days] <= 5 // Our defined on-time threshold
    )
    ```
    *Explanation: Counts delivered orders that met the 5-day on-time threshold.*

5.  **On-Time Delivery Rate:**
    ```dax
    On-Time Delivery Rate =
    DIVIDE(
        [On-Time Delivered Orders],
        [Total Delivered Orders],
        0 // Return 0 if total delivered orders is 0 to avoid errors
    )
    ```
    *Explanation: Calculates the percentage of delivered orders that were on-time.*

6.  **Late Delivered Orders (>5 Days):**
    ```dax
    Late Delivered Orders =
    CALCULATE(
        [Total Delivered Orders],
        Sales[cleaned_delivery_days] > 5 // Our defined late threshold
    )
    ```
    *Explanation: Counts delivered orders that exceeded the 5-day on-time threshold.*

7.  **Late Delivery Rate:**
    ```dax
    Late Delivery Rate =
    DIVIDE(
        [Late Delivered Orders],
        [Total Delivered Orders],
        0
    )
    ```
    *Explanation: Calculates the percentage of delivered orders that were late.*

8.  **Avg. Delivery Charges per Order (Delivered):**
    ```dax
    Avg. Delivery Charges per Order =
    AVERAGEX(
        FILTER(Sales, Sales[return_status] = "Delivered"),
        Sales[clean_delivery_charges]
    )
    ```
    *Explanation: Calculates the average delivery charge for delivered orders.*

9.  **Total Quantity Delivered:**
    ```dax
    Total Quantity Delivered =
    CALCULATE(
        SUM(Sales[quantity]),
        Sales[return_status] = "Delivered"
    )
    ```
    *Explanation: Sums the total quantity of items delivered.*

10. **Prime Member On-Time Rate:**
    ```dax
    Prime Member On-Time Rate =
    VAR PrimeDeliveredOrders = CALCULATE([Total Delivered Orders], Sales[cleaned_is_prime_member] = TRUE())
    VAR PrimeOnTimeOrders = CALCULATE([On-Time Delivered Orders], Sales[cleaned_is_prime_member] = TRUE())
    RETURN
        DIVIDE(PrimeOnTimeOrders, PrimeDeliveredOrders, 0)
    ```
    *Explanation: Calculates the on-time delivery rate specifically for Prime members.*

#### 5. Visualization:

Go to the "Report view" (the icon with a bar chart) on the left sidebar.

**Dashboard Layout & Design Tips:**

*   **Header:** Add a text box for the dashboard title: "Delivery Performance Dashboard".
*   **Consistency:** Use a consistent color palette and font sizes for readability.
*   **Key Metrics First:** Place your most important KPIs (Cards) at the top of the dashboard.
*   **Interactivity:** Ensure visuals cross-filter each other effectively.

**Recommended Visuals:**

1.  **KPI Cards (Top Row):**
    *   **Visual Type:** Card
    *   **Metrics:**
        *   `Total Delivered Orders`
        *   `Avg. Delivery Days (Delivered)` (Format to 1 or 2 decimal places)
        *   `On-Time Delivery Rate` (Format as Percentage, 1 or 2 decimal places)
        *   `Late Delivery Rate` (Format as Percentage, 1 or 2 decimal places)
    *   *Purpose:* Quick overview of primary performance indicators.

2.  **Delivery Days Trend Over Time (Line Chart):**
    *   **Visual Type:** Line Chart
    *   **Axis (X-axis):** `Calendar[Month Name]` (and optionally `Calendar[Year]` for drill-down)
    *   **Values (Y-axis):** `Avg. Delivery Days (Delivered)`
    *   *Purpose:* Monitor changes in average delivery time over months/years.

3.  **On-Time Delivery Rate by State (Filled Map):**
    *   **Visual Type:** Filled Map
    *   **Location:** `Sales[customer_state]`
    *   **Color saturation:** `On-Time Delivery Rate`
    *   *Purpose:* Visualize geographic variations in delivery performance. States with darker saturation could indicate better on-time rates.

4.  **On-Time Delivery Rate by Delivery Type & Category (Clustered Bar Chart):**
    *   **Visual Type:** Clustered Bar Chart
    *   **Axis:** `Sales[delivery_type]`
    *   **Legend:** `Sales[cleaned_category]`
    *   **Values:** `On-Time Delivery Rate`
    *   *Purpose:* Compare on-time rates across different delivery methods and product categories.

5.  **Delivery Performance by Customer Tier & Prime Status (Matrix or Table):**
    *   **Visual Type:** Matrix
    *   **Rows:** `Sales[customer_tier]`
    *   **Columns:** `Sales[cleaned_is_prime_member]`
    *   **Values:** `On-Time Delivery Rate`, `Avg. Delivery Days (Delivered)`
    *   *Purpose:* Analyze how customer segments (tier, prime status) affect delivery performance.

6.  **Distribution of Delivery Days (Column Chart):**
    *   **Visual Type:** Column Chart
    *   **Axis (X-axis):** `Sales[cleaned_delivery_days]` (might need to create bins for days, e.g., 0-1, 2-3, 4-5, etc., in Power Query or DAX for better visualization if there's too much granularity)
    *   **Values (Y-axis):** `Total Delivered Orders`
    *   *Purpose:* Understand the frequency of different delivery durations.

7.  **Average Delivery Charges by Delivery Type (Bar Chart):**
    *   **Visual Type:** Bar Chart
    *   **Axis:** `Sales[delivery_type]`
    *   **Values:** `Avg. Delivery Charges per Order`
    *   *Purpose:* Evaluate cost efficiency across different delivery types.

#### 6. Interactivity:

**Step 1: Add Slicers**

Slicers allow users to filter the entire dashboard dynamically.

1.  **Year Slicer:**
    *   **Visual Type:** Slicer
    *   **Field:** `Calendar[Year]`
    *   **Settings:** Change "Selection" to "Single select" or "Multi-select" as preferred. "Dropdown" or "List" style.

2.  **Month Name Slicer:**
    *   **Visual Type:** Slicer
    *   **Field:** `Calendar[Full Month Name]`
    *   **Settings:** Change "Selection" to "Multi-select" or "Single select" as preferred.

3.  **Customer State Slicer:**
    *   **Visual Type:** Slicer
    *   **Field:** `Sales[customer_state]`

4.  **Delivery Type Slicer:**
    *   **Visual Type:** Slicer
    *   **Field:** `Sales[delivery_type]`

5.  **Product Category Slicer:**
    *   **Visual Type:** Slicer
    *   **Field:** `Sales[cleaned_category]`

6.  **Prime Member Slicer:**
    *   **Visual Type:** Slicer
    *   **Field:** `Sales[cleaned_is_prime_member]`

**Step 2: Enable Cross-filtering**
By default, most visuals in Power BI will cross-filter each other when you click on elements within them.
*   To manage how visuals interact, select a visual, then go to the "Format" tab in the ribbon, and click **"Edit interactions"**. This allows you to set whether other visuals filter or highlight based on your selection.

By following these steps, you will create a robust and insightful Delivery Performance Dashboard in Power BI, empowering you to analyze and understand your delivery operations effectively.